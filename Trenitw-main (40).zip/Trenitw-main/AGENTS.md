<!-- LOVABLE:BEGIN -->

> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

<!-- LOVABLE:END -->

## Freemius paywall

### 1. Premium features — how to identify them

Premium features are the routes/actions gated behind a Freemius entitlement:

| Premium feature                           | Entry point                             | Gated by                                        |
| ----------------------------------------- | --------------------------------------- | ----------------------------------------------- |
| Google Business Profile Draft Generation  | `POST /api/user/generate-draft`         | `require_entitlement` (HTTP 402 if un-entitled) |
| Active Google Business Profile Scheduling | `POST /api/user/approve-post/{post_id}` | Gated via draft creation lifecycle              |

### 2. Paywalling premium features with Freemius

1. **Sell** — The frontend opens the Freemius Checkout overlay for the Growth plan ($29/month).
2. **Sync** — The purchase callback + Freemius webhooks upsert the `user_fs_entitlement` table in PostgreSQL.
3. **Gate** — Before a draft is generated, the backend checks `user_fs_entitlement`. Missing or expired entitlement returns **HTTP 402 Payment Required**.

All Freemius SDK calls are **server-side**; secrets come from `.env` only.

### 3. Where the paywall library functions live

| Concern                         | File                                                         |
| ------------------------------- | ------------------------------------------------------------ |
| Freemius SDK client             | `site/Trenitw/src/services/freemius/client.ts`               |
| Checkout creation & redirect    | `site/Trenitw/src/services/freemius/checkout.ts`             |
| Entitlement sync & verification | `site/Trenitw/src/services/freemius/entitlement.ts`          |
| Frontend Checkout Button        | `site/Trenitw/src/components/freemius/checkout-button.tsx`   |
| Backend Entitlement Check       | `app/routes/user.py` (`/api/user/entitlement/{customer_id}`) |
| Database Table                  | PostgreSQL `user_fs_entitlement`                             |

---

## UI/UX & Design Intelligence

When building, styling, or refactoring UI components, pages, design tokens, or visual layouts:

1. **Always consult the UI/UX Pro Max skill** located at `.agents/skills/ui-ux-pro-max/SKILL.md`.
2. Use `.agents/skills/ui-ux-pro-max/scripts/search.py` to look up stack-specific rules (React / Tailwind / shadcn), color palettes, font pairings, chart styles, and UX heuristics.
3. Follow the accessibility (WCAG AA), responsive layout, and contrast guidelines provided in the design system skills.

---

## Agent Workflow Protocol

- **Tier 1 (Atomic / Direct UI Tasks)**: For localized styling, single component edits, copy changes, or icon fixes: execute directly with immediate type/lint checks.
- **Tier 2 (Complex / Full-Stack Tasks)**: For features connecting to backend APIs or auth: adhere strictly to backend contracts established by `trendexhub-lead`, delegate backend work to `trendexhub-backend`, and verify all states (loading, error, empty, success) via `trendexhub-qa`.
