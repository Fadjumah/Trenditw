# Trendit Landing Page & Footer Marketing/UI Correction

## OBJECTIVE

Work ONLY on the frontend website repository/ZIP (`Trenitw-main (26).zip`) and correct the current landing page so it feels like a credible, restrained, conversion-focused business product website — NOT an AI-generated SaaS template.

Do not redesign the application's dashboard, authentication, checkout, subscription logic, Google Business Profile functionality, API calls, routing, or backend.

Preserve all existing functionality. This task is specifically a landing-page marketing, typography, visual hierarchy, navigation/footer, and conversion-copy correction.

Primary files to inspect and modify:
- `src/routes/index.tsx`
- `src/styles.css`
- `src/components/site-nav.tsx`
- `src/components/site-footer.tsx`

Also inspect any imported landing-page components/styles before changing them.

---

# 1. REMOVE THE CURRENT GENERIC AI-SaaS VISUAL LANGUAGE

Strip out unnecessary visual decoration and aggressive typography from the landing page.

Remove/reduce:
- Excessive `font-bold` / `font-semibold` usage.
- Oversized headings that do not need to be oversized.
- Excessive uppercase labels.
- Excessive letter-spacing/tracking.
- Decorative Lucide icons used merely to make feature cards look “AI/SaaS”.
- Repeated shield/check/trending/calendar/message icons where they add no functional meaning.
- Decorative badges that do not communicate meaningful information.
- Gradient-heavy or “AI startup” visual treatments if present.
- Excessive rounded cards where normal content would be clearer.
- Any visual treatment that makes every section look like a separate SaaS marketing card.

Typography must establish a clear hierarchy:
- One primary hero heading.
- One supporting hero paragraph.
- Section headings should be strong but not oversized.
- Body copy should use normal readable weights.
- Bold should be reserved for genuinely important words or labels.
- Do not make entire paragraphs bold.
- Do not use uppercase as a substitute for hierarchy.

The page should feel designed by a professional product company, not generated from a generic landing-page prompt.

---

# 2. REMOVE THESE TYPES OF GENERIC/UNSUPPORTED CLAIMS

Delete the following types of claims wherever they currently appear:

- “rank #1”
- “Top Local 3-Pack”
- “Algorithmic Boost”
- “Google rewards active businesses.”
- “100% profile completeness” unless it is technically guaranteed and demonstrably true.
- Any promise that Trendit can guarantee a Google ranking position.
- Any wording implying guaranteed ranking, guaranteed visibility, or guaranteed business growth.
- Any fabricated performance statistics.

Do NOT replace these with another exaggerated claim.

Use factual, benefit-led language instead.

---

# 3. REMOVE THE FABRICATED “GROWTH SHOWCASE” METRICS

Remove the current section containing figures such as:

- `18.4K +134%`
- `12.1K +38%`
- `2.6K +42%`
- “Top 3 Local Pack”

These look fabricated and damage trust.

Do not invent replacement customer numbers.

Replace that entire visual concept with a simple, credible section explaining what Trendit helps a business owner do.

Use this exact wording:

## Heading
“Keep your business profile working for you.”

## Paragraph
“Trendit helps you keep your Google Business Profile accurate, active and useful to the customers searching for your business.”

## Three points
“Keep your business information up to date.”
“Stay on top of customer reviews and responses.”
“Find profile issues before they become missed opportunities.”

Do not add statistics to this section.

---

# 4. REMOVE THE SANTA MONICA / FICTIONAL BUSINESS COPY

Remove all references to:
- Santa Monica
- “Luna Artisan Studio”
- Any fictional business presented as if it were a Trendit customer.
- Any location-specific example that could make Trendit appear to be an American-only product.

Do not replace them with another fictional customer.

If an example is needed, use generic wording such as:
“Your business”
or
“A local business”.

---

# 5. REWRITE THE HERO SECTION COMPLETELY

Replace the current hero marketing copy with exactly:

Eyebrow:
“LOCAL BUSINESS MANAGEMENT”

Main heading:
“Keep your Google Business Profile accurate, active and ready for customers.”

Supporting paragraph:
“Trendit gives you one simple place to manage your business profile, stay on top of reviews and identify issues that could hold your local presence back.”

Primary CTA:
“Get started — $29/month”

Secondary CTA:
“See how it works”

Do NOT add:
- “AI”
- “AI-powered”
- “#1”
- “10x”
- “revolutionary”
- “game-changing”
- “dominate”
- “crush your competition”
- “guaranteed”
- “rank higher”

The hero should immediately communicate what Trendit does and why a business owner should care.

---

# 6. REWRITE THE “HOW IT WORKS” SECTION

Heading:
“Simple to manage. Built for busy business owners.”

Paragraph:
“Connect your business, review what needs attention, and keep your profile moving in the right direction — without having to piece everything together yourself.”

Use exactly three steps:

### 01 — Connect your business
“Connect your Google Business Profile and bring your business information into Trendit.”

### 02 — See what needs attention
“Review profile issues, customer reviews and opportunities from one clear dashboard.”

### 03 — Keep improving
“Make the necessary updates and stay consistent as your business changes.”

Do not add decorative icons to the numbered steps unless they are genuinely necessary. Prefer the numbers themselves as the visual anchors.

---

# 7. REWRITE THE FEATURES SECTION

Heading:
“Everything you need to manage your local presence.”

Intro:
“Trendit brings the everyday work of managing your business profile into one straightforward place.”

Use these feature titles and descriptions exactly:

### Profile Audit
“Identify missing, outdated or inconsistent information that could make your profile less useful to customers.”

### Review Management
“Stay on top of customer reviews and respond without losing track of what needs attention.”

### Business Updates
“Keep important business information current so customers see the right details when they find you.”

### Growth Posts
“Create and manage useful updates that keep your profile fresh and informative.”

### Profile Monitoring
“Keep an eye on your profile and catch important issues before they are overlooked.”

### Business Insights
“Understand the activity around your profile and use the information to make better decisions.”

Do not add claims about guaranteed rankings or guaranteed growth.

---

# 8. REMOVE “AI” MARKETING LANGUAGE

For the public-facing landing page, remove the word “AI” from marketing copy, headings, badges, feature descriptions and promotional labels.

Do not replace “AI” with another buzzword such as:
- intelligent
- autonomous
- algorithmic
- neural
- machine-powered
- next-generation

The product should be sold on what it does, not on how fashionable the underlying technology sounds.

Technical/internal implementation references can remain untouched where necessary for functionality.

---

# 9. PRICING SECTION

Keep the actual subscription price at:

“$29/month”

Use this exact heading:

“Everything you need for $29/month.”

Use this paragraph:

“One straightforward plan for businesses that want a better way to manage their Google Business Profile.”

Use this CTA:

“Start for $29/month”

Do not create a free tier.

Do not call it “Free Trial” unless the actual application currently provides a real free trial.

Do not imply that the customer can use the paid product indefinitely for free.

---

# 10. FAQ SECTION

Replace generic AI/SaaS questions with these exact questions and answers.

### What is Trendit?
“Trendit is a business management platform that helps you manage your Google Business Profile, keep your information current, stay on top of reviews and identify areas that need attention.”

### Who is Trendit for?
“Trendit is built for businesses that rely on customers finding them through Google and want a simpler way to manage their local business presence.”

### Do I need a Google Business Profile?
“Yes. Trendit is designed to help you manage and improve the information and activity associated with your Google Business Profile.”

### How much does Trendit cost?
“Trendit costs $29 per month.”

### Can I manage more than one business?
“Your available business connections depend on your account and subscription configuration. Connect the business you want to manage and use Trendit to keep its profile organised and up to date.”

Do not invent additional pricing tiers or features.

---

# 11. TRUST / CREDIBILITY SECTION

Do NOT use:
- Fake testimonials.
- Fake customer names.
- Fake company logos.
- Fake review scores.
- Fabricated case studies.
- Fabricated statistics.

If the current landing page contains any such material, remove it.

Replace the section with this simple copy:

Heading:
“Built to make local business management simpler.”

Paragraph:
“Your business information changes. Your customers ask questions. Reviews come in. Trendit gives you one place to keep track of the work that keeps your Google Business Profile useful and up to date.”

No fake social proof.

---

# 12. FINAL CTA SECTION

Replace the current final CTA copy with:

Heading:
“Give your business profile the attention it deserves.”

Paragraph:
“Keep your information current, stay on top of reviews and manage your local presence from one place.”

Primary CTA:
“Get started — $29/month”

Do not add exaggerated urgency such as:
- “Limited spots”
- “Act now”
- “Don’t miss out”
- “Join thousands”
unless there is a genuine factual basis.

---

# 13. NAVIGATION

Keep the navigation simple.

The primary navigation should not contain unnecessary marketing labels.

Use:

“Trendit”

“Features”

“How it works”

“Pricing”

“FAQ”

Primary CTA:
“Get started”

If the user is already authenticated, preserve the existing authenticated navigation behavior. Do not break routing.

Use the existing logo asset correctly.

---

# 14. COMPLETELY REORGANISE THE FOOTER

The current footer is too generic and looks like a template.

Replace it with a clean, purposeful footer.

Use this structure:

### Brand area

“Trendit”

“Simple tools for keeping your business profile accurate, active and ready for customers.”

### Product

“Features”
“How it works”
“Pricing”
“FAQ”

### Account

“Sign in”
“Get started”

### Legal

“Privacy”
“Terms”

Bottom line:

“© 2026 Trendit. All rights reserved.”

Do NOT create a huge multi-column corporate footer.

Do NOT add:
- “Company”
- “Our Story”
- “Careers”
- “Press”
- “Investors”
- “Partners”
- “Resources”
unless those pages genuinely exist.

Do not add social-media icons unless the corresponding official Trendit accounts actually exist and are configured.

The footer should be compact, balanced and useful.

---

# 15. REMOVE THE “ONE-MAN COMPANY” FEEL

Do not make the landing page revolve around an individual founder.

Do not use medical credentials, clinic language or personal-profession wording as a major marketing element.

The public-facing company identity should be:

“Trendit”

Where a company attribution is needed, use:

“Developed by Trendexhub”

Do not turn the landing page into a founder biography.

---

# 16. VISUAL DESIGN DIRECTION

The final design should have:

- Strong whitespace.
- Moderate heading sizes.
- Normal paragraph weights.
- One clear primary CTA style.
- Minimal secondary CTA styling.
- Restrained borders.
- Simple cards only where cards genuinely improve scanning.
- Very limited icon usage.
- No decorative icon explosion.
- No excessive pills/badges.
- No fake dashboard metrics.
- No giant statistics.
- No fake logos.
- No visual noise.

The visitor should feel:

“ This looks like a serious product I can trust.”

Not:

“ This looks like an AI-generated startup landing page.”

---

# 17. IMPORTANT: DO NOT OVER-REDESIGN

Do not replace the entire application architecture.

Do not rewrite unrelated components.

Do not modify:
- authentication
- checkout
- subscription handling
- Google OAuth
- Google Business Profile connection logic
- dashboard functionality
- API calls
- backend code
- database logic

Only change the presentation, marketing content and landing-page/footer structure necessary to complete this task.

---

# 18. FINAL QUALITY CHECK

Before finishing, inspect the rendered landing page at desktop and mobile widths.

Verify:

1. The hero communicates the product within seconds.
2. There is no unnecessary “AI” marketing language.
3. There are no fabricated metrics.
4. There are no fictional customers.
5. There are no Santa Monica/Luna Artisan references.
6. No section is unnecessarily screaming in bold uppercase.
7. Icons are used sparingly.
8. The $29/month pricing is consistent.
9. CTA wording is consistent.
10. Footer looks intentionally designed rather than template-generated.
11. No fake testimonials or social proof remain.
12. Existing routing and buttons still work.
13. Mobile layout remains clean.
14. The landing page feels like one coherent product website rather than a collection of AI-generated sections.

Most importantly: do not substitute your own marketing copy for the exact copy specified above. Where this document provides exact wording, use it verbatim unless a technical UI constraint makes a minor grammatical adjustment absolutely necessary.
