# Trendit Editorial Design System

> Canonical visual reference for applying the Trendit UI design system across pages, components, dashboards, and future product surfaces.
> Product: Trendit by Trendexhub
> Design direction: premium, editorial, mobile-first SaaS.

---

## 1. DESIGN PRINCIPLES

- Premium editorial SaaS aesthetic.
- Warm, calm, minimal, trustworthy, and conversion-focused.
- Mobile-first; layouts must remain clean on narrow screens.
- Strong hierarchy with generous whitespace.
- Fewer visual elements competing for attention.
- Avoid generic "AI dashboard" aesthetics.
- Avoid unnecessary gradients, excessive shadows, decorative arrows, and generic icon-heavy layouts.
- Reuse the same visual language across marketing pages and product UI without making every page identical.
- Preserve functionality and business logic when applying the design system.
- Prefer clarity and hierarchy over density.

---

## 2. CORE COLOR TOKENS

Primary background:
- Cream / warm off-white: #F7F3EB

Primary text:
- Near-black: #171512

Primary accent:
- Burnt orange: #B64B25

Secondary warm surface:
- Soft peach / beige: #E9DDD0

Cards:
- White: #FFFFFF

Muted text:
- Warm neutral gray; use restrained contrast rather than pure gray whenever possible.

Borders:
- Soft warm gray / beige.
- Use thin borders instead of heavy outlines.

Status:
- Success: restrained green treatment.
- Warning: warm amber treatment.
- Error: restrained red treatment.
- Keep status colors secondary to the main cream/black/orange system.

Do not introduce new dominant colors without a strong functional reason.

---

## 3. TYPOGRAPHY SYSTEM

### Display / Major headings
- Use the site's serif display face (Instrument Serif where available).
- Large, elegant, editorial.
- Primary hero range: approximately 56px–72px on large screens.
- Responsive hero range: approximately 40px–56px on mobile.
- Use serif primarily for major emotional/product headings, not every heading.

### Section headings
- Approximately 36px–52px.
- Serif where editorial emphasis is appropriate.
- Keep line-height tight and intentional.

### Card headings
- Approximately 18px–22px.
- Usually clean sans-serif; serif may be used for important feature/product names.

### Body text
- Approximately 15px–17px.
- Clean sans-serif.
- Comfortable line-height.
- Avoid overly small body copy.

### Secondary text
- Approximately 13px–14px.
- Use for supporting information, metadata, timestamps, etc.

### Eyebrows / labels
- Approximately 12px–13px.
- Uppercase.
- Increased letter spacing.
- Sans-serif or restrained monospace only when it adds a technical/editorial feel.

### Technical / mono text
Use monospace selectively:
- IDs
- timestamps
- schedules
- technical status
- system metadata
- developer-facing values

Do NOT use monospace for every label.

### Avoid
- Random font-family changes.
- Excessive font-weight changes.
- Large numbers of 10px/11px labels.
- Mixing several unrelated typography systems on one page.

---

## 4. TYPOGRAPHY HIERARCHY

Preferred hierarchy:

Eyebrow
→ Section heading
→ Supporting sentence
→ Primary action
→ Card heading
→ Body
→ Metadata

A page should not make every label visually loud.

---

## 5. LAYOUT TOKENS

### Content width
- Standard maximum content width: approximately `max-w-6xl`.
- Keep major sections aligned to the same horizontal content grid.

### Horizontal padding
- Mobile: approximately 20px.
- Tablet: approximately 24px.
- Desktop: approximately 32px or the equivalent spacing from the shared container.

### Vertical rhythm
Use deliberate spacing rather than many small arbitrary margins.

Typical:
- Small internal gap: 8px–12px
- Standard component gap: 16px–24px
- Section gap: 48px–80px
- Major marketing section gap: 80px–120px

Adjust responsively.

### Alignment
- Prefer consistent left alignment for editorial layouts.
- Keep headings, body copy, cards, and actions on the same content grid.
- Avoid unnecessary centered blocks inside otherwise left-aligned layouts.

---

## 6. CARDS

Preferred:
- White or very light warm surface.
- Thin warm border.
- Generous internal padding.
- Rounded corners.
- Subtle or no shadow.
- Strong typographic hierarchy.

Avoid:
- Heavy shadows.
- Excessive nested cards.
- Too many badges inside a card.
- Every piece of information being placed inside its own container.

Cards should group related information, not fragment it.

---

## 7. BUTTONS

Primary:
- Near-black background.
- White text.
- Rounded/pill or moderately rounded shape.
- Strong but restrained.

Secondary:
- Cream/white background.
- Near-black text.
- Thin warm border.

Accent:
- Burnt orange for important product actions or selected states.

Rules:
- One dominant action per visual section whenever possible.
- Avoid multiple competing primary buttons.
- Button text should be concise and action-oriented.

---

## 8. PILLS / BADGES

Use pills for:
- Connection state
- Subscription state
- Active status
- Small categorical information

Do not use pills for every piece of content.

Status badges should be visually quiet.

---

## 9. BORDERS & SHADOWS

Borders:
- Thin, subtle, warm-toned.
- Prefer a refined 1px border.

Shadows:
- Very subtle.
- Use only where elevation materially improves usability.
- Avoid floating-card-heavy interfaces.

The interface should feel tactile without looking glossy.

---

## 10. RADIUS

Use a consistent family of rounded corners.

Suggested:
- Small controls: 10px–14px
- Standard cards: 20px–28px
- Large feature panels: 28px–36px
- Pills: fully rounded

Do not mix many unrelated corner radii.

---

## 11. ICONOGRAPHY

- Use simple, purposeful icons.
- Prefer thin/clean line icons.
- Icons should support meaning rather than decorate empty space.
- Keep icon sizing consistent.
- Avoid generic icon grids and unnecessary decorative symbols.
- Do not let icons compete with typography.

---

## 12. MARKETING PAGE LANGUAGE

Marketing pages should feel:
- Editorial
- Confident
- Human
- Premium
- Direct

Use:
- Large serif statements.
- Short paragraphs.
- Strong whitespace.
- Real product UI previews.
- Clear conversion actions.

Avoid:
- Generic AI buzzwords.
- Dense feature lists.
- Excessive gradients.
- Stock-looking illustrations.
- Overly technical copy above the fold.

---

## 13. DASHBOARD LANGUAGE

The dashboard is a premium SaaS workspace, not a developer/admin console.

Prioritize:
1. Business identity
2. Connection state
3. Subscription state
4. What needs attention
5. Autopilot status
6. Workflow
7. Detailed tools

Avoid making every data point visually prominent.

Use a restrained hierarchy such as:

BUSINESS WORKSPACE

Business Name

Signed in as...

[Connected to Google] [View on Google]

---

## 14. AUDIT / DIAGNOSTIC EXPERIENCE

The Audit Assistant should NOT feel like a generic chatbot.

Primary concept:
- Diagnostic workspace first.
- Conversational assistant second.

Preferred structure:

DIAGNOSTIC ASSISTANT

Business name
Google Business Profile

PROFILE HEALTH

Score
Short interpretation

Opportunities
01 Services
02 Reviews
03 Posts
04 Profile

Then:

Ask about your profile →

When conversation is opened:
- Keep the chat simple.
- One clear conversation area.
- One clean input area.
- Avoid stacking progress bars, status pills, assistant bubbles, assessment bars, and multiple headers simultaneously.

During audit:
- Show one clear progress/status state.
- Keep the user oriented.
- Do not fill the entire mobile screen with technical process information.

---

## 15. AUTOPILOT / SCHEDULING

Scheduling should feel simple and trustworthy.

Show:
- Autopilot status
- Frequency
- Time
- Timezone
- Next scheduled post
- Last published post

Avoid:
- Excessive technical scheduling metadata.
- Multiple competing status cards.
- Developer-style controls.

Timezone handling must remain global and must never assume Kampala, Uganda, Africa, or any specific region.

---

## 16. REVIEWS

Reviews should prioritize:
- Reviewer's rating
- Review content
- Response status
- Suggested/automated response
- Clear action

Avoid dense tables and excessive metadata.

Use whitespace to separate individual reviews.

---

## 17. GROWTH / INSIGHTS

Growth surfaces should emphasize:
- What changed
- What matters
- What action should happen next

Use large numbers sparingly.
Use editorial explanations rather than dashboard clutter.

---

## 18. ONBOARDING

Onboarding should feel:
- Calm
- Guided
- Simple
- Trustworthy

One major action per step.

Avoid showing technical implementation details to the user unless necessary.

---

## 19. RESPONSIVE RULES

Mobile is a first-class experience.

On mobile:
- Reduce heading size responsively.
- Preserve generous vertical spacing.
- Stack cards when necessary.
- Keep tap targets comfortable.
- Avoid horizontal overflow.
- Never allow multiple UI controls to compete for one row.
- Keep primary actions visible and understandable.

Desktop may add columns and breathing room, but should retain the same hierarchy.

---

## 20. PRODUCT UI VS MARKETING UI

Do not copy the Growth Partnership page literally into the dashboard.

Instead:

Marketing:
- More editorial
- More dramatic typography
- More storytelling
- More whitespace

Product:
- More functional
- More structured
- More information density
- Same colors, typography, spacing philosophy, borders, radii, and hierarchy

Both should immediately feel like Trendit.

---

## 21. GLOBAL CONSISTENCY RULE

Before creating any new page/component, ask:

1. Does it use the same cream/black/orange palette?
2. Does it use the same typography hierarchy?
3. Is the serif reserved for meaningful headings?
4. Is monospace being used only where useful?
5. Does it share the same content width?
6. Are spacing values consistent?
7. Are cards/borders/radii consistent?
8. Is there unnecessary visual noise?
9. Is there one clear primary action?
10. Does it look like Trendit rather than a generic SaaS/AI template?

---

## 22. IMPLEMENTATION RULE FOR AI/CODING ASSISTANTS

When asked to redesign a Trendit page/component:

- Read this file first.
- Treat these tokens as the canonical Trendit visual system.
- Inspect existing functionality before changing UI.
- Preserve API calls, state management, routes, authentication, business logic, and data flow unless explicitly asked to change them.
- Prefer modifying existing components/styles over introducing a new visual framework.
- Reuse existing design tokens/classes where possible.
- Do not introduce a new font family unless explicitly required.
- Do not create a separate design system for an individual page.
- If a new visual token is necessary, make it compatible with this system and document it here.

---

## 23. REFERENCE PAGES

The visual benchmark pages are:

- Trendit homepage
- Trendit Growth Partnership page

Use these as visual references for:
- Typography
- Spacing
- Editorial hierarchy
- Color balance
- Card treatment
- Responsive behavior
- Overall brand feel

The Growth Partnership page is the strongest current reference for the design system.

---

## 24. CORE DESIGN TOKENS — QUICK REFERENCE

```text
BACKGROUND       #F7F3EB
TEXT              #171512
ACCENT            #B64B25
SOFT SURFACE      #E9DDD0
CARD              #FFFFFF

CONTENT WIDTH     max-w-6xl
MOBILE PADDING    ~20px
TABLET PADDING    ~24px
DESKTOP PADDING   ~32px

BODY              15–17px
SECONDARY         13–14px
EYEBROW           12–13px
CARD HEADING      18–22px
SECTION HEADING   36–52px
HERO              40–72px responsive

SMALL RADIUS      10–14px
CARD RADIUS       20–28px
FEATURE RADIUS    28–36px
PILL              9999px

BORDER            1px subtle warm neutral
SHADOW            minimal
```

---

## 25. FINAL DESIGN TEST

A finished Trendit page should feel:

**Warm. Editorial. Spacious. Intelligent. Trustworthy. Premium. Simple.**

It should NOT feel:

**Generic. Over-engineered. Developer-heavy. AI-generic. Crowded. Glossy. Template-like.**

This file is the canonical reference for future Trendit UI work.
