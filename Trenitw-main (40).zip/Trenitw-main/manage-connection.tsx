import { useState } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { BACKEND_URL, apiFetch } from "@/lib/api";
import { toast } from "sonner";

export function ManageConnection({
  businessName,
  customerId,
}: {
  businessName?: string;
  customerId: string;
}) {
  const [switching, setSwitching] = useState(false);

  const handleSwitch = async () => {
    setSwitching(true);
    try {
      const response = await apiFetch(
        `/oauth/disconnect?customer_id=${encodeURIComponent(customerId)}`,
        {
          method: "DELETE",
        },
      );
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(
          data.detail || "Could not disconnect the current profile.",
        );
      }

      toast.success("Current profile disconnected", {
        description:
          "Choose the Google Business Profile you want Trendit to manage next.",
      });

      // Keep the Trendit account/session, but force Google to run a fresh consent/discovery flow.
      localStorage.removeItem("trendit_location_id");
      localStorage.removeItem("trendit_business_name");
      window.location.href = `${BACKEND_URL}/oauth/google?state=switch-location`;
    } catch (error) {
      console.error("Switch location error:", error);
      toast.error(
        error instanceof Error ? error.message : "Could not switch business.",
      );
      setSwitching(false);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2"
          disabled={switching}
        >
          <RefreshCw size={14} />
          Switch Business
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="text-amber-500" size={20} />
            Switch your Google Business Profile?
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-3 pt-2">
            <span className="block">
              You are currently connected to{" "}
              <strong>{businessName || "your current business"}</strong>.
            </span>
            <span className="block">
              Switching will disconnect this profile from Trendit. Trendit will
              stop generating, auditing, and scheduling posts for it until you
              connect another profile.
            </span>
            <span className="block font-medium text-foreground">
              Your Trendit account, content profile, and posting history will be
              preserved. Any post already scheduled with Google may still
              publish at its scheduled time.
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={switching}>
            Keep Current Business
          </AlertDialogCancel>
          <AlertDialogAction onClick={handleSwitch} disabled={switching}>
            {switching ? "Switching…" : "Yes, Switch Business"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
