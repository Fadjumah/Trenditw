import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GoogleConnectButton } from "./google-connect-button";
import { useAuthState } from "@/hooks/use-auth-state";

export function PrimaryCTA({
  source,
  className,
  children,
  connectedMode = "dashboard",
  variant = "default",
  size = "lg",
}: {
  source?: string;
  className?: string;
  children?: ReactNode;
  connectedMode?: "dashboard" | "static";
  variant?: "outline" | "default" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
}) {
  const { hydrated, isAuthenticated } = useAuthState();

  if (!hydrated) return null;

  if (isAuthenticated && connectedMode === "static") {
    return (
      <span
        className={`inline-flex items-center gap-2 text-sm font-medium text-accent ${className ?? ""}`}
      >
        <CheckCircle2 size={16} /> Connected
      </span>
    );
  }

  if (isAuthenticated) {
    return (
      <Button asChild variant={variant} size={size} className={className}>
        <Link to="/dashboard">Go to Dashboard</Link>
      </Button>
    );
  }

  return (
    <GoogleConnectButton
      variant={variant}
      size={size}
      source={source}
      className={className}
    >
      {children}
    </GoogleConnectButton>
  );
}
