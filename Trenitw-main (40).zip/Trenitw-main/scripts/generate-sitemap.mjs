import { writeFileSync } from "node:fs";
import { resolve } from "node:path";

const SITE_URL = "https://trendexhub.com";
const lastmod = new Date().toISOString().slice(0, 10);
const pages = [
  ["/", "1.0", "daily"],
  ["/how-it-works", "0.9", "weekly"],
  ["/growth-partnership", "0.9", "weekly"],
  ["/get-listed", "0.9", "weekly"],
  ["/google-business-profile-management", "0.9", "weekly"],
  ["/google-business-profile-audit", "0.9", "weekly"],
  ["/google-business-profile-posts", "0.9", "weekly"],
  ["/local-seo-for-small-businesses", "0.9", "weekly"],
  ["/website-design", "0.8", "monthly"],
  ["/about", "0.7", "monthly"],
  ["/privacy", "0.3", "yearly"],
  ["/terms", "0.3", "yearly"],
];

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(([path, priority, changefreq]) => `  <url>\n    <loc>${SITE_URL}${path}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>${changefreq}</changefreq>\n    <priority>${priority}</priority>\n  </url>`).join("\n")}\n</urlset>\n`;

writeFileSync(resolve("public/sitemap.xml"), xml, "utf8");
console.log(`Generated sitemap with ${pages.length} canonical public URLs for ${lastmod}`);
