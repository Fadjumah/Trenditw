import React, { useEffect, useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import {
  ShieldCheck,
  Activity,
  RefreshCw,
  Mail,
  CheckCircle2,
  AlertCircle,
  Send,
  Loader2,
  Copy,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api";

export type AuditMessage = {
  ts: number;
  type: "thought" | "check" | "section" | "result" | "done" | "error";
  text: string;
  status?:
    | "pass"
    | "fail"
    | "warn"
    | "info"
    | "complete"
    | "completed_with_warnings"
    | "failed";
  detail?: string;
  progress_pct?: number;
};

export type FollowUpChat = {
  id: string;
  sender: "user" | "assistant";
  text: string;
  actionType?: "review_reply" | "post_draft" | "desc_update" | "photo_guide" | "plan_guide" | null;
  actionTitle?: string | null;
  actionContent?: string | null;
  actionCta?: string | null;
  executed?: boolean;
};

interface AuditChatModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  businessName?: string;
  auditId?: string | null;
  customerId?: string | null;
  locationId?: string | null;
  hasActiveSubscription?: boolean;
  auditStatus:
    "idle" | "running" | "complete" | "completed_with_warnings" | "failed";
  auditProgress: number;
  auditStep: string;
  auditMessages: AuditMessage[];
  auditResult: any;
  auditError: string | null;
  onStartAudit: () => void;
  onEmailReport: () => void;
  onReconnectGoogle?: () => void;
  onNavigateToReviews?: () => void;
  onGeneratePostDraft?: () => void;
  onRequireGrowthUpgrade?: (featureName: string) => void;
  emailingReport: boolean;
  reportEmailed: boolean;
  hasLocationId: boolean;
}

export function AuditChatModal({
  open,
  onOpenChange,
  businessName = "Your Business",
  auditId,
  customerId,
  locationId,
  hasActiveSubscription = false,
  auditStatus,
  auditProgress,
  auditStep,
  auditMessages,
  auditResult,
  auditError,
  onStartAudit,
  onEmailReport,
  onReconnectGoogle,
  onNavigateToReviews,
  onGeneratePostDraft,
  onRequireGrowthUpgrade,
  emailingReport,
  reportEmailed,
  hasLocationId,
}: AuditChatModalProps) {
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const [followUpChats, setFollowUpChats] = useState<FollowUpChat[]>([]);
  const [inputText, setInputText] = useState("");
  const [isSubmittingChat, setIsSubmittingChat] = useState(false);
  const [executingActionId, setExecutingActionId] = useState<string | null>(
    null,
  );

  // Auto-scroll to bottom of chat as new messages or responses arrive
  useEffect(() => {
    if (open) {
      chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [auditMessages, auditProgress, auditStatus, followUpChats, open]);

  // Extract the latest single thought for the whisper line
  const latestThought = React.useMemo(() => {
    for (let i = auditMessages.length - 1; i >= 0; i--) {
      if (auditMessages[i].type === "thought") {
        return auditMessages[i].text.replace(/\*\*/g, "").trim();
      }
    }
    return auditStep || "Analyzing profile data signals…";
  }, [auditMessages, auditStep]);

  // Handle follow-up chat submission or chip click
  const handleSendFollowUp = async (
    customPrompt?: string,
    actionType?: string,
  ) => {
    const messageToSend = customPrompt || inputText.trim();
    if (!messageToSend || isSubmittingChat) return;

    if (!customPrompt) {
      setInputText("");
    }

    const userMsgId = `user-${Date.now()}`;
    const assistantMsgId = `asst-${Date.now() + 1}`;

    setFollowUpChats((prev) => [
      ...prev,
      {
        id: userMsgId,
        sender: "user",
        text: messageToSend,
      },
    ]);

    setIsSubmittingChat(true);

    try {
      const targetAuditId = auditId || auditResult?.id;
      if (!targetAuditId) {
        setTimeout(() => {
          setFollowUpChats((prev) => [
            ...prev,
            {
              id: assistantMsgId,
              sender: "assistant",
              text: `Based on the diagnostic audit for **${businessName}**, focusing on fresh weekly updates and replying to every Google review with relevant local keywords will provide the fastest boost to your local rankings.`,
              actionType: actionType === "generate_post" ? "post_draft" : null,
              actionTitle:
                actionType === "generate_post"
                  ? "Publish Post to Google"
                  : null,
              actionContent:
                actionType === "generate_post"
                  ? `We're proud to serve our local community at ${businessName}! Visit us this week or check out our latest updates on Google Maps.`
                  : null,
              actionCta: "Publish to Google",
            },
          ]);
          setIsSubmittingChat(false);
        }, 600);
        return;
      }

      const res = await apiFetch(`/api/user/audit/${targetAuditId}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: messageToSend,
          action: actionType || null,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setFollowUpChats((prev) => [
          ...prev,
          {
            id: assistantMsgId,
            sender: "assistant",
            text:
              data.response ||
              "Here is the recommended optimization based on your audit.",
            actionType: data.action_type || null,
            actionTitle: data.action_title || null,
            actionContent: data.action_content || null,
            actionCta: data.action_cta || "Publish to Google",
          },
        ]);
      } else {
        throw new Error("Chat request failed");
      }
    } catch (e) {
      console.warn("Audit follow-up chat error:", e);
      let fallbackText = `Here is our diagnostic recommendation for **${businessName}**: focus on uploading fresh photos monthly and responding to every customer review with local service keywords to boost your Google Maps ranking.`;
      if (actionType === "photo_recommendations" || messageToSend.toLowerCase().includes("photo")) {
        fallbackText = `For **${businessName}**, Trendit generates compliant visual media and infographics adhering to Google privacy laws to eliminate visual stagnation and drive more patient calls.`;
      } else if (actionType === "draft_review_replies" || messageToSend.toLowerCase().includes("review")) {
        fallbackText = `For **${businessName}**, prompt review replies directly boost your local search pack placement. Trendit Autopilot drafts keyword-rich responses in 1-click.`;
      }
      setFollowUpChats((prev) => [
        ...prev,
        {
          id: assistantMsgId,
          sender: "assistant",
          text: fallbackText,
        },
      ]);
    } finally {
      setIsSubmittingChat(false);
    }
  };

  // 1-Click Execution Confirmation Handler
  const handleExecute1Click = async (chat: FollowUpChat) => {
    if (chat.executed || executingActionId) return;

    if (chat.actionType !== "post_draft") {
      if (chat.actionContent) {
        await navigator.clipboard.writeText(chat.actionContent);
        toast.success(`${chat.actionTitle || "Blueprint"} copied to clipboard!`);
        setFollowUpChats((prev) =>
          prev.map((c) => (c.id === chat.id ? { ...c, executed: true } : c)),
        );
      }
      return;
    }

    if (!hasActiveSubscription) {
      if (onRequireGrowthUpgrade) {
        onRequireGrowthUpgrade(
          chat.actionTitle || "1-Click Direct Google Publishing",
        );
      } else {
        toast.info("Growth Plan required for 1-click publishing to Google.", {
          description:
            "Subscribe to publish directly from the diagnostic panel.",
        });
      }
      return;
    }

    setExecutingActionId(chat.id);
    try {
      if (chat.actionType === "post_draft") {
        if (customerId && locationId) {
          const draftRes = await apiFetch("/api/user/generate-draft", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              customer_id: customerId,
              location_id: locationId,
              post_type: "standard",
              source: "dashboard",
            }),
          });

          if (draftRes.ok) {
            const draftData = await draftRes.json();
            if (draftData.post_id) {
              await apiFetch(`/api/user/approve-post/${draftData.post_id}`, {
                method: "POST",
              });
            }
          }
        }

        setFollowUpChats((prev) =>
          prev.map((c) => (c.id === chat.id ? { ...c, executed: true } : c)),
        );
        toast.success("Post scheduled to Google Maps & Search", {
          description:
            "Google will publish your update at the optimal scheduled time.",
        });
      } else {
        if (chat.actionContent) {
          await navigator.clipboard.writeText(chat.actionContent);
        }
        setFollowUpChats((prev) =>
          prev.map((c) => (c.id === chat.id ? { ...c, executed: true } : c)),
        );
        toast.success("Copied to clipboard & ready to publish");
      }
    } catch (err) {
      console.error("1-click action failed:", err);
      toast.error("Could not complete publishing action. Please try again.");
    } finally {
      setExecutingActionId(null);
    }
  };

  const scoreColor = (score?: number) => {
    if (!score && score !== 0) return "text-red-500";
    if (score >= 90) return "text-emerald-500";
    if (score >= 75) return "text-blue-500";
    if (score >= 60) return "text-amber-500";
    if (score >= 40) return "text-orange-500";
    return "text-red-500";
  };

  const scoreBg = (score?: number) => {
    if (!score && score !== 0) return "bg-red-500/10 border-red-500/30";
    if (score >= 90) return "bg-emerald-500/10 border-emerald-500/30";
    if (score >= 75) return "bg-blue-500/10 border-blue-500/30";
    if (score >= 60) return "bg-amber-500/10 border-amber-500/30";
    if (score >= 40) return "bg-orange-500/10 border-orange-500/30";
    return "bg-red-500/10 border-red-500/30";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="audit-assistant-editorial sm:max-w-2xl h-[90vh] sm:h-[82vh] max-h-[820px] p-0 flex flex-col gap-0 overflow-hidden border border-black/10 bg-[#f7f3eb] text-[#171512] rounded-3xl shadow-2xl">
        <DialogHeader className="px-5 sm:px-7 py-5 border-b border-black/10 bg-[#f7f3eb] flex flex-row items-center justify-between space-y-0 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-10 w-10 rounded-full border border-[#b64b25]/25 bg-[#e9ddd0] flex items-center justify-center text-[#b64b25] shrink-0">
              <ShieldCheck size={19} />
            </div>
            <div className="min-w-0">
              <DialogTitle className="font-serif text-2xl leading-none font-normal tracking-tight truncate">
                Diagnostic Assistant
              </DialogTitle>
              <DialogDescription className="mt-1 text-sm text-black/55 truncate">
                {businessName}
              </DialogDescription>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {auditResult && (
              <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${scoreBg(auditResult.overall_score)} ${scoreColor(auditResult.overall_score)}`}>
                {auditResult.overall_score}/100
              </span>
            )}
            <Button
              size="sm"
              onClick={onStartAudit}
              disabled={auditStatus === "running" || !hasLocationId}
              className="hidden sm:inline-flex h-9 rounded-full bg-[#171512] px-4 text-xs font-semibold text-white hover:bg-[#171512]/90"
            >
              {auditStatus === "running" ? (
                <><Loader2 className="mr-1.5 animate-spin" size={13} /> Auditing</>
              ) : auditResult ? (
                <><RefreshCw className="mr-1.5" size={13} /> Re-run</>
              ) : (
                <><Activity className="mr-1.5" size={13} /> Start audit</>
              )}
            </Button>
          </div>
        </DialogHeader>

        {auditStatus === "running" && (
          <div className="shrink-0 border-b border-[#b64b25]/15 bg-[#e9ddd0]/35 px-5 sm:px-7 py-3">
            <div className="flex items-center justify-between gap-4">
              <span className="min-w-0 truncate text-sm font-medium">
                {auditStep || latestThought || "Reviewing your Google Business Profile…"}
              </span>
              <span className="shrink-0 text-sm font-semibold text-[#b64b25]">{auditProgress}%</span>
            </div>
            <Progress value={auditProgress} className="mt-2 h-1.5 bg-black/10" />
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-5 sm:px-7 py-7" style={{ scrollbarWidth: "thin" }}>
          <div className="mx-auto max-w-xl space-y-7">
            <section className="rounded-3xl border border-black/10 bg-white p-6 sm:p-7">
              <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
                Google Business Profile
              </p>
              <h3 className="mt-3 font-serif text-3xl leading-tight font-normal">
                {auditStatus === "running"
                  ? "We're checking your profile."
                  : auditResult
                    ? "Your diagnostic is ready."
                    : "Let's check your profile."}
              </h3>
              <p className="mt-3 text-base leading-7 text-black/60">
                {auditStatus === "running"
                  ? latestThought || "Reviewing the information Google has for your business."
                  : auditResult
                    ? auditResult.summary_text || "Your profile review is complete."
                    : `We'll review the key profile factors that influence how customers discover ${businessName} on Google.`}
              </p>

              {!auditResult && auditStatus === "idle" && (
                <Button
                  onClick={onStartAudit}
                  disabled={!hasLocationId}
                  className="mt-6 h-11 rounded-full bg-[#171512] px-6 text-sm font-semibold text-white hover:bg-[#171512]/90"
                >
                  <Activity className="mr-2" size={15} />
                  Run profile audit
                </Button>
              )}
            </section>

            {auditStatus === "failed" && (
              <section className="rounded-3xl border border-[#b64b25]/25 bg-[#e9ddd0]/45 p-6">
                <div className="flex gap-3">
                  <AlertCircle className="mt-0.5 shrink-0 text-[#b64b25]" size={19} />
                  <div>
                    <h4 className="font-serif text-xl">The audit could not be completed.</h4>
                    <p className="mt-2 text-sm leading-6 text-black/60">
                      {auditError || "Google Business Profile could not be reached. Please try again."}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {onReconnectGoogle && (
                        <Button onClick={onReconnectGoogle} size="sm" className="rounded-full bg-[#171512] text-white">
                          <RefreshCw className="mr-1.5" size={13} /> Reconnect Google
                        </Button>
                      )}
                      <Button onClick={onStartAudit} size="sm" variant="outline" className="rounded-full border-black/15">
                        Try again
                      </Button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {auditResult && (
              <section className="space-y-5">
                <div className="flex flex-col gap-5 rounded-3xl border border-black/10 bg-white p-6 sm:p-7 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.14em] text-black/45">Profile score</p>
                    <div className={`mt-2 font-serif text-6xl leading-none font-normal ${scoreColor(auditResult.overall_score)}`}>
                      {auditResult.overall_score}
                      <span className="ml-2 text-base text-black/40">/ 100</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={onEmailReport}
                    disabled={emailingReport || reportEmailed}
                    className="rounded-full border-black/15"
                  >
                    <Mail className="mr-1.5" size={13} />
                    {reportEmailed ? "Report sent" : emailingReport ? "Sending…" : "Email report"}
                  </Button>
                </div>

              </section>
            )}

            {followUpChats.length > 0 && (
              <section className="space-y-4">
                <p className="text-sm font-semibold uppercase tracking-[0.14em] text-black/45">Conversation</p>
                {followUpChats.map((chat) => (
                  <div key={chat.id} className={chat.sender === "user" ? "flex justify-end" : "flex justify-start"}>
                    <div className={chat.sender === "user" ? "max-w-[88%] rounded-3xl rounded-br-md bg-[#171512] px-4 py-3 text-sm leading-6 text-white" : "max-w-[92%] rounded-3xl rounded-bl-md border border-black/10 bg-white px-5 py-4 text-sm leading-6"}>
                      <div className="whitespace-pre-wrap">{chat.text}</div>
                      {chat.sender === "assistant" && chat.actionContent && (
                        <div className="mt-4 rounded-2xl border border-black/10 bg-[#f7f3eb] p-4">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-semibold">{chat.actionTitle || "Recommended action"}</span>
                            <button
                              type="button"
                              onClick={async () => {
                                if (chat.actionContent) {
                                  await navigator.clipboard.writeText(chat.actionContent);
                                  toast.success("Copied to clipboard");
                                }
                              }}
                              className="text-xs font-medium text-[#b64b25]"
                            >
                              <Copy className="mr-1 inline" size={12} /> Copy
                            </button>
                          </div>
                          <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-black/65">{chat.actionContent}</p>
                          <div className="mt-4">
                            {chat.executed ? (
                              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700">
                                <CheckCircle2 size={13} />
                                {chat.actionType === "post_draft" ? "Published to Google" : "Copied"}
                              </span>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => handleExecute1Click(chat)}
                                disabled={executingActionId === chat.id}
                                className="rounded-full bg-[#171512] text-white"
                              >
                                {executingActionId === chat.id ? <Loader2 className="mr-1.5 animate-spin" size={13} /> : <ArrowRight className="mr-1.5" size={13} />}
                                {executingActionId === chat.id ? "Working…" : chat.actionCta || (chat.actionType === "post_draft" ? "Publish to Google" : "Use this")}
                              </Button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {isSubmittingChat && (
                  <div className="flex items-center gap-2 text-sm text-black/50">
                    <Loader2 className="animate-spin text-[#b64b25]" size={15} />
                    Preparing your answer…
                  </div>
                )}
                <div ref={chatBottomRef} />
              </section>
            )}
          </div>
        </div>

        <div className="shrink-0 border-t border-black/10 bg-[#f7f3eb] px-5 sm:px-7 py-4">
          <form onSubmit={(e) => { e.preventDefault(); handleSendFollowUp(); }} className="mx-auto flex max-w-xl items-center gap-2 rounded-full border border-black/10 bg-white p-1.5 pl-4">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about your audit…"
              disabled={isSubmittingChat || auditStatus === "running"}
              className="h-9 flex-1 border-0 bg-transparent px-0 text-sm shadow-none focus-visible:ring-0"
            />
            <Button
              type="submit"
              size="sm"
              disabled={!inputText.trim() || isSubmittingChat || auditStatus === "running"}
              className="h-9 w-9 rounded-full bg-[#171512] p-0 text-white"
            >
              {isSubmittingChat ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
            </Button>
          </form>
          <p className="mx-auto mt-2 max-w-xl text-center text-xs text-black/40">
            {auditStatus === "running" ? "The assistant will be available when the audit finishes." : "Ask a question about your audit."}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
