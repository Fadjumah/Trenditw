import React, { useState, useEffect, useMemo } from "react";
import {
  Clock,
  Calendar,
  Loader2,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { apiFetch } from "@/lib/api";

const QUICK_TIME_PRESETS = [
  { value: "07:00", label: "7:00 AM" },
  { value: "09:00", label: "9:00 AM" },
  { value: "12:00", label: "12:00 PM" },
  { value: "15:00", label: "3:00 PM" },
  { value: "18:00", label: "6:00 PM" },
];

const FREQUENCY_OPTIONS = [
  { value: "daily", label: "Every day (7 posts / week)" },
  { value: "5_per_week", label: "5 days per week" },
  { value: "4_per_week", label: "4 days per week" },
  { value: "3_per_week", label: "3 days per week" },
  { value: "2_per_week", label: "2 days per week" },
  { value: "1_per_week", label: "1 day per week" },
  { value: "custom", label: "Custom schedule" },
];

const DEFAULT_DAYS_FOR_FREQUENCY: Record<string, string[]> = {
  daily: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  "5_per_week": ["Mon", "Tue", "Wed", "Thu", "Fri"],
  "4_per_week": ["Mon", "Tue", "Thu", "Fri"],
  "3_per_week": ["Mon", "Wed", "Fri"],
  "2_per_week": ["Tue", "Thu"],
  "1_per_week": ["Wed"],
};

const WEEK_DAYS = [
  { short: "Mon", full: "Monday" },
  { short: "Tue", full: "Tuesday" },
  { short: "Wed", full: "Wednesday" },
  { short: "Thu", full: "Thursday" },
  { short: "Fri", full: "Friday" },
  { short: "Sat", full: "Saturday" },
  { short: "Sun", full: "Sunday" },
];

const COMMON_TIMEZONES = [
  { value: "UTC", label: "UTC (Coordinated Universal Time)" },
  // North America
  { value: "America/New_York", label: "New York / Eastern (EST/EDT, UTC-5/-4)" },
  { value: "America/Chicago", label: "Chicago / Central (CST/CDT, UTC-6/-5)" },
  { value: "America/Denver", label: "Denver / Mountain (MST/MDT, UTC-7/-6)" },
  { value: "America/Los_Angeles", label: "Los Angeles / Pacific (PST/PDT, UTC-8/-7)" },
  { value: "America/Anchorage", label: "Anchorage / Alaska (AKST/AKDT, UTC-9/-8)" },
  { value: "Pacific/Honolulu", label: "Honolulu / Hawaii (HST, UTC-10)" },
  { value: "America/Toronto", label: "Toronto / Canada Eastern (EST/EDT)" },
  { value: "America/Vancouver", label: "Vancouver / Canada Pacific (PST/PDT)" },
  { value: "America/Mexico_City", label: "Mexico City (CST, UTC-6)" },
  // South America
  { value: "America/Bogota", label: "Bogota / Colombia (COT, UTC-5)" },
  { value: "America/Sao_Paulo", label: "Sao Paulo / Brazil (BRT, UTC-3)" },
  { value: "America/Buenos_Aires", label: "Buenos Aires / Argentina (ART, UTC-3)" },
  // Europe
  { value: "Europe/London", label: "London / UK (GMT/BST, UTC+0/+1)" },
  { value: "Europe/Dublin", label: "Dublin / Ireland (GMT/IST, UTC+0/+1)" },
  { value: "Europe/Paris", label: "Paris / France (CET/CEST, UTC+1/+2)" },
  { value: "Europe/Berlin", label: "Berlin / Germany (CET/CEST, UTC+1/+2)" },
  { value: "Europe/Rome", label: "Rome / Italy (CET/CEST, UTC+1/+2)" },
  { value: "Europe/Madrid", label: "Madrid / Spain (CET/CEST, UTC+1/+2)" },
  { value: "Europe/Amsterdam", label: "Amsterdam / Netherlands (CET/CEST, UTC+1/+2)" },
  { value: "Europe/Athens", label: "Athens / Greece (EET/EEST, UTC+2/+3)" },
  // Africa
  { value: "Africa/Cairo", label: "Cairo / Egypt (EEST, UTC+2/+3)" },
  { value: "Africa/Johannesburg", label: "Johannesburg / South Africa (SAST, UTC+2)" },
  { value: "Africa/Lagos", label: "Lagos / Nigeria (WAT, UTC+1)" },
  { value: "Africa/Accra", label: "Accra / Ghana (GMT, UTC+0)" },
  { value: "Africa/Nairobi", label: "Nairobi / Kenya (EAT, UTC+3)" },
  { value: "Africa/Kampala", label: "Kampala / Uganda (EAT, UTC+3)" },
  { value: "Africa/Casablanca", label: "Casablanca / Morocco (WET/WEST, UTC+1)" },
  // Middle East
  { value: "Asia/Dubai", label: "Dubai / UAE (GST, UTC+4)" },
  { value: "Asia/Riyadh", label: "Riyadh / Saudi Arabia (AST, UTC+3)" },
  { value: "Asia/Jerusalem", label: "Jerusalem / Israel (IST/IDT, UTC+2/+3)" },
  { value: "Europe/Istanbul", label: "Istanbul / Turkey (TRT, UTC+3)" },
  // Asia
  { value: "Asia/Kolkata", label: "India / Mumbai / Delhi (IST, UTC+5:30)" },
  { value: "Asia/Karachi", label: "Karachi / Pakistan (PKT, UTC+5)" },
  { value: "Asia/Dhaka", label: "Dhaka / Bangladesh (BST, UTC+6)" },
  { value: "Asia/Bangkok", label: "Bangkok / Thailand (ICT, UTC+7)" },
  { value: "Asia/Jakarta", label: "Jakarta / Indonesia (WIB, UTC+7)" },
  { value: "Asia/Singapore", label: "Singapore (SGT, UTC+8)" },
  { value: "Asia/Hong_Kong", label: "Hong Kong (HKT, UTC+8)" },
  { value: "Asia/Tokyo", label: "Tokyo / Japan (JST, UTC+9)" },
  { value: "Asia/Seoul", label: "Seoul / South Korea (KST, UTC+9)" },
  // Oceania
  { value: "Australia/Sydney", label: "Sydney / Melbourne (AEST/AEDT, UTC+10/+11)" },
  { value: "Australia/Brisbane", label: "Brisbane / Queensland (AEST, UTC+10)" },
  { value: "Australia/Perth", label: "Perth / Western Australia (AWST, UTC+8)" },
  { value: "Pacific/Auckland", label: "Auckland / New Zealand (NZST/NZDT, UTC+12/+13)" },
];

interface AutopilotScheduleCardProps {
  customerId: string;
  locationId?: string | null;
  businessName?: string;
  hasAccess?: boolean;
  freeUsage?: {
    posts_30d?: number;
    posts_30d_limit?: number;
    posts_available?: boolean;
    next_post_reset_at?: string | null;
  } | null;
  onUpgradeRequired: () => void;
}

export function AutopilotScheduleCard({
  customerId,
  locationId,
  businessName,
  hasAccess = false,
  freeUsage = null,
  onUpgradeRequired,
}: AutopilotScheduleCardProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [autopilotEnabled, setAutopilotEnabled] = useState(false);
  const [postingTime, setPostingTime] = useState("09:00");
  const [postingTimezone, setPostingTimezone] = useState<string>("");
  const [postingFrequency, setPostingFrequency] = useState<string>("daily");
  const [postingDays, setPostingDays] = useState<string[]>([
    "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun",
  ]);
  const [nextScheduledPost, setNextScheduledPost] = useState<{
    next_run_local?: string;
    next_run_iso?: string;
    timezone?: string;
    is_today?: boolean;
  } | null>(null);

  const fetchSettings = async () => {
    if (!customerId) return;
    try {
      setLoading(true);
      const res = await apiFetch(`/api/user/schedule-settings/${customerId}`);
      if (res.ok) {
        const data = await res.json();
        setAutopilotEnabled(hasAccess && !freePostingLocked && (data.autopilot_enabled ?? false));
        setPostingTime(data.posting_time || "09:00");
        // Keep posting timezone empty if unconfigured (bias-free)
        setPostingTimezone(data.posting_timezone || "");
        setPostingFrequency(data.posting_frequency || "daily");
        setPostingDays(
          data.posting_days && data.posting_days.length > 0
            ? data.posting_days
            : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        );
        setNextScheduledPost(data.next_scheduled_post || null);
      }
    } catch (e) {
      console.error("Failed to load schedule settings:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [customerId, hasAccess, freeUsage?.posts_available]);

  const freePostingLocked =
    hasAccess &&
    !!freeUsage &&
    freeUsage.posts_available === false;
  const requireAccess = () => {
    if (!hasAccess) {
      onUpgradeRequired();
      return false;
    }
    if (freePostingLocked) {
      toast.info("Free posting limit reached", {
        description: "Your 10 autonomous posts for the current 30-day period are used. Posting will unlock automatically when the oldest post leaves the 30-day window.",
      });
      return false;
    }
    return true;
  };

  const saveSchedule = async (
    enabled: boolean,
    time: string,
    tz: string,
    freq: string,
    days: string[],
    silent = false
  ) => {
    if (!requireAccess()) return;

    try {
      setSaving(true);
      const res = await apiFetch("/api/user/schedule-settings", {
        method: "POST",
        body: JSON.stringify({
          customer_id: customerId,
          autopilot_enabled: enabled,
          posting_time: time,
          posting_timezone: tz || null,
          posting_frequency: freq,
          posting_days: days,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAutopilotEnabled(data.autopilot_enabled);
        setPostingTime(data.posting_time);
        setPostingTimezone(data.posting_timezone || "");
        setPostingFrequency(data.posting_frequency || freq);
        setPostingDays(data.posting_days || days);
        setNextScheduledPost(data.next_scheduled_post || null);

        if (typeof window !== "undefined") {
          window.dispatchEvent(
            new CustomEvent("trendit_schedule_updated", { detail: data })
          );
        }

        if (!silent) {
          if (enabled) {
            const daysLabel =
              freq === "daily" || days.length === 7
                ? "Daily"
                : `${days.join(", ")}`;
            const tzName = tz ? tz.split("/").pop()?.replace(/_/g, " ") : "UTC";
            toast.success("Autopilot Schedule Updated!", {
              description: `Posts will publish automatically on ${daysLabel} at ${formatTime(time)} (${tzName}).`,
            });
          } else {
            toast.info(tz ? "Settings Saved" : "Autopilot Paused", {
              description: tz
                ? `Preferred timezone set to ${tz.split("/").pop()?.replace(/_/g, " ")}.`
                : "Automated publishing is currently paused.",
            });
          }
        }
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err.detail || "Failed to update schedule settings.");
      }
    } catch (e) {
      toast.error("An error occurred while saving schedule.");
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = (checked: boolean) => {
    if (!requireAccess()) return;
    if (checked && !postingTimezone) {
      toast.error("Timezone Required", {
        description: "Please select your time zone before enabling Autopilot.",
      });
      return;
    }
    setAutopilotEnabled(checked);
    saveSchedule(checked, postingTime, postingTimezone, postingFrequency, postingDays);
  };

  const handleTimeChange = (newTime: string) => {
    if (!requireAccess()) return;
    setPostingTime(newTime);
    if (newTime && /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(newTime)) {
      saveSchedule(autopilotEnabled, newTime, postingTimezone, postingFrequency, postingDays);
    }
  };

  const handleTimezoneChange = (newTz: string) => {
    if (!requireAccess()) return;
    if (!newTz) return;
    setPostingTimezone(newTz);
    saveSchedule(autopilotEnabled, postingTime, newTz, postingFrequency, postingDays);
  };

  const handleFrequencyChange = (newFreq: string) => {
    if (!requireAccess()) return;
    setPostingFrequency(newFreq);
    let nextDays = postingDays;
    if (newFreq in DEFAULT_DAYS_FOR_FREQUENCY) {
      nextDays = DEFAULT_DAYS_FOR_FREQUENCY[newFreq];
      setPostingDays(nextDays);
    }
    saveSchedule(autopilotEnabled, postingTime, postingTimezone, newFreq, nextDays);
  };

  const handleToggleDay = (day: string) => {
    if (!requireAccess()) return;
    let nextDays: string[];
    if (postingDays.includes(day)) {
      if (postingDays.length <= 1) {
        toast.error("At least 1 posting day is required");
        return;
      }
      nextDays = postingDays.filter((d) => d !== day);
    } else {
      // Maintain natural Monday-to-Sunday order
      nextDays = WEEK_DAYS.map((w) => w.short).filter(
        (d) => postingDays.includes(d) || d === day
      );
    }

    // Determine matching preset or mark custom
    let nextFreq = "custom";
    if (nextDays.length === 7) {
      nextFreq = "daily";
    } else {
      const match = Object.entries(DEFAULT_DAYS_FOR_FREQUENCY).find(
        ([key, defaultDays]) =>
          key !== "daily" &&
          defaultDays.length === nextDays.length &&
          defaultDays.every((d) => nextDays.includes(d))
      );
      if (match) {
        nextFreq = match[0];
      }
    }

    setPostingDays(nextDays);
    setPostingFrequency(nextFreq);
    saveSchedule(autopilotEnabled, postingTime, postingTimezone, nextFreq, nextDays);
  };

  const formatTime = (timeStr: string) => {
    if (!timeStr) return "9:00 AM";
    const parts = timeStr.split(":");
    if (parts.length < 2) return timeStr;
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (isNaN(h) || isNaN(m)) return timeStr;
    const period = h >= 12 ? "PM" : "AM";
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const displayM = m < 10 ? `0${m}` : `${m}`;
    return `${displayH}:${displayM} ${period}`;
  };

  const timezoneOptions = useMemo(() => {
    const list = [...COMMON_TIMEZONES];
    if (postingTimezone && !list.some((t) => t.value === postingTimezone)) {
      return [{ value: postingTimezone, label: postingTimezone }, ...list];
    }
    return list;
  }, [postingTimezone]);

  return (
    <div
      id="autopilot-schedule-section"
      className="app-editorial autopilot-editorial rounded-3xl border border-black/10 dark:border-white/15 bg-card p-5 sm:p-6 shadow-none flex flex-col justify-between space-y-5"
    >
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-muted-foreground">
              Autopilot Engine
            </span>
            <span className="relative flex h-2 w-2">
              {autopilotEnabled ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </>
              ) : (
                <span className="relative inline-flex rounded-full h-2 w-2 bg-zinc-400"></span>
              )}
            </span>
          </div>

          <Badge
            variant="outline"
            className={
              autopilotEnabled
                ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-0 text-[11px] font-semibold"
                : "bg-muted text-muted-foreground border-0 text-[11px] font-semibold"
            }
          >
            {autopilotEnabled ? "Autopilot Active" : "Autopilot Off"}
          </Badge>
        </div>

        {/* Hero title & explanation */}
        <div className="space-y-1.5">
          <h3 className="font-serif text-lg font-bold text-foreground">
            Autonomous Google Posting
          </h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Trendit automatically generates fresh, high-impact posts tailored to your
            services and publishes them directly to your Google Business Profile on your schedule.
          </p>
        </div>

        {/* Live status alert card */}
        {loading ? (
          <div className="py-6 text-center space-y-2">
            <Loader2 className="animate-spin text-accent mx-auto" size={20} />
            <p className="text-xs text-muted-foreground">Loading schedule preferences…</p>
          </div>
        ) : (
          <div
            className={`p-4 rounded-2xl transition-colors space-y-3 ${
              autopilotEnabled
                ? "bg-emerald-500/[0.07] ring-1 ring-emerald-500/20 text-emerald-950 dark:text-emerald-200"
                : "bg-muted/30 text-muted-foreground"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock
                  size={16}
                  className={autopilotEnabled ? "text-emerald-500" : "text-muted-foreground"}
                />
                <span className="text-xs font-semibold">
                  {autopilotEnabled
                    ? "Next Scheduled Publication"
                    : "Automated Publishing Paused"}
                </span>
              </div>
              {saving && <Loader2 size={14} className="animate-spin text-muted-foreground" />}
            </div>

            {autopilotEnabled ? (
              <div className="space-y-2">
                <div>
                  <p className="text-sm font-bold text-foreground">
                    {nextScheduledPost?.next_run_local ||
                      `Scheduled at ${formatTime(postingTime)}`}
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Timezone: {postingTimezone ? (timezoneOptions.find((t) => t.value === postingTimezone)?.label || postingTimezone) : "Not selected"} ({nextScheduledPost?.is_today ? "Scheduled for today" : "Next scheduled run"})
                  </p>
                </div>

                {/* Active days indicator */}
                <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-emerald-500/10">
                  <span className="text-[10px] text-muted-foreground mr-1">Active days:</span>
                  {postingFrequency === "daily" || postingDays.length === 7 ? (
                    <Badge variant="outline" className="text-[10px] px-2 py-0 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-0">
                      Every day (7x / week)
                    </Badge>
                  ) : (
                    postingDays.map((d) => (
                      <span
                        key={d}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-mono font-medium"
                      >
                        {d}
                      </span>
                    ))
                  )}
                </div>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">
                Turn on Autopilot below to resume automated posting to your Google Business Profile.
              </p>
            )}
          </div>
        )}

        {!hasAccess && !loading && (
          <div className="rounded-2xl border border-[#b64b25]/20 bg-[#b64b25]/[0.06] p-4 space-y-3">
            <div>
              <p className="text-sm font-semibold text-foreground">Trendit Pro required</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Autopilot, posting time, posting frequency, posting days, and timezone settings are Pro features.
              </p>
            </div>
            <button
              type="button"
              onClick={onUpgradeRequired}
              className="inline-flex items-center justify-center rounded-full bg-[#171512] px-4 py-2 text-xs font-semibold text-white hover:bg-[#171512]/90"
            >
              Unlock Trendit Pro
            </button>
          </div>
        )}

        {freePostingLocked && !loading && (
          <div className="rounded-2xl bg-muted/40 p-4 space-y-2 opacity-70">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-foreground">Free posting limit reached</p>
              <Badge variant="outline" className="text-[10px] border-0 bg-muted text-muted-foreground">Paused</Badge>
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {freeUsage?.posts_30d ?? 10} / {freeUsage?.posts_30d_limit ?? 10} autonomous posts used in the last 30 days.
              {freeUsage?.next_post_reset_at ? " The oldest post will roll off automatically." : ""}
            </p>
          </div>
        )}

        {/* Schedule Controls */}
        <div className="space-y-4 pt-1">
          {/* Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-muted/30">
            <div className="space-y-0.5 pr-2">
              <label
                htmlFor="autopilot-switch"
                className="text-xs font-semibold text-foreground cursor-pointer"
              >
                Enable Autonomous Posting
              </label>
              <p className="text-[11px] text-muted-foreground">
                Publish localized updates automatically to Google on your chosen schedule
              </p>
            </div>
            <Switch
              id="autopilot-switch"
              checked={autopilotEnabled}
              onCheckedChange={handleToggle}
              disabled={saving || loading || freePostingLocked}
            />
          </div>

          {/* Frequency Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              Posting Frequency
            </label>
            <Select
              value={postingFrequency}
              onValueChange={handleFrequencyChange}
              disabled={saving || loading || !autopilotEnabled}
            >
              <SelectTrigger className="w-full h-9 text-xs bg-background">
                <SelectValue placeholder="Select Frequency" />
              </SelectTrigger>
              <SelectContent>
                {FREQUENCY_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value} className="text-xs">
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Posting Days Selection (shown when not daily) */}
          {postingFrequency !== "daily" ? (
            <div className="space-y-2.5 p-3.5 rounded-2xl bg-muted/30">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-semibold text-foreground flex items-center gap-1.5">
                  <Calendar size={13} className="text-accent" />
                  <span>Select Posting Days</span>
                </label>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-medium">
                  {postingDays.length} {postingDays.length === 1 ? "day" : "days"} selected
                </span>
              </div>
              <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
                {WEEK_DAYS.map(({ short, full }) => {
                  const isSelected = postingDays.includes(short);
                  return (
                    <button
                      key={short}
                      type="button"
                      disabled={saving || loading || !autopilotEnabled || !hasAccess}
                      onClick={() => handleToggleDay(short)}
                      title={full}
                      className={`h-8 sm:h-9 rounded-lg text-xs font-medium transition-all flex flex-col items-center justify-center cursor-pointer ${
                        isSelected
                          ? "bg-emerald-500 text-white font-bold shadow-xs"
                          : "bg-background/80 hover:bg-background text-muted-foreground"
                      } ${!autopilotEnabled ? "opacity-50 cursor-not-allowed" : ""}`}
                    >
                      <span>{short}</span>
                    </button>
                  );
                })}
              </div>
              <p className="text-[10px] text-muted-foreground">
                Days are interpreted in your selected local timezone.
              </p>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-muted/20 text-[11px] text-muted-foreground flex items-center gap-2">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>Posts will publish every day of the week (Monday through Sunday).</span>
            </div>
          )}

          {/* Time Picker & Timezone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Daily Posting Time */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="custom-posting-time"
                  className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider cursor-pointer"
                >
                  Posting Time
                </label>
                {postingTime && (
                  <span className="text-[11px] font-mono font-medium text-emerald-600 dark:text-emerald-400">
                    {formatTime(postingTime)}
                  </span>
                )}
              </div>
              <div className="relative">
                <Input
                  id="custom-posting-time"
                  type="time"
                  value={postingTime}
                  onChange={(e) => handleTimeChange(e.target.value)}
                  onBlur={() => {
                    if (
                      postingTime &&
                      /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(postingTime) &&
                      autopilotEnabled
                    ) {
                      saveSchedule(autopilotEnabled, postingTime, postingTimezone, postingFrequency, postingDays);
                    }
                  }}
                  disabled={saving || loading || !hasAccess}
                  className="w-full h-9 text-xs bg-background font-mono px-3"
                  step="60"
                />
              </div>
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] text-muted-foreground">Quick:</span>
                {QUICK_TIME_PRESETS.map((preset) => (
                  <button
                    key={preset.value}
                    type="button"
                    disabled={saving || loading || !hasAccess}
                    onClick={() => handleTimeChange(preset.value)}
                    className={`text-[10px] px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                      postingTime === preset.value
                        ? "bg-foreground text-background font-semibold"
                        : "bg-muted/40 hover:bg-muted text-muted-foreground"
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Timezone Picker */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                Your Timezone
              </label>
              <Select
                value={postingTimezone || undefined}
                onValueChange={handleTimezoneChange}
                disabled={saving || loading}
              >
                <SelectTrigger className={`w-full h-9 text-xs bg-background ${!postingTimezone ? "border-dashed border-amber-500/60 dark:border-amber-400/60 text-muted-foreground" : ""}`}>
                  <SelectValue placeholder="SELECT YOUR TIME ZONE" />
                </SelectTrigger>
                <SelectContent className="max-h-56">
                  {timezoneOptions.map((tz) => (
                    <SelectItem key={tz.value} value={tz.value} className="text-xs">
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground pt-1">
                {postingTimezone
                  ? `Selected: ${timezoneOptions.find((t) => t.value === postingTimezone)?.label || postingTimezone}`
                  : "Select your timezone to ensure posts publish at your desired local time."}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-3 border-t border-border/40">
        <div className="flex items-center justify-between text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Zap size={12} className="text-accent" />
            <span>Autonomous Mode</span>
          </span>
          <span>
            {postingFrequency === "daily" || postingDays.length === 7
              ? "Runs daily automatically"
              : `Runs ${postingDays.length}x per week automatically`}
          </span>
        </div>
      </div>
    </div>
  );
}
