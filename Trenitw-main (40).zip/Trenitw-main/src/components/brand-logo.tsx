import * as React from "react";
import { GoogleBarGraphIcon } from "./google-bar-graph-icon";

export interface BrandLogoProps extends React.HTMLAttributes<HTMLDivElement> {
  showWordmark?: boolean;
  theme?: "light" | "dark" | "auto";
  iconClassName?: string;
  textClassName?: string;
}

export function BrandLogo({
  showWordmark = true,
  theme = "auto",
  iconClassName = "h-8 w-8",
  textClassName = "",
  className = "",
  ...props
}: BrandLogoProps) {
  const textColor =
    theme === "light"
      ? "text-[#101820]"
      : theme === "dark"
      ? "text-white"
      : "text-[#101820] dark:text-white";

  return (
    <div
      className={`inline-flex items-center gap-2.5 ${className}`}
      {...props}
    >
      <GoogleBarGraphIcon className={`shrink-0 ${iconClassName}`} />
      {showWordmark && (
        <span
          className={`font-sans text-[22px] font-extrabold tracking-[-0.035em] leading-none select-none ${textColor} ${textClassName}`}
        >
          Trendit
        </span>
      )}
    </div>
  );
}
