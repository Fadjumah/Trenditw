import { useCallback, useEffect, useState } from "react";
import { ArrowDownRight, ArrowUpRight, Eye, Globe2, MapPin, Phone, RefreshCw } from "lucide-react";
import { apiFetch } from "@/lib/api";

type PerformanceData = {
  period?: { start?: string; end?: string; days?: number };
  totals?: Record<string, number>;
  change_percent?: Record<string, number | null>;
  unavailable_metrics?: string[];
};

type Props = { customerId: string; locationId?: string };

const metrics = [
  { key: "calls", label: "Calls", icon: Phone, description: "Call button clicks" },
  { key: "direction_requests", label: "Directions", icon: MapPin, description: "Direction requests" },
  { key: "website_clicks", label: "Website clicks", icon: Globe2, description: "Website clicks" },
  { key: "search_impressions", label: "Search views", icon: Eye, description: "Google Search impressions" },
  { key: "maps_impressions", label: "Maps views", icon: MapPin, description: "Google Maps impressions" },
] as const;

function formatPeriod(start?: string, end?: string) {
  if (!start || !end) return "Last 30 completed days";
  const fmt = (value: string) =>
    new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(value + "T12:00:00"));
  return fmt(start) + " – " + fmt(end);
}

export function BusinessPerformanceMetrics({ customerId, locationId }: Props) {
  const [data, setData] = useState<PerformanceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (manual = false) => {
    if (!customerId) return;
    manual ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      const params = locationId ? "?location_id=" + encodeURIComponent(locationId) : "";
      const response = await apiFetch("/api/user/performance/" + customerId + params);
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body?.detail || "Google performance data is unavailable right now.");
      }
      setData(await response.json());
    } catch (err) {
      console.error("Failed to load Google performance metrics:", err);
      setError(err instanceof Error ? err.message : "Google performance data is unavailable right now.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [customerId, locationId]);

  useEffect(() => { load(); }, [load]);

  const totals = data?.totals || {};
  const changes = data?.change_percent || {};

  return (
    <section className="rounded-3xl border border-black/10 dark:border-white/15 bg-card p-5 sm:p-7 shadow-none space-y-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-[10px] font-mono font-bold uppercase tracking-widest text-muted-foreground">Google performance</div>
          <h2 className="mt-1 font-serif text-xl sm:text-2xl font-bold text-foreground">Customer activity on Google</h2>
          <p className="mt-1 text-xs sm:text-sm text-muted-foreground">
            {data ? formatPeriod(data.period?.start, data.period?.end) + " · completed Google data" : "Calls, directions, website clicks and visibility from your Google Business Profile."}
          </p>
        </div>
        <button type="button" onClick={() => load(true)} disabled={loading || refreshing} className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border/60 text-muted-foreground hover:text-foreground hover:bg-muted/50 transition" title="Refresh Google performance">
          <RefreshCw size={14} className={refreshing ? "animate-spin" : ""} />
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {metrics.map((metric) => <div key={metric.key} className="h-28 rounded-2xl border border-border/50 bg-background/40 animate-pulse" />)}
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-muted-foreground">
          <p className="font-medium text-foreground">Google performance data is temporarily unavailable.</p>
          <p className="mt-1">{error}</p>
          <button type="button" onClick={() => load(true)} className="mt-3 inline-flex items-center gap-1.5 text-accent font-medium hover:underline"><RefreshCw size={12} /> Try again</button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            {metrics.map(({ key, label, icon: Icon, description }) => {
              const change = changes[key];
              return (
                <div key={key} className="rounded-2xl border border-border/50 bg-background/40 p-4">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-accent/10 text-accent"><Icon size={15} /></span>
                    {change !== null && change !== undefined && (
                      <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-muted-foreground">
                        {change >= 0 ? <ArrowUpRight size={11} /> : <ArrowDownRight size={11} />}
                        {Math.abs(change)}%
                      </span>
                    )}
                  </div>
                  <div className="mt-4 text-2xl font-bold tracking-tight text-foreground">{(totals[key] || 0).toLocaleString()}</div>
                  <div className="mt-0.5 text-xs font-semibold text-foreground">{label}</div>
                  <div className="mt-1 text-[10px] leading-snug text-muted-foreground">{description}</div>
                </div>
              );
            })}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-muted-foreground">
            <span>Compared with the preceding {data?.period?.days || 30} completed days.</span>
            <span>Source: Google Business Profile Performance API</span>
          </div>
          {data?.unavailable_metrics?.includes("BUSINESS_CONVERSATIONS") && (
            <p className="text-[10px] text-muted-foreground">
              Google Business Profile chat/message conversations are not shown because that metric is no longer reliably available through the Performance API.
            </p>
          )}
        </>
      )}
    </section>
  );
}
