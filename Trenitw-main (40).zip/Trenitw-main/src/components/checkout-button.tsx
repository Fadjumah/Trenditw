import React, { useState } from "react";
import { Checkout } from "@freemius/checkout";
import { Button } from "@/components/ui/button";
import { useAuthState } from "@/hooks/use-auth-state";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

declare global { interface Window { FS?: { Checkout: new (options: any) => { open: (options: any) => void | Promise<void> } } } }

interface FreemiusCheckoutButtonProps {
  planId?: string | number;
  pricingId?: string | number;
  billingCycle?: "monthly" | "annual" | "lifetime";
  trial?: boolean;
  isGrowthProgram?: boolean;
  allowGuest?: boolean;
  service?: "core" | "growth_program" | "gbp_setup" | "website_design";
  successPath?: string;
  userEmail?: string;
  className?: string;
  children?: React.ReactNode;
  variant?: "default" | "outline" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
  onSuccess?: (response?: any) => void;
  onUnauthenticated?: () => void;
  onClick?: () => boolean | Promise<boolean | void> | void;
}

export function FreemiusCheckoutButton({ planId, pricingId: pricingIdProp, billingCycle: billingCycleProp, trial = false, isGrowthProgram: isGrowthProgramProp = false, allowGuest = false, service = "core", successPath, userEmail, className, children, variant = "default", size = "lg", onSuccess, onUnauthenticated, onClick }: FreemiusCheckoutButtonProps) {
  const { email, customerId, token, isAuthenticated } = useAuthState();
  const [loading, setLoading] = useState(false);

  const handleOpenCheckout = async () => {
    if (onClick) { try { const canProceed = await onClick(); if (canProceed === false) return; } catch (err) { console.error("[Freemius] Pre-click validation error:", err); return; } }
    if (!allowGuest && (!isAuthenticated || !email)) { if (onUnauthenticated) return onUnauthenticated(); toast.error("Please get started by connecting your business."); return; }
    try {
      setLoading(true);
      const isGrowth = Boolean(isGrowthProgramProp || service === "growth_program");
      const prefix = service === "gbp_setup" ? "GBP_SETUP" : service === "website_design" ? "WEBSITE_DESIGN" : null;
      const serviceEnv = prefix ? { productId: (import.meta.env as any)[`VITE_FREEMIUS_${prefix}_PRODUCT_ID`], publicKey: (import.meta.env as any)[`VITE_FREEMIUS_${prefix}_PUBLIC_KEY`], planId: (import.meta.env as any)[`VITE_FREEMIUS_${prefix}_PLAN_ID`], pricingId: (import.meta.env as any)[`VITE_FREEMIUS_${prefix}_PRICING_ID`] } : null;
      const targetPlanId = planId ? String(planId) : isGrowth ? (import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PLAN_ID || "68083") : service === "gbp_setup" ? (serviceEnv?.planId || import.meta.env.VITE_FREEMIUS_GBP_SETUP_PLAN_ID || "65081") : service === "website_design" ? (serviceEnv?.planId || import.meta.env.VITE_FREEMIUS_WEBSITE_DESIGN_PLAN_ID || "") : (import.meta.env.VITE_FREEMIUS_GROWTH_PLAN_ID || "62230");
      const targetPricingId = pricingIdProp ? String(pricingIdProp) : isGrowth ? (import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRICING_ID || "89986") : service === "gbp_setup" ? (serviceEnv?.pricingId || import.meta.env.VITE_FREEMIUS_GBP_SETUP_PRICING_ID || "86491") : service === "website_design" ? (serviceEnv?.pricingId || import.meta.env.VITE_FREEMIUS_WEBSITE_DESIGN_PRICING_ID || "") : (import.meta.env.VITE_FREEMIUS_GROWTH_PRICING_ID || "83073");
      let config: any = null;
      try { const queryParams = new URLSearchParams(); if (isGrowth) queryParams.set("product", "growth_program"); else if (service === "gbp_setup") queryParams.set("product", "gbp_setup"); else if (service === "website_design") queryParams.set("product", "website_design"); if (targetPlanId) queryParams.set("plan_id", targetPlanId); const configRes = await fetch(`/api/checkout/config?${queryParams.toString()}`); if (configRes.ok) config = await configRes.json(); } catch (err) { console.warn("[Freemius] Failed to fetch server config, using env fallback:", err); }
      const growthProductId = import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRODUCT_ID || "39637";
      const growthPublicKey = import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PUBLIC_KEY || "pk_2e959d49f4d948eba6254d5cb101a";
      const growthPricingId = import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRICING_ID || "89986";
      const coreProductId = import.meta.env.VITE_FREEMIUS_PRODUCT_ID || "37245";
      const corePublicKey = import.meta.env.VITE_FREEMIUS_PUBLIC_KEY || "pk_40c56495e18eb307b90c34e86e552";
      const corePricingId = import.meta.env.VITE_FREEMIUS_GROWTH_PRICING_ID || "83073";
      const productId = isGrowth ? (config?.product_id === growthProductId ? config.product_id : growthProductId) : service === "gbp_setup" ? (serviceEnv?.productId || import.meta.env.VITE_FREEMIUS_GBP_SETUP_PRODUCT_ID || coreProductId) : service === "website_design" ? (serviceEnv?.productId || import.meta.env.VITE_FREEMIUS_WEBSITE_DESIGN_PRODUCT_ID || coreProductId) : (config?.product_id && config.product_id !== growthProductId ? config.product_id : coreProductId);
      const publicKey = isGrowth ? (config?.public_key?.startsWith("pk_") && config.product_id === productId ? config.public_key : growthPublicKey) : service === "gbp_setup" ? (serviceEnv?.publicKey || import.meta.env.VITE_FREEMIUS_GBP_SETUP_PUBLIC_KEY || corePublicKey) : service === "website_design" ? (serviceEnv?.publicKey || import.meta.env.VITE_FREEMIUS_WEBSITE_DESIGN_PUBLIC_KEY || corePublicKey) : (config?.public_key?.startsWith("pk_") && config.product_id === productId ? config.public_key : corePublicKey);
      const activePlanId = isGrowth ? (config?.plan_id && config.product_id === productId ? config.plan_id : (targetPlanId || "68083")) : (service === "core" && config?.plan_id && config.product_id === productId ? config.plan_id : targetPlanId);
      const activePricingId = isGrowth ? (config?.pricing_id && config.product_id === productId ? config.pricing_id : growthPricingId) : (service === "core" && config?.pricing_id && config.product_id === productId ? config.pricing_id : targetPricingId);
      if (!publicKey || !productId || !activePlanId) { toast.error("Checkout is currently unavailable. Please reach out via WhatsApp or phone for immediate assistance."); setLoading(false); return; }
      const effectiveBillingCycle = billingCycleProp || (service === "website_design" || service === "gbp_setup" ? "lifetime" : "monthly");
      const customerEmail = userEmail || email || undefined;
      const checkoutOptions: Record<string, any> = { product_id: productId, plugin_id: productId, plan_id: activePlanId, currency: "usd", public_key: publicKey, ...(activePricingId ? { pricing_id: activePricingId } : {}), ...(customerEmail ? { user_email: customerEmail } : {}), image: "https://trendexhub.com/favicon.png?v=2", billing_cycle: effectiveBillingCycle, show_confirmation_dialog: false, ...(trial || config?.trial ? { trial: true } : {}) };
      if (config?.sandbox) checkoutOptions.sandbox = { token: config.sandbox.token, ctx: config.sandbox.ctx };
      const handlePurchaseCompleted = async (response: any) => {
        // Freemius documents purchaseCompleted as a successful purchase/trial
        // completion callback. Never treat the checkout being opened/closed as
        // success, and never unlock the app from client-side state alone.
        const completedPurchase = response?.purchase || response?.trial;
        const licenseId =
          response?.purchase?.license_id ||
          response?.trial?.license_id ||
          response?.subscription?.license_id ||
          response?.license?.id;
        const purchaseEmail =
          customerEmail ||
          response?.user?.email ||
          response?.purchase?.user_email ||
          response?.license?.user_email;

        if (!completedPurchase || !licenseId) {
          toast.info("Checkout not completed", {
            description: "No subscription was activated. Complete checkout to unlock Trendit Pro.",
          });
          return;
        }

        let syncData: any = null;
        try {
          const syncRes = await fetch("/api/purchase", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify({
              license_id: String(licenseId),
              customer_id: customerId || undefined,
              email: purchaseEmail || undefined,
              plan_id: activePlanId,
            }),
          });
          syncData = await syncRes.json().catch(() => null);
        } catch (e) {
          console.warn("[Freemius] Immediate entitlement sync failed; webhook may finalize sync.", e);
        }

        // The local entitlement mirror is the access-control source of truth.
        // Do not redirect/unlock unless the purchase was actually verified and
        // the entitlement is active.
        if (!syncData?.success || !syncData?.synced || !syncData?.entitlement) {
          toast.error("Checkout could not be verified yet", {
            description: "Your checkout was not unlocked locally. Please wait for activation and try again.",
          });
          return;
        }

        const resolvedCustomerId = customerId || syncData?.customer_id || null;
        if (!resolvedCustomerId) {
          toast.error("Checkout could not be linked to your Trendit account", {
            description: "No authenticated Trendit customer was returned, so access remains locked.",
          });
          return;
        }

        try {
          const entitlementRes = await fetch(`/api/user/entitlement/${resolvedCustomerId}`, {
            headers: token ? { Authorization: `Bearer ${token}` } : undefined,
          });
          const entitlement = entitlementRes.ok ? await entitlementRes.json() : null;
          if (!entitlement?.has_access) {
            toast.error("Checkout activation is still pending", {
              description: "Trendit did not receive an active entitlement yet, so premium features remain locked.",
            });
            return;
          }
        } catch {
          toast.error("Checkout activation could not be verified", {
            description: "Trendit will keep your account locked until the purchase is verified.",
          });
          return;
        }

        const completionPayload = {
          ...(response || {}),
          ...(resolvedCustomerId ? { customer_id: resolvedCustomerId } : {}),
          license_id: String(licenseId),
          service,
        };

        if (isGrowth) {
          toast.success("Growth Program billing setup saved!");
          if (onSuccess) onSuccess(completionPayload);
          else if (resolvedCustomerId) {
            window.location.href = `/growth-baseline?customer_id=${encodeURIComponent(resolvedCustomerId)}`;
          } else {
            window.location.href = "/manage-connection?growth_enrolled=1";
          }
          return;
        }

        const serviceTitle =
          service === "gbp_setup"
            ? "Google Business Profile Setup"
            : service === "website_design"
              ? "Trendit Website Design"
              : "Trendit Subscription";
        toast.success("Checkout completed!", {
          description: `Your ${serviceTitle} has been verified and activated.`,
        });
        if (onSuccess) onSuccess(completionPayload);
        else if (successPath) window.location.href = successPath;
        else window.location.reload();
      };
      const openParams = { name: isGrowth ? "Google Business Growth Program" : service === "gbp_setup" ? "Google Business Profile Setup" : service === "website_design" ? "Trendit Website Design" : "Business", licenses: 1, purchaseCompleted: handlePurchaseCompleted, success: (response: any) => console.log("[Freemius] Checkout closed after successful purchase:", response) };
      if (typeof window !== "undefined" && window.FS?.Checkout) { const handler = new window.FS.Checkout(checkoutOptions); handler.open(openParams); } else { const checkout = new Checkout(checkoutOptions as any); await checkout.open(openParams); }
    } catch (err: any) { console.error("Error opening checkout:", err); toast.error(err?.message || "Could not open checkout. Please try again."); } finally { setLoading(false); }
  };
  return <Button variant={variant} size={size} onClick={handleOpenCheckout} disabled={loading} className={className}>{loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Loading checkout…</> : (children ?? "Continue to Secure Checkout")}</Button>;
}
