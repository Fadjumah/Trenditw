import { Phone, Mail } from "lucide-react";
import { WhatsAppIcon } from "@/components/social-icons";
import {
  CONTACT_PHONE_1,
  CONTACT_PHONE_1_RAW,
  WHATSAPP_LINK,
  WHATSAPP_NUMBER,
  CONTACT_EMAIL,
} from "@/lib/seo";
import { track } from "@/lib/analytics";

interface ContactCtaBannerProps {
  /** Page/section this renders on, for analytics attribution. */
  source: string;
  heading?: string;
  subheading?: string;
}

/**
 * A loud, unmissable "just call us" block for pages meant to generate
 * inbound calls/WhatsApp messages rather than pure self-serve signups.
 */
export function ContactCtaBanner({
  source,
  heading = "Prefer to just talk it through?",
  subheading = "Call or WhatsApp us directly — no forms, no waiting.",
}: ContactCtaBannerProps) {
  return (
    <div className="dark-surface rounded-3xl border border-white/15 bg-[#171512] px-6 py-9 sm:px-12 sm:py-12 text-center text-white shadow-none">
      <h3 className="font-serif text-2xl sm:text-3xl font-medium tracking-tight text-white mb-2.5">
        {heading}
      </h3>
      <p className="text-sm sm:text-base text-white/65 mb-7 max-w-md mx-auto leading-relaxed">
        {subheading}
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <a
          href={`tel:${CONTACT_PHONE_1_RAW}`}
          onClick={() => track("contact_call_click", { source })}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-full bg-[#b64b25] px-7 py-3.5 text-sm sm:text-base font-semibold text-white shadow-none hover:bg-[#a03f1d] transition-colors min-h-[48px]"
        >
          <Phone size={18} />
          Call {CONTACT_PHONE_1}
        </a>
        <a
          href={WHATSAPP_LINK}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => track("contact_whatsapp_click", { source })}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-full bg-[#25D366] px-7 py-3.5 text-sm sm:text-base font-semibold text-white shadow-none hover:bg-[#20bd5a] transition-colors min-h-[48px]"
        >
          <WhatsAppIcon className="h-[18px] w-[18px]" />
          WhatsApp {WHATSAPP_NUMBER}
        </a>
      </div>
      <a
        href={`mailto:${CONTACT_EMAIL}`}
        onClick={() => track("contact_email_click", { source })}
        className="mt-5 inline-flex items-center justify-center gap-1.5 text-xs sm:text-sm text-white/60 hover:text-white transition-colors"
      >
        <Mail size={14} />
        {CONTACT_EMAIL}
      </a>
    </div>
  );
}
