import { useState } from "react";
import { CheckCircle2, Sparkles, ArrowRight } from "lucide-react";
import { FreemiusCheckoutButton } from "@/components/checkout-button";
import { useAuthState } from "@/hooks/use-auth-state";
import { GBP_SETUP_OFFER, getGbpSetupPlanId } from "@/lib/gbp-setup-offer";
import { track } from "@/lib/analytics";

interface GbpSetupOfferCardProps {
  /** Where this card is rendered, for analytics attribution. */
  source: string;
}

export function GbpSetupOfferCard({ source }: GbpSetupOfferCardProps) {
  const { customerId, email: authEmail } = useAuthState();
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="flex flex-col p-5 sm:p-6 rounded-2xl border-2 border-emerald-600 bg-emerald-50 text-card-foreground shadow-none items-center text-center">
        <CheckCircle2 size={32} className="text-emerald-600 mb-3" />
        <h3 className="text-lg sm:text-xl font-semibold mb-1.5 text-emerald-950">
          Order received!
        </h3>
        <p className="text-xs sm:text-sm text-emerald-900 leading-relaxed">
          We're preparing your Google Business Profile setup. Check your email — we'll keep you posted and reach out shortly to collect any specific details we need from you.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col p-5 sm:p-6 rounded-2xl border-2 border-[#b64b25] bg-[#b64b25]/5 text-card-foreground shadow-none">
      <div className="mb-3 sm:mb-4 flex items-center justify-between">
        <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-full bg-[#b64b25]/20 flex items-center justify-center text-[#b64b25]">
          <Sparkles size={20} className="sm:hidden" />
          <Sparkles size={24} className="hidden sm:block" />
        </div>
        <span className="text-xs font-semibold uppercase tracking-wide text-white bg-[#b64b25] rounded-full px-3 py-1">
          Done for you
        </span>
      </div>
      <h3 className="text-lg sm:text-xl font-semibold mb-1.5 sm:mb-2">
        I need to create one
      </h3>
      <p className="text-xs sm:text-sm text-muted-foreground mb-1 leading-relaxed">
        {GBP_SETUP_OFFER.description}
      </p>
      <div className="flex items-baseline gap-2 my-3">
        <span className="text-2xl font-bold">${GBP_SETUP_OFFER.price}</span>
        <span className="text-sm text-muted-foreground line-through">
          ${GBP_SETUP_OFFER.originalPrice}
        </span>
        <span className="text-xs text-muted-foreground">one-time</span>
      </div>
      <ul className="text-xs sm:text-sm text-muted-foreground mb-6 space-y-2">
        {GBP_SETUP_OFFER.features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-accent" />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      <FreemiusCheckoutButton
        service="gbp_setup"
        planId={getGbpSetupPlanId()}
        pricingId={import.meta.env.VITE_FREEMIUS_GBP_SETUP_PRICING_ID || "86491"}
        userEmail={authEmail || undefined}
        allowGuest
        successPath={`/get-listed?ordered=1`}
        onClick={() => {
          track("gbp_setup_checkout_started", {
            source,
            user_id: customerId || undefined,
          });
          return true;
        }}
        onSuccess={() => {
          setDone(true);
        }}
        className="w-full text-xs sm:text-sm min-h-[44px] bg-[#b64b25] hover:bg-[#a03f1d] text-white rounded-full font-semibold shadow-none flex items-center justify-center gap-2"
      >
        <span>{GBP_SETUP_OFFER.ctaText}</span>
        <ArrowRight size={15} />
      </FreemiusCheckoutButton>
      <p className="text-[11px] text-muted-foreground mt-2.5 text-center">
        {GBP_SETUP_OFFER.turnaround}
      </p>
    </div>
  );
}
