import * as React from "react";

export function GoogleBarGraphIcon({
  className = "h-4 w-4",
  ...props
}: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
      {...props}
    >
      {/* Bar 1: Google Blue */}
      <rect x="2.5" y="11" width="3.5" height="7" rx="1" fill="#4285F4" />
      {/* Bar 2: Google Yellow */}
      <rect x="8.25" y="7" width="3.5" height="11" rx="1" fill="#FBBC05" />
      {/* Bar 3: Google Green */}
      <rect x="14" y="3" width="3.5" height="15" rx="1" fill="#34A853" />
    </svg>
  );
}
