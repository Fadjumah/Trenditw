import { Button } from "@/components/ui/button";
import { track } from "@/lib/analytics";
import { BACKEND_URL } from "@/lib/api";

export function GoogleConnectButton({
  className,
  variant = "outline",
  size = "lg",
  state,
  children,
  source,
  forceReauth = false,
}: {
  className?: string;
  variant?:
    | "outline"
    | "default"
    | "secondary"
    | "ghost"
    | "destructive"
    | "link";
  size?: "default" | "sm" | "lg" | "icon";
  state?: string;
  children?: React.ReactNode;
  source?: string;
  /** Skip the "already have a customer_id -> go to dashboard" shortcut and
   * always relaunch the Google consent screen. Use this for any "try again"
   * / "reconnect" / "connect a different account" button. */
  forceReauth?: boolean;
}) {
  const handleConnect = () => {
    const cid = typeof window !== "undefined" ? localStorage.getItem("trendit_customer_id") : null;
    const page = typeof window !== "undefined" ? window.location.pathname : undefined;

    track("connect_google_click", { source: source ?? "unknown", page, user_id: cid || undefined });
    track("business_connection_started", { connection_method: "google_oauth", source: source ?? "unknown", user_id: cid || undefined });

    // track() creates the stable anonymous visitor ID. Mark this exact browser
    // visitor as being in an auth flow before leaving for Google's consent page.
    if (typeof window !== "undefined") {
      try {
        const visitorId = localStorage.getItem("trendit_visitor_id");
        if (visitorId) localStorage.setItem("trendit_pending_auth_visitor_id", visitorId);
        localStorage.setItem("trendit_pending_auth_at", String(Date.now()));
      } catch {
        // Analytics state must never block authentication.
      }
    }

    // A saved customer ID only proves that a previous Trendit session exists.
    // It must not silently bypass Google authorization.
    let url = `${BACKEND_URL}/oauth/google`;
    if (state) url += `?state=${encodeURIComponent(state)}`;
    window.location.href = url;
  };

  return (
    <Button onClick={handleConnect} variant={variant} size={size} className={`flex items-center gap-3 font-medium transition-all hover:bg-muted/50 ${className}`}>
      <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
        <path fill="#4285F4" d="M17.64 9.2c0-.63-.06-1.25-.16-1.84H9v3.49h4.84c-.21 1.12-.84 2.07-1.79 2.71v2.25h2.91c1.7-1.57 2.68-3.88 2.68-6.61z" />
        <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.91-2.25c-.81.54-1.85.87-3.05.87-2.34 0-4.33-1.58-5.03-3.71H.95v2.33C2.43 15.89 5.5 18 9 18z" />
        <path fill="#FBBC05" d="M3.97 10.73c-.18-.54-.28-1.12-.28-1.73s.1-1.19.28-1.73V4.94H.95C.35 6.16 0 7.54.95 4.06l3.02 2.33z" />
        <path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58C13.47.89 11.43 0 9 0 5.5 0 2.43 2.11.95 4.94L3.97 7.27C4.67 5.14 6.66 3.58 9 3.58z" />
      </svg>
      {children || "Connect your business"}
    </Button>
  );
}
