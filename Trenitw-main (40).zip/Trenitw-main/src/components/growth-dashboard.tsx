import { useCallback, useEffect, useState } from "react";
import { ArrowUpRight, BarChart3, Loader2, LockKeyhole, RefreshCw, TrendingDown, TrendingUp, Clock3 } from "lucide-react";
import { apiFetch } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type BaselineStatus = {
  status?: string;
  maturity?: string;
  complete_months_available?: number;
  period_start?: string;
  period_end?: string;
  baseline_metrics?: Record<string, number | null>;
};

type GrowthReport = {
  business_name?: string;
  period: { current_start: string; current_end: string; baseline_start: string; baseline_end: string; elapsed_days: number };
  baseline: Record<string, number | boolean>;
  baseline_labels?: Record<string, string>;
  metric_details?: Record<string, any>;
  baseline_mtd: Record<string, number>;
  current: Record<string, number>;
  change: Record<string, number>;
  change_percent: Record<string, number | null>;
  managed: boolean;
  billing: { performance_rate_usd: number; growth_threshold_calls: number; monthly_cap_usd: number; incremental_calls: number; calculated_fee_usd: number; fee_usd: number; status: string };
};

function fmt(value: number) { return Number.isInteger(value) ? value.toString() : value.toFixed(1); }
function maturityText(value?: string, monthsAvailable?: number) {
  if (value === "standard" || monthsAvailable === 3) return "3-month average";
  if (value === "provisional_2_month" || monthsAvailable === 2) return "2-month average";
  if (value === "provisional_1_month" || monthsAvailable === 1) return "Based on 1 month of actual data";
  return "Building baseline";
}


function MetricCard({ label, current, baseline, change, percent }: { label: string; current: number; baseline: number; change: number; percent: number | null }) {
  const positive = change >= 0;
  return <Card className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] shadow-none"><CardContent className="p-6 space-y-3"><div className="flex items-center justify-between gap-3"><span className="text-xs font-semibold text-black/60 dark:text-white/60">{label}</span>{percent !== null && <Badge variant="outline" className={positive ? "border-emerald-500/30 text-emerald-700 dark:text-emerald-400 bg-emerald-500/5 rounded-full" : "border-destructive/30 text-destructive bg-destructive/5 rounded-full"}>{positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}{positive ? "+" : ""}{percent}%</Badge>}</div><div className="flex items-end justify-between gap-3"><div><div className="font-serif text-3xl sm:text-4xl font-bold text-[#171512] dark:text-white">{fmt(current)}</div><div className="text-[11px] text-black/50 dark:text-white/50">this month to date</div></div><div className="text-right text-[11px] text-black/60 dark:text-white/60"><div>Baseline MTD</div><div className="font-semibold text-[#171512] dark:text-white">{fmt(baseline)}</div><div className={positive ? "text-emerald-700 dark:text-emerald-400" : "text-destructive"}>{positive ? "+" : ""}{fmt(change)}</div></div></div></CardContent></Card>;
}

export function GrowthDashboard({ customerId, locationId }: { customerId: string; locationId?: string }) {
  const [baseline, setBaseline] = useState<BaselineStatus | null>(null);
  const [report, setReport] = useState<GrowthReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (manual = false) => {
    if (!customerId) return;
    manual ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      const query = locationId ? `?location_id=${encodeURIComponent(locationId)}` : "";
      const baselineRes = await apiFetch(`/api/user/growth-baseline/${encodeURIComponent(customerId)}${query}`);
      const baselineData = await baselineRes.json().catch(() => ({}));
      if (!baselineRes.ok) throw new Error(baselineData?.detail || "Unable to load your Growth Program baseline");
      setBaseline(baselineData);
      if (baselineData.status !== "confirmed") {
        setReport(null);
        return;
      }
      const response = await apiFetch(`/api/user/growth/${encodeURIComponent(customerId)}${query}`);
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data?.detail || "Unable to load Google performance data");
      setReport(data);
    } catch (e: any) {
      setError(e?.message || "Unable to load Google growth data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [customerId, locationId]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] p-10 flex items-center justify-center gap-3 text-sm text-black/60 dark:text-white/60 shadow-none"><Loader2 className="animate-spin text-[#b64b25]" size={17} /> Loading Growth Program data…</div>;

  if (error) return <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] p-8 space-y-4 shadow-none"><div className="font-semibold text-[#171512] dark:text-white">Growth tracking is not available yet</div><p className="text-sm text-black/65 dark:text-white/70 max-w-xl">{error}</p><Button variant="outline" onClick={() => load(true)} disabled={refreshing} className="gap-2 rounded-full border border-black/15 dark:border-white/20"><RefreshCw size={14} className={refreshing ? "animate-spin" : ""} /> Retry</Button></div>;

  if (!baseline || baseline.status !== "confirmed" || !report) {
    return <div className="app-editorial growth-dashboard-editorial space-y-6 pt-1"><div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4"><div className="space-y-1.5"><div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25] dark:text-[#f3a37f]">Google Growth</div><h2 className="font-serif text-3xl sm:text-4xl text-[#171512] dark:text-white">Establish your starting point first.</h2><p className="text-sm text-black/65 dark:text-white/70 max-w-2xl">Trendit uses your actual Google Business Profile history. The current partial month is excluded, and newer profiles receive a transparent provisional baseline instead of invented data.</p></div><Button variant="outline" size="sm" onClick={() => load(true)} disabled={refreshing} className="gap-2 rounded-full border border-black/15 dark:border-white/20"><RefreshCw size={13} className={refreshing ? "animate-spin" : ""} /> Refresh</Button></div><Card className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] shadow-none"><CardContent className="p-7 sm:p-9"><div className="flex gap-4"><div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#b64b25]/10 text-[#b64b25]"><Clock3 size={19} /></div><div><div className="text-xs font-semibold uppercase tracking-wider text-[#b64b25]">Baseline status</div><h3 className="mt-1 font-serif text-2xl text-[#171512] dark:text-white">{maturityText(baseline.maturity, baseline.complete_months_available)}</h3><p className="mt-2 text-sm leading-6 text-black/60 dark:text-white/65">{baseline.maturity === "collecting_history" || (baseline.complete_months_available || 0) === 0 ? "Not enough complete historical data yet. Trendit will establish the baseline as more GBP performance data becomes available." : "Your historical months have been calculated. Review the month-by-month figures and confirm the baseline to lock the Growth Program starting point."}</p><div className="mt-4 flex flex-wrap gap-2 text-xs text-black/55 dark:text-white/55"><Badge variant="outline" className="rounded-full">{baseline.complete_months_available || 0} complete month{baseline.complete_months_available === 1 ? "" : "s"} available</Badge>{baseline.period_start && <Badge variant="outline" className="rounded-full">{baseline.period_start} → {baseline.period_end}</Badge>}</div><Button onClick={() => { window.location.href = `/growth-baseline?customer_id=${encodeURIComponent(customerId)}${locationId ? `&location_id=${encodeURIComponent(locationId)}` : ""}`; }} className="mt-6 rounded-full bg-[#171512] text-white hover:bg-black/90">Review baseline <ArrowUpRight size={15} /></Button></div></div></CardContent></Card></div>;
  }

  const periodLabel = `${new Date(report.period.current_start).toLocaleDateString(undefined, { month: "short", day: "numeric" })}–${new Date(report.period.current_end).toLocaleDateString(undefined, { month: "short", day: "numeric" })}`;
  const baselineLabel = `${new Date(report.period.baseline_start).toLocaleDateString(undefined, { month: "short", year: "numeric" })} – ${new Date(report.period.baseline_end).toLocaleDateString(undefined, { month: "short", year: "numeric" })}`;

  return <div className="app-editorial growth-dashboard-editorial space-y-8 pt-1"><div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4"><div className="space-y-1.5"><div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25] dark:text-[#f3a37f]">Google Growth</div><h2 className="font-serif text-3xl sm:text-4xl text-[#171512] dark:text-white">Baseline → measurable growth.</h2><p className="text-sm text-black/65 dark:text-white/70 max-w-2xl">Google Business Profile performance is compared against the locked enrollment baseline. The baseline itself never moves after confirmation.</p></div><Button variant="outline" size="sm" onClick={() => load(true)} disabled={refreshing} className="gap-2 shrink-0 rounded-full border border-black/15 dark:border-white/20"><RefreshCw size={13} className={refreshing ? "animate-spin" : ""} /> Refresh</Button></div><div className="grid gap-4 md:grid-cols-3"><MetricCard label="Google calls" current={report.current.calls} baseline={report.baseline_mtd.calls} change={report.change.calls} percent={report.change_percent.calls} /><MetricCard label="Website clicks" current={report.current.website_clicks} baseline={report.baseline_mtd.website_clicks} change={report.change.website_clicks} percent={report.change_percent.website_clicks} /><MetricCard label="Direction requests" current={report.current.direction_requests} baseline={report.baseline_mtd.direction_requests} change={report.change.direction_requests} percent={report.change_percent.direction_requests} /></div><div className="grid gap-6 lg:grid-cols-[1.25fr_.75fr]"><Card className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] shadow-none"><CardHeader><CardTitle className="text-base flex items-center gap-2 font-serif text-[#171512] dark:text-white"><BarChart3 size={18} className="text-[#b64b25] dark:text-[#f3a37f]" /> Locked baseline</CardTitle></CardHeader><CardContent className="space-y-4"><div className="grid grid-cols-3 gap-3"><div className="rounded-2xl bg-black/[0.02] dark:bg-white/5 p-4"><div className="text-[10px] uppercase tracking-wide text-black/50 dark:text-white/50">Calls</div><div className="font-serif text-2xl font-bold">{fmt(Number(report.baseline.calls))}</div><div className="text-[10px] text-black/50 dark:text-white/50">{report.baseline_labels?.calls || maturityText(baseline.maturity, baseline.complete_months_available)}</div></div><div className="rounded-2xl bg-black/[0.02] dark:bg-white/5 p-4"><div className="text-[10px] uppercase tracking-wide text-black/50 dark:text-white/50">Website</div><div className="font-serif text-2xl font-bold">{fmt(Number(report.baseline.website_clicks))}</div><div className="text-[10px] text-black/50 dark:text-white/50">{report.baseline_labels?.website_clicks || maturityText(baseline.maturity, baseline.complete_months_available)}</div></div><div className="rounded-2xl bg-black/[0.02] dark:bg-white/5 p-4"><div className="text-[10px] uppercase tracking-wide text-black/50 dark:text-white/50">Directions</div><div className="font-serif text-2xl font-bold">{fmt(Number(report.baseline.direction_requests))}</div><div className="text-[10px] text-black/50 dark:text-white/50">{report.baseline_labels?.direction_requests || maturityText(baseline.maturity, baseline.complete_months_available)}</div></div></div><div className="flex flex-wrap items-center gap-2 text-xs text-black/60 dark:text-white/60"><LockKeyhole size={13} className="text-[#b64b25] dark:text-[#f3a37f]" /> Baseline locked · {baselineLabel} · {maturityText(baseline.maturity, baseline.complete_months_available)}</div><div className="text-[11px] text-black/50 dark:text-white/50">Current measurement: {periodLabel} · {report.period.elapsed_days} completed day(s)</div></CardContent></Card><Card className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] shadow-none"><CardHeader><CardTitle className="text-base font-serif">Growth Partnership</CardTitle></CardHeader><CardContent className="space-y-4">{report.managed ? <><div className="rounded-2xl bg-[#b64b25]/5 border border-[#b64b25]/15 p-4 space-y-2"><div className="text-xs font-semibold text-[#b64b25] dark:text-[#f3a37f]">Performance fee</div><div className="font-serif text-3xl font-bold">${report.billing.fee_usd.toFixed(2)}</div><div className="text-[11px] text-black/60 dark:text-white/60">Calculated from the agreed incremental-growth metric. Final billing remains pending until the measurement period is complete.</div></div><div className="grid grid-cols-2 gap-3 text-xs"><div><span className="text-black/50 dark:text-white/50">Rate</span><div className="font-semibold">${report.billing.performance_rate_usd.toFixed(2)} / call</div></div><div><span className="text-black/50 dark:text-white/50">Monthly cap</span><div className="font-semibold">${report.billing.monthly_cap_usd.toFixed(2)}</div></div></div><Badge variant="outline" className="w-fit rounded-full">{report.billing.status === "pending_month_end" ? "Pending month end" : "Ready"}</Badge></> : <><div className="rounded-2xl bg-black/[0.02] dark:bg-white/5 p-4 space-y-2"><div className="text-sm font-semibold">Not a managed client</div><p className="text-xs leading-relaxed text-black/60 dark:text-white/60">This account is currently using Trendit as software. Trendexhub's performance-based Growth Partnership can be activated separately.</p></div><a href="/growth-partnership" className="inline-flex items-center gap-2 text-xs font-semibold text-[#b64b25] dark:text-[#f3a37f] hover:underline">Explore managed growth <ArrowUpRight size={13} /></a></>}</CardContent></Card></div></div>;

}
