import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Check, CheckCircle2, TrendingUp } from "lucide-react";
import { FreemiusCheckoutButton } from "@/components/checkout-button";
import { PRICING_PLANS, getFreemiusPlanIdForTier } from "@/lib/pricing-plans";

interface GrowthUpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  description?: string;
  highlightFeature?: string;
  onSuccess?: () => void;
}

/**
 * Contextual upgrade modal with a mini-selector across all 3 paid tiers.
 */
export function GrowthUpgradeModal({
  open,
  onOpenChange,
  title = "Unlock Trendit Pro",
  description = "Take your Google Business Profile to the next level with automated daily activity and smart review management.",
  highlightFeature,
  onSuccess,
}: GrowthUpgradeModalProps) {
  const proTier = PRICING_PLANS[0];
  const activeFreemiusPlanId = getFreemiusPlanIdForTier(proTier);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] p-6 sm:p-7 bg-[#f7f3eb] border border-black/10 text-[#171512] rounded-3xl shadow-2xl">
        <DialogHeader className="text-left space-y-2 pb-3 border-b border-black/10 dark:border-white/10">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-[#b64b25]/15 text-[#b64b25]">
              <TrendingUp size={18} />
            </span>
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#b64b25]">
              30-Day Free Trial
            </span>
          </div>

          <DialogTitle className="font-serif text-2xl sm:text-[26px] tracking-tight font-semibold text-[#171512] dark:text-[#f7f3eb]">
            {title}
          </DialogTitle>

          <DialogDescription className="text-xs sm:text-sm text-[#514b45] dark:text-[#c4bebb] leading-relaxed">
            {description}
          </DialogDescription>
        </DialogHeader>

        {highlightFeature && (
          <div className="rounded-2xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/10 p-3 flex items-center gap-2.5 text-xs font-medium text-[#171512] dark:text-[#f7f3eb]">
            <CheckCircle2 size={15} className="text-[#b64b25] shrink-0" />
            <span>
              <strong>Action required:</strong> {highlightFeature}
            </span>
          </div>
        )}

        {/* Pro Plan Card */}
        <div className="my-2 rounded-2xl border-2 border-[#b64b25] bg-white/80 dark:bg-[#201d19] p-4 text-left">
          <div className="flex items-center justify-between">
            <div>
              <span className="inline-block rounded-full bg-[#b64b25] text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5">
                30 Days Free
              </span>
              <h4 className="mt-1 text-lg font-bold font-serif text-[#171512] dark:text-[#f7f3eb]">
                {proTier.name}
              </h4>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-[#171512] dark:text-[#f7f3eb]">
                ${proTier.price}
                <span className="text-xs font-normal text-[#514b45] dark:text-[#c4bebb]">
                  {proTier.period}
                </span>
              </div>
              <p className="text-[10px] text-[#b64b25] font-semibold">after 30-day free trial</p>
            </div>
          </div>
          <div className="mt-3 space-y-1.5 border-t border-black/10 dark:border-white/10 pt-3 text-xs text-[#514b45] dark:text-[#c4bebb]">
            {proTier.features.slice(0, 4).map((benefit) => (
              <div key={benefit} className="flex items-start gap-2">
                <Check size={13} className="text-[#b64b25] shrink-0 mt-0.5" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action */}
        <div className="pt-2">
          <FreemiusCheckoutButton
            service="core"
            planId={activeFreemiusPlanId}
            billingCycle="monthly"
            trial={true}
            variant="default"
            size="lg"
            successPath="/dashboard"
            onSuccess={() => {
              onOpenChange(false);
              onSuccess?.();
            }}
            className="w-full justify-center rounded-full bg-[#b64b25] hover:bg-[#a03f1d] text-white py-3 text-xs sm:text-sm font-semibold shadow-none"
          >
            Start 30-Day Free Trial (then $29/mo)
          </FreemiusCheckoutButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}
