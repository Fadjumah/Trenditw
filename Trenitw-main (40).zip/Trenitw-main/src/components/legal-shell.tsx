import type { ReactNode } from "react";
import { SiteNav } from "./site-nav";
import { SiteFooter } from "./site-footer";

export function LegalShell({ title, effective, updated, children }: { title: string; effective: string; updated: string; children: ReactNode }) {
  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f7f3eb] text-[#171512]">
      <SiteNav />
      <main className="mx-auto max-w-[1000px] px-5 py-12 sm:px-8 sm:py-16 lg:py-20">
        <div className="mb-8 rounded-[28px] border border-black/[0.07] bg-white/75 p-7 sm:p-10">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-[#b64b25]">Legal</div>
          <h1 className="font-serif text-4xl leading-[1.02] tracking-tight sm:text-5xl md:text-6xl">{title}</h1>
          <p className="mt-4 text-xs sm:text-sm text-black/55">Effective date: {effective} · Last updated: {updated}</p>
        </div>
        <div className="space-y-8 text-sm leading-relaxed text-black/75 sm:text-[15px]">{children}</div>
      </main>
      <SiteFooter />
    </div>
  );
}

export function LegalSection({ number, title, children }: { number: number; title: string; children: ReactNode }) {
  return (
    <section className="rounded-[24px] border border-black/[0.07] bg-white p-6 sm:p-8">
      <h2 className="font-serif text-2xl tracking-tight text-[#171512] sm:text-3xl">{number}. {title}</h2>
      <div className="mt-4 space-y-3">{children}</div>
    </section>
  );
}

export function Callout({ children }: { children: ReactNode }) {
  return <div className="rounded-[20px] border border-[#ffb98e]/25 bg-[#fff2e8] p-5 text-sm leading-relaxed sm:p-7">{children}</div>;
}

export function LegalList({ items }: { items: ReactNode[] }) {
  return <ul className="list-disc space-y-2 pl-5 marker:text-[#b64b25]">{items.map((item, i) => <li key={i}>{item}</li>)}</ul>;
}
