import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { GrowthUpgradeModal } from "@/components/growth-upgrade-modal";
import { apiFetch } from "@/lib/api";
import { toast } from "sonner";
import {
  Building2,
  Loader2,
  Store,
  CheckCircle2,
  ArrowRight,
  Lock,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface LocationItem {
  location_id: string;
  business_name: string;
  address?: string | null;
  account_id?: string | null;
}

interface ManageConnectionProps {
  customerId: string;
  businessName?: string;
  currentLocationId?: string;
  hasAccess?: boolean;
}

/**
 * High-converting location management component.
 * Allows users to discover all connected Google Business Profile locations.
 * Free-tier users are restricted to 1 active location and prompted with
 * high-converting upgrade CTAs to subscribe to Growth for multi-location switching.
 */
export function ManageConnection({
  customerId,
  businessName,
  currentLocationId,
  hasAccess = false,
}: ManageConnectionProps) {
  const [loading, setLoading] = useState(false);
  const [locations, setLocations] = useState<LocationItem[]>([]);
  const [locationsModalOpen, setLocationsModalOpen] = useState(false);
  const [noOtherModalOpen, setNoOtherModalOpen] = useState(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [upgradeTargetLoc, setUpgradeTargetLoc] = useState<LocationItem | null>(null);
  const [switchingId, setSwitchingId] = useState<string | null>(null);

  const handleViewOtherProfiles = async () => {
    setLoading(true);
    try {
      const res = await apiFetch(`/oauth/locations?customer_id=${customerId}`);
      if (res.ok) {
        const data = await res.json();
        const list: LocationItem[] = data.locations || [];

        if (list.length <= 1) {
          toast.info("No other locations exist for your account.", {
            description: `You are currently viewing your only connected Google Business Profile${
              businessName ? ` (${businessName})` : ""
            }.`,
          });
          setNoOtherModalOpen(true);
        } else {
          setLocations(list);
          setLocationsModalOpen(true);
        }
        return;
      }

      if (res.status === 401 || res.status === 404) {
        toast.error("Unable to load profiles. Please verify your Google Business connection.");
      } else {
        toast.error("Failed to retrieve locations. Please try again.");
      }
    } catch (err) {
      console.error("Failed to fetch locations:", err);
      toast.error("Network error while checking profile locations.");
    } finally {
      setLoading(false);
    }
  };

  const handleSwitchProfile = async (loc: LocationItem) => {
    if (loc.location_id === currentLocationId) {
      toast.info(`"${loc.business_name}" is already your active profile.`);
      return;
    }

    // Free Tier Conversion Gate:
    // Free tier users can only connect 1 location. Block switching and trigger upgrade modal.
    if (!hasAccess) {
      setUpgradeTargetLoc(loc);
      setUpgradeModalOpen(true);
      return;
    }

    setSwitchingId(loc.location_id);
    try {
      const res = await apiFetch("/oauth/select-location", {
        method: "POST",
        body: JSON.stringify({
          customer_id: customerId,
          location_id: loc.location_id,
          business_name: loc.business_name,
          account_id: loc.account_id || null,
        }),
      });

      if (res.status === 402) {
        // Backend entitlement paywall hit
        setUpgradeTargetLoc(loc);
        setUpgradeModalOpen(true);
        return;
      }

      if (res.ok) {
        const data = await res.json();
        toast.success(`Switched active profile to ${loc.business_name}`);
        if (typeof window !== "undefined") {
          localStorage.setItem("trendit_location_id", loc.location_id);
          localStorage.setItem("trendit_business_name", loc.business_name);
          if (data.session_token) {
            localStorage.setItem("trendit_token", data.session_token);
          }
        }
        window.location.href = `/dashboard?customer_id=${encodeURIComponent(
          customerId
        )}&location_id=${encodeURIComponent(loc.location_id)}`;
        return;
      }

      const errText = await res.text();
      toast.error(`Could not switch profile: ${errText || "Unknown error"}`);
    } catch (err) {
      toast.error(
        "Failed to switch profile: " +
          (err instanceof Error ? err.message : String(err))
      );
    } finally {
      setSwitchingId(null);
    }
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="gap-1.5 text-xs h-8 px-2.5 sm:px-3 border-accent/40 hover:bg-accent/10 text-foreground font-medium"
        onClick={handleViewOtherProfiles}
        disabled={loading}
        title="View other locations or profiles under this Google account"
      >
        {loading ? (
          <Loader2 size={13} className="text-accent shrink-0 animate-spin" />
        ) : (
          <Building2 size={13} className="text-accent shrink-0" />
        )}
        <span>{loading ? "Checking Profiles…" : "View Other Profiles"}</span>
      </Button>

      {/* Multiple Profiles Modal (with conversion paywall for Free tier) */}
      <Dialog open={locationsModalOpen} onOpenChange={setLocationsModalOpen}>
        <DialogContent className="max-w-md p-6">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl">
              Your Google Business Profiles
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              We found {locations.length} locations on your account.
              {hasAccess
                ? " Select a profile to switch your active workspace."
                : " Free accounts can only connect 1 location."}
            </DialogDescription>
          </DialogHeader>

          {/* High-Converting Upgrade Banner for Free Tier Users */}
          {!hasAccess && (
            <div className="rounded-2xl border border-accent/30 bg-gradient-to-br from-accent/15 via-accent/5 to-transparent p-4 text-foreground space-y-2.5 shadow-2xs">
              <div className="flex items-center gap-2">
                <span className="grid h-6 w-6 place-items-center rounded-lg bg-accent text-accent-foreground font-bold text-xs">
                  <Sparkles size={13} />
                </span>
                <span className="text-[11px] font-bold uppercase tracking-wider text-accent">
                  Trendit Pro Feature
                </span>
              </div>
              <div className="space-y-1">
                <h4 className="font-serif text-sm sm:text-base font-semibold text-foreground">
                  Multi-Location Profile Switching
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  You have <strong className="text-foreground">{locations.length} connected locations</strong>. Free tier accounts can only manage 1 profile. Upgrade to Trendit Pro to unlock instant profile switching and automated daily growth across all your locations.
                </p>
              </div>
              <Button
                variant="default"
                size="sm"
                className="w-full justify-center rounded-full bg-accent text-accent-foreground hover:bg-accent/90 text-xs font-semibold h-9 shadow-xs"
                onClick={() => {
                  setUpgradeTargetLoc(null);
                  setUpgradeModalOpen(true);
                }}
              >
                <Sparkles size={13} className="mr-1.5" />
                Upgrade to Pro — 30 Days Free (then $29/mo)
              </Button>
            </div>
          )}

          <div className="max-h-64 overflow-y-auto space-y-2.5 my-2 pr-1">
            {locations.map((loc) => {
              const isActive =
                loc.location_id === currentLocationId ||
                (businessName && loc.business_name === businessName);

              return (
                <div
                  key={loc.location_id}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-xl border transition-colors",
                    isActive
                      ? "bg-accent/5 border-accent/40 shadow-xs"
                      : "bg-card border-border hover:border-accent/30"
                  )}
                >
                  <div className="min-w-0 flex-1 pr-3">
                    <div className="flex items-center gap-2">
                      <Store
                        size={14}
                        className={isActive ? "text-accent" : "text-muted-foreground"}
                      />
                      <h4 className="text-xs sm:text-sm font-semibold text-foreground truncate">
                        {loc.business_name}
                      </h4>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">
                      {loc.address || "Storefront address not provided"}
                    </p>
                  </div>

                  <div className="shrink-0">
                    {isActive ? (
                      <Badge
                        variant="secondary"
                        className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20 text-[10px] px-2.5 py-0.5 font-medium"
                      >
                        Active Profile
                      </Badge>
                    ) : !hasAccess ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs font-medium border-accent/40 bg-accent/5 text-accent hover:bg-accent hover:text-accent-foreground gap-1.5 cursor-pointer"
                        onClick={() => {
                          setUpgradeTargetLoc(loc);
                          setUpgradeModalOpen(true);
                        }}
                      >
                        <Lock size={11} className="shrink-0" />
                        <span>Upgrade to Switch</span>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs font-medium border-accent/40 hover:bg-accent hover:text-accent-foreground gap-1"
                        disabled={switchingId === loc.location_id}
                        onClick={() => handleSwitchProfile(loc)}
                      >
                        {switchingId === loc.location_id ? (
                          <Loader2 size={11} className="animate-spin" />
                        ) : (
                          <>
                            <span>Switch</span>
                            <ArrowRight size={11} />
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <DialogFooter className="flex-row items-center justify-between gap-2 pt-2 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground h-8 px-2"
              onClick={() => {
                const locsJson = JSON.stringify(locations);
                const locsB64 = btoa(encodeURIComponent(locsJson));
                window.location.href = `/location-picker?customer_id=${customerId}&locations=${locsB64}&active_location_id=${
                  currentLocationId || ""
                }`;
              }}
            >
              Open Full Picker
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-8 text-xs"
              onClick={() => setLocationsModalOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Single Location Informational Dialog */}
      <Dialog open={noOtherModalOpen} onOpenChange={setNoOtherModalOpen}>
        <DialogContent className="max-w-sm p-6 text-center sm:text-left">
          <div className="flex flex-col items-center sm:items-start gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-accent/10 text-accent">
              <CheckCircle2 size={20} />
            </div>
            <DialogHeader>
              <DialogTitle className="font-serif text-lg">
                No Other Locations Found
              </DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground">
                No other locations exist for your account.
              </DialogDescription>
            </DialogHeader>
          </div>

          <div className="rounded-xl border border-border bg-card p-3.5 text-xs text-muted-foreground my-2">
            <p className="leading-relaxed">
              Your Google account is currently associated with only one active business
              profile:{" "}
              <strong className="text-foreground font-semibold">
                {businessName || "your business"}
              </strong>
              . No additional locations are available to switch to.
            </p>
          </div>

          <DialogFooter className="sm:justify-end pt-2">
            <Button
              variant="default"
              size="sm"
              className="h-8 text-xs px-4"
              onClick={() => setNoOtherModalOpen(false)}
            >
              Got it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* High-Converting Growth Upgrade Modal */}
      <GrowthUpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
        title="Unlock Multi-Location Switching"
        description="Free tier accounts are limited to 1 connected business location. Upgrade to Trendit Pro to switch profiles and manage all your locations from a single dashboard."
        highlightFeature={
          upgradeTargetLoc
            ? `Switch active profile to "${upgradeTargetLoc.business_name}"`
            : "Multi-location workspace management"
        }
        onSuccess={() => {
          setUpgradeModalOpen(false);
          toast.success("Welcome to Trendit Pro! Refreshing workspace...");
          window.location.reload();
        }}
      />
    </>
  );
}
