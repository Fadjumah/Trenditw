import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";

interface OnboardingReviewProps {
  answers: any;
  onSubmit: () => void;
}

export function OnboardingReview({ answers, onSubmit }: OnboardingReviewProps) {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="space-y-2">
        <h2 className="text-2xl font-serif">One last check</h2>
        <p className="text-muted-foreground">
          Review your business details and preferences. We'll use them to tailor
          your Google Business Profile updates and review responses.
        </p>
      </div>

      <div className="space-y-4 rounded-lg bg-muted/50 p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-8">
          <div>
            <Label className="text-xs text-muted-foreground uppercase tracking-wider">
              Category
            </Label>
            <p className="font-medium">
              {answers.category === "Other"
                ? answers.customCategory
                : answers.category || "Not selected"}
            </p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground uppercase tracking-wider">
              Brand Tone
            </Label>
            <p className="font-medium">{answers.tone || "Not selected"}</p>
          </div>
          <div className="col-span-1 sm:col-span-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-wider">
              Top Services
            </Label>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {(answers.services || []).length > 0 ? (
                answers.services.map((s: string) => (
                  <Badge key={s} variant="secondary">
                    {s}
                  </Badge>
                ))
              ) : (
                <span className="text-sm text-muted-foreground">
                  None selected
                </span>
              )}
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground uppercase tracking-wider">
              Target Audience
            </Label>
            <p className="font-medium">
              {answers.targetCustomer || "Not selected"}
            </p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground uppercase tracking-wider">
              Promotions
            </Label>
            <p className="font-medium">{answers.promos || "Not selected"}</p>
          </div>
          {answers.customPromo && (
            <div className="col-span-1 sm:col-span-2">
              <Label className="text-xs text-muted-foreground uppercase tracking-wider">
                Current Promo Focus
              </Label>
              <p className="font-medium">{answers.customPromo}</p>
            </div>
          )}
        </div>
      </div>

      <Button
        onClick={onSubmit}
        className="w-full h-14 text-lg bg-foreground text-background hover:bg-foreground/90 shadow-lg hover:shadow-xl transition-all"
      >
        <CheckCircle2 size={18} className="mr-2" /> Complete Onboarding
      </Button>
    </div>
  );
}
