import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight } from "lucide-react";
import { Question, Option } from "./onboardingQuestions";

interface OnboardingStepProps {
  question: Question;
  answers: any;
  onAnswer: (id: string, value: any) => void;
  onNext: () => void;
}

export function OnboardingStep({
  question,
  answers,
  onAnswer,
  onNext,
}: OnboardingStepProps) {
  const options = question.dynamicOptions
    ? question.dynamicOptions(answers)
    : question.options || [];

  const currentValue = answers[question.id];

  const handleSelect = (value: string) => {
    if (question.type === "single-select") {
      onAnswer(question.id, value);
      onNext();
    } else if (question.type === "multi-select") {
      const current = (currentValue as string[]) || [];
      const updated = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value];
      onAnswer(question.id, updated);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="space-y-2">
        <h2 className="text-2xl font-serif">{question.title}</h2>
        <p className="text-muted-foreground">{question.description}</p>
      </div>

      {question.type === "text" ? (
        <div className="space-y-4">
          <Input
            placeholder="Type your answer..."
            value={currentValue || ""}
            onChange={(e) => onAnswer(question.id, e.target.value)}
            className="h-14"
            autoFocus
          />
          <Button onClick={onNext} className="w-full h-12">
            Continue <ChevronRight size={16} className="ml-2" />
          </Button>
        </div>
      ) : (
        <div
          className={
            question.type === "single-select"
              ? "grid grid-cols-1 sm:grid-cols-2 gap-3"
              : "flex flex-wrap gap-2"
          }
        >
          {options.map((option: Option) => {
            const isSelected =
              question.type === "single-select"
                ? currentValue === option.value
                : ((currentValue as string[]) || []).includes(option.value);

            return (
              <button
                key={option.value}
                onClick={() => handleSelect(option.value)}
                className={
                  question.type === "single-select"
                    ? `p-4 text-left rounded-xl border-2 transition-all hover:border-accent ${
                        isSelected
                          ? "border-accent bg-accent/5"
                          : "border-border"
                      }`
                    : `px-4 py-2 rounded-full border-2 transition-all ${
                        isSelected
                          ? "border-accent bg-accent text-accent-foreground"
                          : "border-border hover:border-muted-foreground"
                      }`
                }
              >
                <span className="font-medium">{option.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {question.type === "multi-select" && (
        <div className="pt-4">
          <Button
            onClick={onNext}
            disabled={!currentValue || (currentValue as string[]).length === 0}
            className="w-full h-12"
          >
            Next <ChevronRight size={16} className="ml-2" />
          </Button>
        </div>
      )}
    </div>
  );
}
