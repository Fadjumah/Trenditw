import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { onboardingQuestions, Question } from "./onboardingQuestions";
import { OnboardingStep } from "./OnboardingStep";
import { OnboardingReview } from "./OnboardingReview";

interface OnboardingWizardProps {
  onComplete: (answers: any) => void;
  connected?: boolean;
}

export function OnboardingWizard({
  onComplete,
  connected,
}: OnboardingWizardProps) {
  const [stepIndex, setStepIndex] = useState(0);
  const [answers, setAnswers] = useState<any>({
    category: "",
    services: [],
    tone: "",
    targetCustomer: "",
    promos: "",
  });

  // Flat list of questions to handle follow-ups easily
  const questions: Question[] = [];
  onboardingQuestions.forEach((q) => {
    questions.push(q);
    if (q.followUp && answers[q.id]) {
      const showFollowUp = q.followUp.is
        ? answers[q.id] === q.followUp.is
        : answers[q.id] !== q.followUp.isNot;

      if (showFollowUp) {
        questions.push(q.followUp.question);
      }
    }
  });

  const isLastStep = stepIndex >= questions.length;
  const currentQuestion = questions[stepIndex];
  const totalSteps = questions.length + 1;
  const progress = isLastStep ? 100 : ((stepIndex + 1) / totalSteps) * 100;

  const handleAnswer = (id: string, value: any) => {
    setAnswers((prev: any) => ({ ...prev, [id]: value }));
  };

  const handleNext = () => {
    if (stepIndex <= questions.length) {
      setStepIndex(stepIndex + 1);
    }
  };

  const handleBack = () => {
    if (stepIndex > 0) {
      setStepIndex(stepIndex - 1);
    }
  };

  return (
    <div className="app-editorial onboarding-editorial w-full max-w-2xl mx-auto">
      <div className="mb-8 space-y-4 text-center">
        <h1 className="font-serif text-3xl tracking-tight">
          Customize your Profile Growth Preferences
        </h1>
        <div className="flex items-center gap-4">
          <Progress value={progress} className="h-2 flex-1" />
          <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">
            {isLastStep
              ? "Final review"
              : `Step ${stepIndex + 1} of ${totalSteps}`}
          </span>
        </div>
      </div>

      <Card className="border-border shadow-md overflow-hidden min-h-[500px] flex flex-col">
        <CardContent className="p-8 flex-1 flex flex-col">
          {!isLastStep ? (
            <OnboardingStep
              question={currentQuestion}
              answers={answers}
              onAnswer={handleAnswer}
              onNext={handleNext}
            />
          ) : (
            <OnboardingReview
              answers={answers}
              onSubmit={() => onComplete(answers)}
            />
          )}

          <div className="mt-auto pt-8 flex items-center justify-between border-top border-border">
            {stepIndex > 0 ? (
              <button
                onClick={handleBack}
                className="flex items-center gap-1 text-sm font-medium text-muted-foreground hover:text-foreground transition"
              >
                <ChevronLeft size={16} /> Back
              </button>
            ) : (
              <div />
            )}

            {!isLastStep && currentQuestion.type !== "single-select" && (
              <button
                onClick={handleNext}
                disabled={
                  !answers[currentQuestion.id] ||
                  (Array.isArray(answers[currentQuestion.id]) &&
                    answers[currentQuestion.id].length === 0)
                }
                className="flex items-center gap-1 text-sm font-medium text-accent hover:text-accent/80 transition disabled:opacity-50"
              >
                Next <ChevronRight size={16} />
              </button>
            )}
          </div>
        </CardContent>
      </Card>

      <p className="mt-8 text-center text-xs text-muted-foreground">
        {connected
          ? "Google Business Profile connected"
          : "Connection details saved"}{" "}
        · Your answers are used to tailor your business updates.
      </p>
    </div>
  );
}
