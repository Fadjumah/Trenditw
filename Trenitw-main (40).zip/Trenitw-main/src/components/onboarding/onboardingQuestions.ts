export type QuestionType = "single-select" | "multi-select" | "text";

export interface Option {
  label: string;
  value: string;
}

export interface Question {
  id: string;
  title: string;
  description: string;
  type: QuestionType;
  options?: Option[];
  followUp?: {
    is?: string;
    isNot?: string;
    question: Question;
  };
  dynamicOptions?: (answers: any) => Option[];
}

export const onboardingQuestions: Question[] = [
  {
    id: "businessName",
    title: "What is your business name?",
    description: "Please enter your official business name.",
    type: "text",
  },
  {
    id: "category",
    title: "What is your business category?",
    description: "This helps Trendit understand your industry context.",
    type: "single-select",
    options: [
      { label: "Food & Drink", value: "Food & Drink" },
      { label: "Home & Trade Services", value: "Home & Trade Services" },
      { label: "Health & Wellness", value: "Health & Wellness" },
      { label: "Retail", value: "Retail" },
      { label: "Other", value: "Other" },
    ],
    followUp: {
      is: "Other",
      question: {
        id: "customCategory",
        title: "What is your business category?",
        description: "Please specify your industry.",
        type: "text",
      },
    },
  },
  {
    id: "services",
    title: "Which services do you offer?",
    description: "Select 3-5 that apply to your business.",
    type: "multi-select",
    dynamicOptions: (answers) => {
      const services: Record<string, string[]> = {
        "Food & Drink": [
          "Dine-in",
          "Takeout",
          "Delivery",
          "Catering",
          "Events",
        ],
        "Home & Trade Services": [
          "Plumbing",
          "Electrical",
          "HVAC",
          "Roofing",
          "Landscaping",
        ],
        "Health & Wellness": [
          "Personal Training",
          "Yoga",
          "Massage",
          "Nutrition",
          "Physical Therapy",
        ],
        Retail: [
          "In-store shopping",
          "Curbside pickup",
          "Online ordering",
          "Gift cards",
          "Repairs",
        ],
      };
      const opts = services[answers.category] || [
        "Consulting",
        "Software",
        "Education",
        "Manufacturing",
        "Other",
      ];
      return opts.map((o) => ({ label: o, value: o }));
    },
  },
  {
    id: "tone",
    title: "What should be your brand tone?",
    description: "How should Trendit speak to your customers?",
    type: "single-select",
    options: [
      { label: "Friendly & casual", value: "Friendly & casual" },
      { label: "Professional & polished", value: "Professional & polished" },
      { label: "Warm & personal", value: "Warm & personal" },
      { label: "Bold & energetic", value: "Bold & energetic" },
    ],
  },
  {
    id: "targetCustomer",
    title: "Who is your target customer?",
    description: "Knowing your audience helps craft better messages.",
    type: "single-select",
    options: [
      { label: "Local homeowners", value: "Local homeowners" },
      { label: "Young professionals", value: "Young professionals" },
      { label: "Families", value: "Families" },
      { label: "Businesses (B2B)", value: "Businesses (B2B)" },
    ],
  },
  {
    id: "promos",
    title: "How often do you run promotions?",
    description: "This helps Trendit plan seasonal content.",
    type: "single-select",
    options: [
      { label: "We run regular promos", value: "Regular promos" },
      { label: "Only seasonal (holidays etc.)", value: "Only seasonal" },
      { label: "Rarely", value: "Rarely" },
      { label: "Never", value: "Never" },
    ],
    followUp: {
      isNot: "Never",
      question: {
        id: "customPromo",
        title: "Any specific upcoming promo?",
        description: "Tell us about your next big thing.",
        type: "text",
      },
    },
  },
];
