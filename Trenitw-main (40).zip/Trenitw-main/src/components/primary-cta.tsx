import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { GoogleConnectButton } from "@/components/google-connect-button";
import { useAuthState } from "@/hooks/use-auth-state";
import { cn } from "@/lib/utils";
import { ArrowRight, LayoutDashboard, Store } from "lucide-react";

interface PrimaryCTAProps {
  className?: string;
  variant?: "default" | "outline" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
  source?: string;
  children?: React.ReactNode;
  /**
   * "static" — always show the connect button regardless of auth state.
   * Default behaviour navigates to dashboard when already authenticated.
   */
  connectedMode?: "static" | "dashboard";
}

/**
 * Site-wide primary call-to-action with full 3-state auth support:
 *
 * 1. Anonymous (Logged-out):
 *    → "Get Started" / supplied CTA copy (OAuth flow)
 * 2. Returning Account without connected GBP:
 *    → "Connect your business" (OAuth re-auth flow)
 * 3. Authenticated with Connected GBP:
 *    → "Go to Dashboard" (navigate to /dashboard)
 */
export function PrimaryCTA({
  className,
  variant = "default",
  size = "lg",
  source = "cta",
  children,
  connectedMode,
}: PrimaryCTAProps) {
  const { hydrated, authMode, businessName } = useAuthState();
  const navigate = useNavigate();

  const isStatic = connectedMode === "static";

  // State 1 & Static: Anonymous or forced static connect
  if (!hydrated || authMode === "anonymous" || isStatic) {
    return (
      <GoogleConnectButton
        variant={variant}
        size={size}
        source={source}
        forceReauth={isStatic}
        className={cn(
          "rounded-md font-medium transition-all border-none",
          className,
        )}
      >
        {children ?? "Get Started"}
      </GoogleConnectButton>
    );
  }

  // State 2: Account exists, but no active connected GBP
  if (authMode === "account_unconnected") {
    return (
      <GoogleConnectButton
        variant={variant}
        size={size}
        source={source}
        forceReauth
        className={cn(
          "rounded-md font-medium transition-all border-none gap-2",
          className,
        )}
      >
        <Store size={18} />
        {children ?? "Connect your business"}
      </GoogleConnectButton>
    );
  }

  // State 3: Authenticated with active connected GBP
  return (
    <Button
      variant={variant}
      size={size}
      className={cn(
        "rounded-md font-medium transition-all border-none gap-2 shadow-sm",
        className,
      )}
      onClick={() => navigate({ to: "/dashboard" })}
    >
      <LayoutDashboard size={18} />
      <span>Go to Dashboard {businessName ? `(${businessName})` : ""}</span>
      <ArrowRight size={16} />
    </Button>
  );
}
