import React from "react";

type PublicVisual = {
  src: string;
  alt: string;
  eyebrow: string;
  title: string;
};

type PublicVisualStripProps = {
  items: PublicVisual[];
  className?: string;
};

export function PublicVisualStrip({ items, className = "" }: PublicVisualStripProps) {
  return (
    <section className={className}>
      <div className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 sm:px-8 lg:px-12 xl:px-16">
        <div className="grid gap-5 md:grid-cols-3">
          {items.map((item) => (
            <figure key={item.src} className="group overflow-hidden rounded-[28px] bg-white dark:bg-[#201d19]">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={item.src}
                  alt={item.alt}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/5 to-transparent" />
                <figcaption className="absolute inset-x-0 bottom-0 p-5 text-white">
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/70">
                    {item.eyebrow}
                  </div>
                  <div className="font-serif text-xl leading-tight sm:text-2xl">
                    {item.title}
                  </div>
                </figcaption>
              </div>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
