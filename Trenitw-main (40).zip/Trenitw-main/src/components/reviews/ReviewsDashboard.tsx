import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  MessageSquare,
  Star,
  RefreshCcw,
  Send,
  MessageSquareText,
  AlertCircle,
  Zap,
  CheckCircle2,
  Sparkles,
  Copy,
  Check,
} from "lucide-react";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiFetch } from "@/lib/api";
import { GrowthUpgradeModal } from "@/components/growth-upgrade-modal";

interface ReviewsDashboardProps {
  customerId?: string;
}

interface Review {
  reviewId: string;
  reviewer: {
    displayName: string;
    profilePhotoUrl?: string;
  };
  starRating: string;
  comment?: string;
  createTime: string;
  updateTime?: string;
  is_replied?: boolean;
  reviewReply?: {
    comment?: string;
    updateTime?: string;
    reviewReplyState?: string;
  };
  saved_draft?: string;
  owner_decision?: string;
  published_at?: string;
}

const RATING_MAP: Record<string, number> = {
  ONE: 1,
  TWO: 2,
  THREE: 3,
  FOUR: 4,
  FIVE: 5,
};

function ratingToNumber(value: string | number): number {
  if (typeof value === "number") return Math.max(1, Math.min(5, value));
  const normalized = String(value || "").trim().toUpperCase();
  if (RATING_MAP[normalized]) return RATING_MAP[normalized];
  const parsed = Number.parseInt(normalized.replace(/[^0-9]/g, ""), 10);
  return Number.isFinite(parsed) ? Math.max(1, Math.min(5, parsed)) : 5;
}

const PRESETS = [
  {
    label: "5-Star: Great Physio Care",
    rating: 5,
    text: "The physiotherapy team at Heritage Physio Care in Entebbe was wonderful. My lower back pain has improved significantly after just three visits!",
  },
  {
    label: "4-Star: Helpful with minor wait",
    rating: 4,
    text: "Friendly staff and clean clinic. The exercises helped my neck stiffness a lot, though the clinic was quite busy and I had a brief wait.",
  },
  {
    label: "2-Star: Schedule confusion",
    rating: 2,
    text: "Had some miscommunication regarding my appointment time yesterday. The treatment was helpful once I got in, but scheduling needs improvement.",
  },
];

export function ReviewsDashboard({
  customerId: customerIdProp,
}: ReviewsDashboardProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [activeTab, setActiveTab] = useState<"all" | "unreplied" | "replied">("all");
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState<Record<string, boolean>>({});
  const [replies, setReplies] = useState<Record<string, string>>({});
  const [sending, setSending] = useState<Record<string, boolean>>({});
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);

  // Test AI Reply Sandbox State
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [sandboxRating, setSandboxRating] = useState(5);
  const [sandboxText, setSandboxText] = useState(
    "Had a great physiotherapy session at Heritage Physio Care in Entebbe. The therapist was very attentive and my back feels much better!"
  );
  const [sandboxResult, setSandboxResult] = useState("");
  const [sandboxGenerating, setSandboxGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const [quota, setQuota] = useState<{
    used_today: number;
    max_daily: number;
    remaining: number;
    lifetime_used?: number | null;
    lifetime_limit?: number | null;
    lifetime_remaining?: number | null;
  }>({
    used_today: 0,
    max_daily: 3,
    remaining: 3,
    lifetime_used: null,
    lifetime_limit: null,
    lifetime_remaining: null,
  });
  const [autopilotEnabled, setAutopilotEnabled] = useState<boolean>(false);

  const customerId =
    customerIdProp ||
    (typeof window !== "undefined"
      ? localStorage.getItem("trendit_customer_id")
      : null);
  const locationId =
    typeof window !== "undefined"
      ? localStorage.getItem("trendit_location_id")
      : null;
  const [businessName, setBusinessName] = useState("your business");

  const fetchReviews = async () => {
    if (!customerId) return;
    setLoading(true);
    try {
      // Check entitlement
      try {
        const entitlementResp = await apiFetch(
          `/api/user/entitlement/${encodeURIComponent(customerId)}`,
        );
        if (entitlementResp.ok) {
          const entitlement = await entitlementResp.json();
          setHasAccess(entitlement?.has_access === true);
        }
      } catch (e) {
        console.warn("Entitlement check error:", e);
      }

      // Fetch profile for business name
      const profileResp = await apiFetch(`/api/user/profile/${customerId}`);
      if (profileResp.ok) {
        const profileData = await profileResp.json();
        if (profileData.business_name)
          setBusinessName(profileData.business_name);
      }

      // All users (Free & Growth) fetch actual Google reviews
      const queryParams = locationId
        ? `?location_id=${encodeURIComponent(locationId)}`
        : "";
      const response = await apiFetch(`/reviews/${customerId}${queryParams}`);
      if (response.ok) {
        const data = await response.json();
        const rawReviews = data.reviews || [];
        setReviews(rawReviews);
        if (data.quota) {
          setQuota(data.quota);
        }
        if (typeof data.autopilot_enabled === "boolean") {
          setAutopilotEnabled(data.autopilot_enabled);
        }
        // Pre-populate any saved drafts
        const existingReplies: Record<string, string> = {};
        for (const r of rawReviews) {
          if (r.saved_draft && r.reviewId) {
            existingReplies[r.reviewId] = r.saved_draft;
          }
        }
        if (Object.keys(existingReplies).length > 0) {
          setReplies((prev) => ({ ...existingReplies, ...prev }));
        }
        if (data.business_name) {
          setBusinessName(data.business_name);
        }
      } else {
        setReviews([]);
      }
    } catch (error) {
      console.error("Failed to fetch reviews:", error);
      toast.error("Failed to load reviews. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [customerId]);

  const generateReply = async (review: Review) => {
    setGenerating((prev) => ({ ...prev, [review.reviewId]: true }));
    try {
      const response = await apiFetch("/reviews/generate-suggestion", {
        method: "POST",
        body: JSON.stringify({
          customer_id: customerId,
          review_text: review.comment || "No comment provided",
          star_rating: ratingToNumber(review.starRating),
          business_name: businessName,
          tone: "professional",
        }),
      });
      if (response.ok) {
        const data = await response.json();
        setReplies((prev) => ({
          ...prev,
          [review.reviewId]: data.suggestion,
        }));
        toast.success("Suggested response drafted!");
      } else {
        throw new Error("Failed to generate response");
      }
    } catch (error) {
      console.error("Failed to generate reply:", error);
      toast.error("Failed to generate suggested reply.");
    } finally {
      setGenerating((prev) => ({ ...prev, [review.reviewId]: false }));
    }
  };

  const submitReply = async (reviewId: string) => {
    // If user is on Free tier, open the Growth Upgrade Modal
    if (!hasAccess) {
      setUpgradeModalOpen(true);
      return;
    }

    const replyText = replies[reviewId];
    if (!replyText?.trim() || !customerId || !locationId) return;

    setSending((prev) => ({ ...prev, [reviewId]: true }));
    try {
      const response = await apiFetch("/reviews/submit-reply", {
        method: "POST",
        body: JSON.stringify({
          customer_id: customerId,
          location_id: locationId,
          review_id: reviewId,
          reply_text: replyText,
        }),
      });

      if (response.ok) {
        toast.success("Reply posted to Google successfully!");
        setReviews((prev) =>
          prev.map((r) =>
            r.reviewId === reviewId
              ? {
                  ...r,
                  is_replied: true,
                  reviewReply: {
                    comment: replyText,
                    updateTime: new Date().toISOString(),
                  },
                }
              : r
          )
        );
      } else if (response.status === 402) {
        setUpgradeModalOpen(true);
      } else {
        throw new Error("Failed to post reply");
      }
    } catch (error) {
      console.error("Failed to submit reply:", error);
      toast.error("Failed to post your reply. Please try again.");
    } finally {
      setSending((prev) => ({ ...prev, [reviewId]: false }));
    }
  };

  const runSandboxGenerate = async () => {
    if (!sandboxText.trim()) {
      toast.error("Please enter a review comment.");
      return;
    }
    setSandboxGenerating(true);
    try {
      const response = await apiFetch("/reviews/generate-suggestion", {
        method: "POST",
        body: JSON.stringify({
          customer_id: customerId,
          review_text: sandboxText,
          star_rating: sandboxRating,
          business_name: businessName,
          tone: "professional",
        }),
      });
      if (response.ok) {
        const data = await response.json();
        setSandboxResult(data.suggestion || "");
        toast.success("AI reply generated!");
      } else {
        throw new Error("Failed to generate suggestion");
      }
    } catch (err) {
      console.error("Sandbox generation error:", err);
      toast.error("Failed to generate AI reply.");
    } finally {
      setSandboxGenerating(false);
    }
  };

  const copySandboxResult = async () => {
    if (!sandboxResult) return;
    try {
      await navigator.clipboard.writeText(sandboxResult);
      setCopied(true);
      toast.success("Copied response to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy text.");
    }
  };

  // Filtered views
  const unrepliedReviews = reviews.filter(
    (r) => !r.is_replied && !(r.reviewReply && Boolean(r.reviewReply.comment))
  );
  const repliedReviews = reviews.filter(
    (r) => r.is_replied || (r.reviewReply && Boolean(r.reviewReply.comment))
  );
  const displayedReviews =
    activeTab === "unreplied"
      ? unrepliedReviews
      : activeTab === "replied"
      ? repliedReviews
      : reviews;

  if (loading) {
    return (
      <div className="app-editorial reviews-editorial space-y-8">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <Skeleton className="h-6 w-1/3" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (locationId === "pending_location_discovery") {
    return (
      <Card className="app-editorial border-dashed bg-white shadow-none rounded-3xl">
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <AlertCircle size={48} className="mb-4 text-accent" />
          <h3 className="font-serif text-xl">Account Not Fully Verified</h3>
          <p className="mt-2 max-w-sm text-muted-foreground">
            Google Business Profile access is still pending verification.
            Reviews will appear here once your account is fully synced.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="app-editorial reviews-editorial space-y-8">
      {/* Autopilot Status & Quota Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-xl bg-card shadow-xs ring-1 ring-black/[0.04] dark:ring-white/[0.06] gap-3">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            {autopilotEnabled ? (
              <>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </>
            ) : (
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-zinc-400"></span>
            )}
          </span>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-foreground">
                {autopilotEnabled ? "Review Autopilot Active" : "Review Autopilot Off"}
              </span>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                Max {quota.max_daily} / 24hrs
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {autopilotEnabled
                ? "Trendit Autopilot continuously monitors and replies to positive reviews (4-5 stars), holding negative reviews for your 1-click review."
                : "Autopilot is paused. Enable it in Overview settings to resume automated replies."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <span className="text-xs font-medium text-muted-foreground">
            Today's Quota:
          </span>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-muted/40">
            {quota.used_today} / {quota.max_daily} used
          </span>
          {quota.lifetime_limit !== null && (
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-muted/40">
              {quota.lifetime_used ?? 0} / {quota.lifetime_limit} lifetime
            </span>
          )}
        </div>
      </div>

      {/* Tabs and Actions Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
        <div className="flex items-center gap-1 p-1 bg-muted/40 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab("all")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === "all"
                ? "bg-background text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            All Reviews ({reviews.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("unreplied")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === "unreplied"
                ? "bg-background text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Needs Reply ({unrepliedReviews.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("replied")}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === "replied"
                ? "bg-background text-foreground shadow-sm font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Replied ({repliedReviews.length})
          </button>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <Button
            onClick={() => setSandboxOpen(true)}
            variant="outline"
            size="sm"
            className="gap-1.5 text-xs border-accent/40 hover:bg-accent/5 text-accent"
          >
            <Sparkles size={13} />
            Test AI Reply
          </Button>
          <Button
            onClick={fetchReviews}
            variant="ghost"
            size="sm"
            className="gap-1.5 text-xs"
          >
            <RefreshCcw size={13} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Reviews List */}
      {displayedReviews.length === 0 ? (
        <Card className="app-editorial border-dashed bg-white shadow-none rounded-3xl">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <MessageSquare size={48} className="mb-4 text-accent" />
            <h3 className="font-serif text-xl">
              {activeTab === "unreplied"
                ? "No Pending Reviews"
                : activeTab === "replied"
                ? "No Replied Reviews Yet"
                : "No Reviews Found"}
            </h3>
            <p className="mt-2 text-muted-foreground max-w-sm text-xs sm:text-sm">
              {activeTab === "unreplied"
                ? "You're all caught up! Great job maintaining an active, responsive presence with your customers."
                : activeTab === "replied"
                ? "Reviews that have received a reply will appear in this tab."
                : "No Google reviews found for this business listing yet."}
            </p>
            <Button
              onClick={fetchReviews}
              variant="outline"
              className="mt-6 gap-2 text-xs"
            >
              <RefreshCcw size={14} />
              Check for New Reviews
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:gap-6">
          {displayedReviews.map((review) => {
            const stars = ratingToNumber(review.starRating);
            const hasReply = Boolean(
              review.is_replied ||
                (review.reviewReply && Boolean(review.reviewReply.comment))
            );
            const replyText = review.reviewReply?.comment;
            const replyDate = review.reviewReply?.updateTime;

            return (
              <Card key={review.reviewId} className="border-0 shadow-xs ring-1 ring-black/[0.04] dark:ring-white/[0.06]">
                <CardHeader className="p-4 sm:p-6 pb-2 sm:pb-3 flex flex-row items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full bg-accent/10 text-accent font-bold text-sm shrink-0">
                      {review.reviewer.displayName.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-sm sm:text-base truncate">
                        {review.reviewer.displayName}
                      </CardTitle>
                      <div className="flex items-center gap-1 mt-0.5 flex-wrap">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              size={11}
                              className={
                                i < stars
                                  ? "fill-accent text-accent"
                                  : "text-muted-foreground"
                              }
                            />
                          ))}
                        </div>
                        <span className="text-[11px] text-muted-foreground ml-1">
                          {new Date(review.createTime).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  {hasReply ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 shrink-0">
                      <CheckCircle2 size={12} />
                      Replied on Google
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-500/10 text-amber-600 dark:text-amber-400 shrink-0">
                      Needs Reply
                    </span>
                  )}
                </CardHeader>

                <CardContent className="p-4 sm:p-6 pt-2 sm:pt-2 space-y-4">
                  <p className="text-xs sm:text-sm text-foreground/90 italic leading-relaxed">
                    "{review.comment || "No comment provided."}"
                  </p>

                  {/* Published Google Reply Callout */}
                  {hasReply && replyText && (
                    <div className="space-y-2 rounded-xl bg-emerald-500/[0.06] p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                          <CheckCircle2 size={13} className="text-emerald-500" />
                          Published Google Response
                        </span>
                        {replyDate && (
                          <span className="text-[11px] text-muted-foreground">
                            {new Date(replyDate).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm text-foreground/90 leading-relaxed">
                        {replyText}
                      </p>
                    </div>
                  )}

                  {/* Unreplied Interactive Response Box */}
                  {!hasReply && (
                    <>
                      {replies[review.reviewId] ? (
                        <div className="space-y-3 rounded-xl bg-accent/[0.06] p-4 ring-1 ring-accent/15">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-accent flex items-center gap-1">
                              <MessageSquareText size={12} />
                              Suggested Reply
                            </span>
                          </div>
                          <Textarea
                            value={replies[review.reviewId]}
                            onChange={(e) =>
                              setReplies((prev) => ({
                                ...prev,
                                [review.reviewId]: e.target.value,
                              }))
                            }
                            className="text-xs sm:text-sm bg-background"
                            rows={4}
                          />
                          <div className="flex flex-col-reverse sm:flex-row justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => generateReply(review)}
                              disabled={generating[review.reviewId]}
                              className="text-xs w-full sm:w-auto"
                            >
                              Regenerate
                            </Button>
                            <Button
                              size="sm"
                              className="gap-2 text-xs w-full sm:w-auto"
                              onClick={() => submitReply(review.reviewId)}
                              disabled={sending[review.reviewId]}
                            >
                              {sending[review.reviewId]
                                ? "Publishing to Google..."
                                : "Publish to Google"}
                              <Send size={14} />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex justify-end">
                          <Button
                            variant="outline"
                            className="gap-2 border-accent/40 text-accent hover:bg-accent/5 text-xs w-full sm:w-auto"
                            onClick={() => generateReply(review)}
                            disabled={generating[review.reviewId]}
                          >
                            {generating[review.reviewId] ? (
                              <>
                                <RefreshCcw size={14} className="animate-spin" />
                                Drafting Response...
                              </>
                            ) : (
                              <>
                                <MessageSquareText size={14} />
                                Draft Suggested Reply
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Test AI Reply Sandbox Modal */}
      <Dialog open={sandboxOpen} onOpenChange={setSandboxOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-5 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg flex items-center gap-2">
              <Sparkles size={18} className="text-accent" />
              Test AI Review Response Engine
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm">
              Preview how Trendit's Autopilot crafts keyword-optimized, professional
              responses for your Google reviews in real time.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-2">
            {/* Quick Presets */}
            <div>
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block mb-1.5">
                Quick Sample Presets
              </label>
              <div className="flex flex-wrap gap-1.5">
                {PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSandboxRating(p.rating);
                      setSandboxText(p.text);
                      setSandboxResult("");
                    }}
                    className="text-[11px] px-2.5 py-1 rounded-md bg-muted/40 hover:bg-muted text-foreground transition-all"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Star Rating Picker */}
            <div>
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block mb-1">
                Rating
              </label>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setSandboxRating(star)}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <Star
                      size={20}
                      className={
                        star <= sandboxRating
                          ? "fill-accent text-accent"
                          : "text-muted-foreground"
                      }
                    />
                  </button>
                ))}
                <span className="text-xs font-semibold ml-2 text-foreground">
                  {sandboxRating} / 5 Stars
                </span>
              </div>
            </div>

            {/* Review Text Input */}
            <div>
              <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block mb-1">
                Review Comment
              </label>
              <Textarea
                value={sandboxText}
                onChange={(e) => setSandboxText(e.target.value)}
                placeholder="Enter customer review text..."
                rows={3}
                className="text-xs sm:text-sm bg-background"
              />
            </div>

            {/* Generate Action */}
            <Button
              onClick={runSandboxGenerate}
              disabled={sandboxGenerating || !sandboxText.trim()}
              className="w-full gap-2 text-xs"
            >
              {sandboxGenerating ? (
                <>
                  <RefreshCcw size={14} className="animate-spin" />
                  Generating Response...
                </>
              ) : (
                <>
                  <Sparkles size={14} />
                  Generate AI Response
                </>
              )}
            </Button>

            {/* Response Output Card */}
            {sandboxResult && (
              <div className="rounded-xl bg-accent/[0.06] p-4 ring-1 ring-accent/15 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-accent flex items-center gap-1">
                    <MessageSquareText size={12} />
                    Trendit Generated Response
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={copySandboxResult}
                    className="h-7 px-2 text-xs gap-1"
                  >
                    {copied ? (
                      <>
                        <Check size={12} className="text-emerald-500" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy size={12} />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
                <p className="text-xs sm:text-sm text-foreground leading-relaxed">
                  {sandboxResult}
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Growth Upgrade Modal for 1-click Google publishing */}
      <GrowthUpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
        title="Unlock 1-Click Review Publishing"
        description="Publishing suggested review responses directly to Google Search and Maps requires an active Trendit subscription."
        highlightFeature="Publish responses directly to Google Business Profile"
        onSuccess={() => {
          setHasAccess(true);
        }}
      />
    </div>
  );
}
