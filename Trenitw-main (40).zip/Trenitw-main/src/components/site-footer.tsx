import { Link } from "@tanstack/react-router";
import { GoogleConnectButton } from "./google-connect-button";
import { BrandLogo } from "./brand-logo";
import { useAuthState } from "@/hooks/use-auth-state";
import { LayoutDashboard, Mail, MapPin, Phone, Linkedin, Facebook, Instagram, Youtube } from "lucide-react";
import { WhatsAppIcon, PinterestIcon, XTwitterIcon } from "./social-icons";
import { CONTACT_PHONE_1, CONTACT_PHONE_1_RAW, CONTACT_PHONE_2, CONTACT_PHONE_2_RAW, WHATSAPP_LINK, WHATSAPP_NUMBER, CONTACT_EMAIL } from "@/lib/seo";

const product = [
  ["Features", "/how-it-works#features"],
  ["How it works", "/how-it-works"],
  ["Growth Partnership", "/growth-partnership"],
  ["Get Listed", "/get-listed"],
  ["Website Design", "/website-design"],
  ["Pricing", "/#pricing"],
  ["Google Business Profile Management", "/google-business-profile-management"],
  ["Local SEO Guide", "/local-seo-for-small-businesses"],
  ["GBP Audit Guide", "/google-business-profile-audit"],
  ["GBP Posts Guide", "/google-business-profile-posts"],
];

export function SiteFooter() {
  const { hydrated, isAuthenticated } = useAuthState();
  const socials = [
    ["LinkedIn", "https://www.linkedin.com/company/trendexhub", Linkedin],
    ["Pinterest", "https://www.pinterest.com/trendexhub", PinterestIcon],
    ["X", "https://x.com/trendexhub", XTwitterIcon],
    ["Facebook", "https://www.facebook.com/trendexhub", Facebook],
    ["Instagram", "https://www.instagram.com/trendexhub", Instagram],
    ["YouTube", "https://www.youtube.com/@trendexhab", Youtube],
  ] as const;

  return (
    <footer className="mt-auto border-t border-white/10 bg-[#14202d] text-white">
      <div className="mx-auto max-w-[1310px] px-5 py-12 sm:px-8 sm:py-14 lg:px-10 xl:px-0">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
          <div>
            <Link to="/" className="inline-flex"><BrandLogo theme="dark" iconClassName="h-8 w-8" textClassName="text-[23px]" /></Link>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/60">Win more local customers on Google Search and Maps with a healthier, more active Business Profile.</p>
            <div className="mt-5">
              {hydrated && isAuthenticated ? <Link to="/dashboard" className="inline-flex h-10 items-center gap-2 rounded-[12px] bg-[#ff5b00] px-4 text-sm font-bold text-white hover:bg-[#e94f00]"><LayoutDashboard size={15}/>Dashboard</Link> : <GoogleConnectButton variant="default" size="sm" source="footer_get_started" className="h-10 rounded-[12px] border-0 bg-[#ff5b00] px-5 text-sm font-bold text-white hover:bg-[#e94f00]">Start Now →</GoogleConnectButton>}
            </div>
          </div>

          <div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#f3a37f]">Product</p><ul className="mt-4 space-y-2.5 text-sm">{product.map(([label, href]) => <li key={label}><a href={href} className="text-white/65 transition hover:text-white">{label}</a></li>)}</ul></div>
          <div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#f3a37f]">Company</p><ul className="mt-4 space-y-2.5 text-sm"><li><Link to="/about" className="text-white/65 hover:text-white">About Trendexhub</Link></li><li><Link to="/privacy" className="text-white/65 hover:text-white">Privacy Policy</Link></li><li><Link to="/terms" className="text-white/65 hover:text-white">Terms of Service</Link></li></ul></div>
          <div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#f3a37f]">Contact</p><ul className="mt-4 space-y-3 text-sm"><li><a href={`mailto:${CONTACT_EMAIL}`} className="flex items-center gap-2 text-white/65 hover:text-white"><Mail size={14}/>{CONTACT_EMAIL}</a></li><li><a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-white/65 hover:text-white"><WhatsAppIcon className="h-4 w-4 fill-current"/>Chat on WhatsApp</a></li><li><a href={`tel:${CONTACT_PHONE_1_RAW}`} className="flex items-center gap-2 text-white/65 hover:text-white"><Phone size={14}/>{CONTACT_PHONE_1}</a></li><li><span className="flex items-start gap-2 text-white/50"><MapPin size={14} className="mt-0.5 shrink-0"/>Global local-business growth platform</span></li></ul></div>
        </div>

        <div className="mt-10 flex flex-col gap-5 border-t border-white/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#f3a37f]">Connect with us</p><div className="mt-3 flex items-center gap-2"><a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" aria-label={`WhatsApp ${WHATSAPP_NUMBER}`} className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 hover:bg-white/10 hover:text-white"><WhatsAppIcon className="h-4 w-4 fill-current"/></a>{socials.map(([label, href, Icon]) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 hover:bg-white/10 hover:text-white"><Icon className="h-4 w-4"/></a>)}</div></div>
          <a href="https://www.producthunt.com/products/trendit-2?utm_source=badge-follow&utm_medium=badge&utm_source=badge-trendit-2" target="_blank" rel="noopener noreferrer" className="opacity-85 hover:opacity-100"><img src="https://api.producthunt.com/widgets/embed-image/v1/follow.svg?product_id=1309151&theme=dark" alt="Trendit on Product Hunt" width="250" height="54" className="h-[54px] w-[250px] max-w-full"/></a>
        </div>
        <div className="mt-7 flex flex-col gap-2 border-t border-white/10 pt-5 text-xs text-white/40 sm:flex-row sm:justify-between"><p>© {new Date().getFullYear()} Trendit by Trendexhub. All rights reserved.</p><p>Built for local business visibility.</p></div>
      </div>
    </footer>
  );
}
