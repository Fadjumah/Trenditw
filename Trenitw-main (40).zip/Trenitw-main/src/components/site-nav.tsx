import * as React from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, X, LogOut, LayoutDashboard, User, ChevronDown } from "lucide-react";
import { Button } from "./ui/button";
import { GoogleConnectButton } from "./google-connect-button";
import { ThemeToggle } from "./theme-toggle";
import { GoogleBarGraphIcon } from "./google-bar-graph-icon";
import { BrandLogo } from "./brand-logo";
import { useAuthState } from "@/hooks/use-auth-state";
import { track } from "@/lib/analytics";
import { BACKEND_URL } from "@/lib/api";
import { cn } from "@/lib/utils";

const navLinks = [
  { label: "How It Works", href: "/how-it-works", internal: true },
  { label: "Pricing", href: "/#pricing", internal: false },
];

const resourceLinks = [
  { label: "Growth Partnership", href: "/growth-partnership" },
  { label: "Get Listed", href: "/get-listed" },
  { label: "Web Design", href: "/website-design" },
  { label: "FAQ", href: "/#faq" },
  { label: "Google Business Profile Management", href: "/google-business-profile-management" },
  { label: "Local SEO for Small Businesses", href: "/local-seo-for-small-businesses" },
  { label: "Google Business Profile Audit", href: "/google-business-profile-audit" },
  { label: "Google Business Profile Posts", href: "/google-business-profile-posts" },
];

export function SiteNav() {
  const [isOpen, setIsOpen] = React.useState(false);
  const navigate = useNavigate();
  const { hydrated, isAuthenticated, email: userEmail, businessName } = useAuthState();

  React.useEffect(() => {
    if (!hydrated || !isAuthenticated || typeof window === "undefined") return;
    const token = localStorage.getItem("trendit_token");
    const customerId = localStorage.getItem("trendit_customer_id");
    if (!token || !customerId) return;
    const touchedKey = "trendit_session_touched_token";
    if (sessionStorage.getItem(touchedKey) === token) return;

    fetch(`${BACKEND_URL}/api/user/session/touch?customer_id=${encodeURIComponent(customerId)}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      keepalive: true,
    })
      .then(() => sessionStorage.setItem(touchedKey, token))
      .catch(() => {
        // Session telemetry must never block or degrade the application.
      });
  }, [hydrated, isAuthenticated]);

  const handleLogout = () => {
    if (typeof window !== "undefined") {
      ["trendit_customer_id", "trendit_token", "trendit_location_id", "trendit_email", "trendit_business_name", "trendit_onboarding_data"].forEach((key) => localStorage.removeItem(key));
      sessionStorage.removeItem("trendit_session_touched_token");
      window.dispatchEvent(new Event("trendit_auth_change"));
    }
    navigate({ to: "/" });
  };

  return (
    <header className="relative z-50 px-3 pt-3 sm:px-5 sm:pt-4 lg:px-6">
      <div className="mx-auto flex h-[62px] max-w-[1310px] items-center justify-between rounded-[20px] border border-black/[0.06] bg-white/90 px-4 shadow-[0_8px_30px_rgba(23,21,18,0.05)] backdrop-blur-xl sm:h-[68px] sm:px-6">
        <Link to="/" className="group flex shrink-0 items-center">
          <BrandLogo className="transition-transform group-hover:scale-[1.02]" iconClassName="h-7 w-7 sm:h-8 sm:w-8" textClassName="text-[21px] sm:text-[23px]" />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {hydrated && isAuthenticated && (
            <Link to="/dashboard" className="rounded-full bg-[#fff0e8] px-3 py-2 text-[14px] font-bold text-[#b64b25] transition hover:bg-[#fff0e8]">
              Dashboard
            </Link>
          )}
          {navLinks.map((link) => link.internal ? (
            <Link key={link.label} to={link.href as any} className="rounded-full px-3 py-2 text-[14px] font-semibold text-[#171512]/80 transition hover:bg-[#f7f3eb] hover:text-[#b64b25]">{link.label}</Link>
          ) : (
            <a key={link.label} href={link.href} className="rounded-full px-3 py-2 text-[14px] font-semibold text-[#171512]/80 transition hover:bg-[#f7f3eb] hover:text-[#b64b25]">{link.label}</a>
          ))}
          <details className="group relative">
            <summary className="flex cursor-pointer list-none items-center gap-1 rounded-full px-3 py-2 text-[14px] font-semibold text-[#171512]/80 hover:bg-[#f7f3eb] hover:text-[#b64b25]">Resources <ChevronDown className="h-4 w-4 transition group-open:rotate-180" /></summary>
            <div className="absolute right-0 top-11 w-52 rounded-2xl border border-black/[0.07] bg-white p-2 shadow-[0_18px_50px_rgba(23,21,18,0.12)]">
              {resourceLinks.map((link) => <Link key={link.label} to={link.href as any} className="block rounded-xl px-3 py-2.5 text-sm font-medium text-[#171512]/80 hover:bg-[#fff0e8] hover:text-[#b64b25]">{link.label}</Link>)}
            </div>
          </details>
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          {hydrated && isAuthenticated ? (
            <div className="hidden items-center gap-2 sm:flex">
              <Link to="/dashboard" className="inline-flex h-10 items-center gap-2 rounded-[12px] bg-[#ff5b00] px-4 text-sm font-bold text-white shadow-[0_8px_18px_rgba(255,91,0,0.18)] hover:bg-[#e94f00]"><LayoutDashboard size={15} />Dashboard</Link>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="rounded-full px-3 text-sm font-semibold text-[#171512]/70 hover:bg-[#f7f3eb]"><LogOut size={14} /> Logout</Button>
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <GoogleConnectButton variant="outline" size="sm" state="intent:login" source="nav_login" className="h-10 rounded-full border-0 bg-transparent px-4 text-sm font-semibold text-[#171512] hover:bg-[#f7f3eb]">Log in</GoogleConnectButton>
              <GoogleConnectButton variant="default" size="sm" state="intent:signup" source="nav_signup" className="h-10 rounded-[12px] border-0 bg-[#ff5b00] px-5 text-sm font-bold text-white shadow-[0_8px_18px_rgba(255,91,0,0.20)] hover:bg-[#e94f00]">Start Now <span className="ml-1">→</span></GoogleConnectButton>
            </div>
          )}
          {hydrated && isAuthenticated ? (
            <Button variant="ghost" size="icon" onClick={handleLogout} className="h-9 w-9 rounded-full sm:hidden" aria-label="Log out"><LogOut className="h-4 w-4" /></Button>
          ) : (
            <GoogleConnectButton variant="outline" size="sm" state="intent:login" source="nav_mobile_login_quick" className="h-9 rounded-full border border-black/10 bg-white/70 px-3 text-[11px] font-semibold text-[#171512] sm:hidden">Sign in</GoogleConnectButton>
          )}
          <Link to="/growth-partnership" onClick={() => track("nav_growth_graph_click", { source: "site_nav" })} className="hidden h-10 w-10 items-center justify-center rounded-full border border-black/[0.08] bg-white text-[#b64b25] hover:bg-[#fff0e8] sm:flex" aria-label="Growth performance"><GoogleBarGraphIcon className="h-4.5 w-4.5" /></Link>
          <ThemeToggle />
          <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full lg:hidden" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle Menu">{isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</Button>
        </div>
      </div>

      <div className={cn("fixed inset-x-3 top-[84px] z-50 max-h-[calc(100vh-96px)] overflow-y-auto rounded-[24px] border border-black/[0.07] bg-white p-4 shadow-[0_20px_60px_rgba(23,21,18,0.14)] lg:hidden", !isOpen && "hidden")}>
        <div className="mb-3 flex items-center justify-between border-b border-black/[0.07] pb-3">
          <BrandLogo iconClassName="h-7 w-7" textClassName="text-[20px]" />
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setIsOpen(false)}><X className="h-5 w-5" /></Button>
        </div>
        {hydrated && isAuthenticated && <div className="mb-3 flex items-center justify-between rounded-2xl bg-[#f7f3eb] px-3 py-2.5 text-xs"><span className="flex items-center gap-2 font-semibold"><User size={14} />{userEmail || "Account"}</span>{businessName && <span className="max-w-[130px] truncate rounded-full bg-white px-2 py-1 text-[#b64b25]">{businessName}</span>}</div>}
        <nav className="grid gap-1">
          {hydrated && isAuthenticated && <Link to="/dashboard" onClick={() => setIsOpen(false)} className="rounded-xl bg-[#fff0e8] px-3 py-3 text-sm font-bold text-[#b64b25]">Dashboard</Link>}
          {[...navLinks, ...resourceLinks.map((link) => ({ ...link, internal: true }))].map((link) => link.internal ? <Link key={link.label} to={link.href as any} onClick={() => setIsOpen(false)} className="rounded-xl px-3 py-3 text-sm font-semibold hover:bg-[#fff0e8]">{link.label}</Link> : <a key={link.label} href={link.href} onClick={() => setIsOpen(false)} className="rounded-xl px-3 py-3 text-sm font-semibold hover:bg-[#fff0e8]">{link.label}</a>)}
        </nav>
        <div className="mt-3 border-t border-black/[0.07] pt-3">
          {hydrated && isAuthenticated ? <div className="grid gap-2"><Link to="/dashboard" onClick={() => setIsOpen(false)} className="flex h-12 w-full items-center justify-center gap-2 rounded-[12px] bg-[#ff5b00] text-sm font-bold text-white">Go to Dashboard</Link><Button variant="ghost" onClick={() => { handleLogout(); setIsOpen(false); }} className="h-11 rounded-[12px] text-sm font-semibold">Log out</Button></div> : <div className="grid gap-2"><GoogleConnectButton variant="default" size="lg" state="intent:signup" source="nav_mobile_signup" className="h-12 rounded-[12px] border-0 bg-[#ff5b00] text-sm font-bold text-white">Start Now</GoogleConnectButton><GoogleConnectButton variant="outline" size="lg" state="intent:login" source="nav_mobile_login" className="h-11 rounded-[12px] border border-black/10 text-sm font-semibold">Log in</GoogleConnectButton></div>}
          <div className="mt-3 flex justify-center"><ThemeToggle variant="mobile" /></div>
        </div>
      </div>
    </header>
  );
}
