import * as React from "react";
import { Sun, Moon } from "lucide-react";
import { cn } from "@/lib/utils";

export type Theme = "light" | "dark";

const STORAGE_KEY = "trendit_theme";
const THEME_CHANGE_EVENT = "trendit_theme_change";

export function getStoredTheme(): Theme {
  if (typeof window === "undefined") return "light";
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === "dark" || stored === "light") return stored;
    return "dark";
  } catch {
    return "light";
  }
}

export function applyTheme(theme: Theme) {
  if (typeof window === "undefined") return;
  document.documentElement.classList.toggle("dark", theme === "dark");
  try { localStorage.setItem(STORAGE_KEY, theme); } catch {}
  window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT, { detail: { theme } }));
}

export function useTheme() {
  const [theme, setThemeState] = React.useState<Theme>(getStoredTheme);
  React.useEffect(() => {
    const current = getStoredTheme();
    setThemeState(current);
    applyTheme(current);
    const handleThemeChange = (e: Event) => {
      const detail = (e as CustomEvent<{ theme: Theme }>).detail;
      if (detail?.theme) setThemeState(detail.theme);
    };
    window.addEventListener(THEME_CHANGE_EVENT, handleThemeChange);
    return () => {
      window.removeEventListener(THEME_CHANGE_EVENT, handleThemeChange);
    };
  }, []);

  const toggleTheme = React.useCallback(() => {
    const next = theme === "dark" ? "light" : "dark";
    setThemeState(next);
    applyTheme(next);
  }, [theme]);

  return { theme, isDark: theme === "dark", toggleTheme, setTheme: (t: Theme) => { setThemeState(t); applyTheme(t); } };
}

export function ThemeToggle({ className, variant = "default" }: {
  className?: string;
  variant?: "default" | "landing" | "mobile";
}) {
  const { isDark, toggleTheme } = useTheme();
  const label = isDark ? "Switch to light mode" : "Switch to dark mode";

  if (variant === "mobile") {
    return (
      <button type="button" onClick={toggleTheme} className={cn(
        "flex min-h-[44px] w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition-colors cursor-pointer",
        "border border-border bg-card text-card-foreground hover:bg-accent/10",
        className,
      )} aria-label={label} title={label}>
        <span className="flex items-center gap-2.5 text-foreground">
          {isDark ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-foreground" />}
          <span>{isDark ? "Light mode" : "Dark mode"}</span>
        </span>
        <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-0.5 rounded-full bg-muted">
          {isDark ? "Dark ON" : "Light ON"}
        </span>
      </button>
    );
  }

  return (
    <button type="button" onClick={toggleTheme} className={cn(
      "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background text-foreground/80 hover:bg-accent/10 hover:text-foreground hover:border-foreground/30 transition-all cursor-pointer shadow-xs active:scale-95",
      className,
    )} aria-label={label} title={label}>
      {isDark ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-foreground/80" />}
    </button>
  );
}
