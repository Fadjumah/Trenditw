import { Toaster as Sonner } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      gap={16}
      offset={16}
      mobileOffset={{ bottom: 16, right: 16, left: 16, top: 16 }}
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg group-[.toaster]:p-4 group-[.toaster]:rounded-xl group-[.toaster]:border",
          description:
            "group-[.toast]:text-muted-foreground group-[.toast]:mt-1 text-xs leading-relaxed",
          actionButton:
            "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground group-[.toast]:h-10 group-[.toast]:px-4 group-[.toast]:rounded-lg text-xs font-semibold transition hover:opacity-90",
          cancelButton:
            "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground group-[.toast]:h-10 group-[.toast]:px-4 group-[.toast]:rounded-lg text-xs font-semibold transition hover:opacity-90",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };
