import { useState, useEffect, useCallback } from "react";

export type AuthMode =
  | "anonymous" // No valid session token or customer ID
  | "account_unconnected" // Valid session/customer ID, but no connected GBP location
  | "authenticated_connected"; // Valid session + customer ID + connected GBP location

export interface AuthState {
  hydrated: boolean;
  customerId: string | null;
  locationId: string | null;
  token: string | null;
  email: string | null;
  businessName: string | null;
  authMode: AuthMode;
  isAuthenticated: boolean;
}

export function useAuthState(): AuthState {
  const readState = useCallback((): AuthState => {
    if (typeof window === "undefined") {
      return {
        hydrated: false,
        customerId: null,
        locationId: null,
        token: null,
        email: null,
        businessName: null,
        authMode: "anonymous",
        isAuthenticated: false,
      };
    }

    const customerId = localStorage.getItem("trendit_customer_id");
    const token = localStorage.getItem("trendit_token");
    const locationId = localStorage.getItem("trendit_location_id");
    const email = localStorage.getItem("trendit_email");
    const businessName = localStorage.getItem("trendit_business_name");

    const hasValidSession = Boolean(
      customerId && token && token.trim().length > 0,
    );
    const hasConnectedLocation = Boolean(
      hasValidSession &&
      locationId &&
      locationId !== "pending_location_discovery" &&
      locationId !== "pending_location_selection" &&
      locationId !== "multiple_locations_pending",
    );

    let mode: AuthMode = "anonymous";
    if (hasValidSession) {
      mode = hasConnectedLocation
        ? "authenticated_connected"
        : "account_unconnected";
    }

    return {
      hydrated: true,
      customerId: hasValidSession ? customerId : null,
      locationId: hasConnectedLocation ? locationId : null,
      token: hasValidSession ? token : null,
      email: hasValidSession ? email : null,
      businessName: hasValidSession ? businessName : null,
      authMode: mode,
      isAuthenticated: hasValidSession,
    };
  }, []);

  const [state, setState] = useState<AuthState>(readState);

  useEffect(() => {
    setState(readState());

    const handleStorage = () => {
      setState(readState());
    };

    window.addEventListener("storage", handleStorage);
    window.addEventListener("trendit_auth_change", handleStorage);

    return () => {
      window.removeEventListener("storage", handleStorage);
      window.removeEventListener("trendit_auth_change", handleStorage);
    };
  }, [readState]);

  // Handle analytics transitions based on auth state changes
  useEffect(() => {
    // Only run when hydrated to avoid false positives on initial render
    if (!state.hydrated) return;

    const prevCustomerId = sessionStorage.getItem("trendit_prev_customer_id");
    const currentCustomerId = state.customerId;

    if (currentCustomerId && currentCustomerId !== prevCustomerId) {
      import("@/lib/analytics").then(({ track, identifyUser }) => {
        const isConnected = state.authMode === "authenticated_connected";
        identifyUser(currentCustomerId, {
          user_id: currentCustomerId,
          ...(state.email ? { email: state.email } : {}),
          ...(state.businessName ? { business_name: state.businessName } : {}),
          gbp_connected: isConnected,
          onboarding_status: isConnected ? "completed" : "pending",
          connected_location_count: isConnected ? 1 : 0,
        });

        // Differentiate genuine login vs restored session in a new tab
        // If this is the very first time we see them in this session (prevCustomerId is null)
        // AND they already have a connected location from the start, they are likely a returning user
        // opening a new tab, rather than a fresh login flow.
        const isRestoredSession = !prevCustomerId && isConnected;

        if (isRestoredSession) {
          track("returning_user", {
            user_id: currentCustomerId,
            gbp_connected: isConnected,
          });
        } else {
          track("login", {
            user_id: currentCustomerId,
            gbp_connected: isConnected,
          });
        }
      });
      sessionStorage.setItem("trendit_prev_customer_id", currentCustomerId);
    } else if (!currentCustomerId && prevCustomerId) {
      // Authenticated -> Logged out
      import("@/lib/analytics").then(({ track, resetUser }) => {
        track("logout", { user_id: prevCustomerId });
        resetUser();
      });
      sessionStorage.removeItem("trendit_prev_customer_id");
    }
  }, [state.hydrated, state.customerId, state.email]);

  return state;
}
