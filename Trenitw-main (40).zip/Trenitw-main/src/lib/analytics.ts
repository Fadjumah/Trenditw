import posthog from "posthog-js";
import { BACKEND_URL } from "@/lib/api";

const POSTHOG_KEY = import.meta.env?.VITE_POSTHOG_KEY || import.meta.env?.VITE_POSTHOG_PROJECT_TOKEN || "phc_s6auxceeBiJ7ruBaJ9dYFWkD5zudqUaVyQgnrBPgg8M7";
const POSTHOG_HOST = import.meta.env?.VITE_POSTHOG_HOST || import.meta.env?.VITE_POSTHOG_API_HOST || "https://eu.i.posthog.com";
const SENSITIVE_KEY = /(token|access[_-]?token|refresh[_-]?token|secret|password|credential|authorization|api[_-]?key|private[_-]?key)/i;
const FIRST_PARTY_EVENTS = new Set(["$pageview", "connect_google_click", "business_connection_started", "auth_completed", "auth_failed", "signup_completed", "audit_started", "audit_completed", "audit_failed", "post_published", "autonomous_post_published", "review_reply_published", "review_replied", "checkout_started", "pricing_cta_click", "dashboard_view"]);

function sanitize(value: unknown): unknown {
  if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
  if (Array.isArray(value)) return value.slice(0, 20).map(sanitize);
  if (typeof value === "object") return Object.fromEntries(Object.entries(value as Record<string, unknown>).slice(0, 50).filter(([key]) => !SENSITIVE_KEY.test(key)).map(([key, val]) => [key, sanitize(val)]));
  return undefined;
}

function getVisitorId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const key = "trendit_visitor_id";
    const existing = localStorage.getItem(key);
    if (existing) return existing;
    const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `v_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;
    localStorage.setItem(key, id);
    return id;
  } catch { return null; }
}

function sendFirstPartyEvent(event: string, properties?: Record<string, unknown>, visitorId?: string | null): void {
  if (typeof window === "undefined" || !FIRST_PARTY_EVENTS.has(event)) return;
  const visitor = visitorId || getVisitorId();
  if (!visitor) return;
  const clean = (sanitize(properties) || {}) as Record<string, unknown>;
  const customerId = localStorage.getItem("trendit_customer_id") || undefined;
  const email = event === "auth_completed" ? (typeof clean.email === "string" ? clean.email : localStorage.getItem("trendit_email") || undefined) : undefined;
  void fetch(`${BACKEND_URL}/api/analytics/track`, { method: "POST", headers: { "Content-Type": "application/json" }, keepalive: true, body: JSON.stringify({ visitor_id: visitor, event_name: event, customer_id: customerId, email, path: window.location.pathname, source: typeof clean.source === "string" ? clean.source : undefined, properties: clean }) }).catch(() => undefined);
}

function completePendingAuth(): void {
  if (typeof window === "undefined") return;
  try {
    const startedAt = Number(localStorage.getItem("trendit_pending_auth_at") || 0);
    const callbackAt = Number(localStorage.getItem("trendit_oauth_callback_completed_at") || 0);
    const pendingVisitor = localStorage.getItem("trendit_pending_auth_visitor_id");
    const customerId = localStorage.getItem("trendit_customer_id");
    const email = localStorage.getItem("trendit_email");
    if (!startedAt || !callbackAt || !pendingVisitor || !customerId || !email) return;
    if (callbackAt < startedAt || callbackAt - startedAt > 30 * 60 * 1000) return;
    if (localStorage.getItem("trendit_auth_completed_recorded") === callbackAt.toString()) return;
    localStorage.setItem("trendit_auth_completed_recorded", callbackAt.toString());
    sendFirstPartyEvent("auth_completed", { email, user_id: customerId }, pendingVisitor);
    localStorage.removeItem("trendit_pending_auth_at");
    localStorage.removeItem("trendit_pending_auth_visitor_id");
    localStorage.removeItem("trendit_oauth_callback_completed_at");
  } catch { /* analytics must never block the app */ }
}

export function initAnalytics() {
  if (typeof window === "undefined" || !POSTHOG_KEY || posthog.__loaded) return;
  try {
    posthog.init(POSTHOG_KEY, { api_host: POSTHOG_HOST || "https://eu.i.posthog.com", ui_host: "https://eu.posthog.com", person_profiles: "identified_only", capture_pageview: "history_change", capture_pageleave: true, autocapture: true, persistence: "localStorage+cookie" });
  } catch { /* Fail-safe initialization */ }
}

export function track(event: string, properties?: Record<string, unknown>): void {
  try {
    if (typeof window !== "undefined" && !posthog.__loaded) initAnalytics();
    const clean = sanitize(properties) as Record<string, unknown>;
    posthog.capture(event, clean);
    sendFirstPartyEvent(event, clean);
    if (event === "$pageview") completePendingAuth();
  } catch { /* Analytics must never break the product. */ }
}

export function identifyUser(customerId: string | number, userProperties?: Record<string, unknown>): void {
  try {
    if (!customerId) return;
    if (typeof window !== "undefined" && !posthog.__loaded) initAnalytics();
    posthog.identify(String(customerId), userProperties ? (sanitize(userProperties) as Record<string, unknown>) : undefined);
  } catch { /* Non-blocking by design. */ }
}

export function resetUser(): void {
  try {
    if (typeof window === "undefined" || !posthog.__loaded) return;
    posthog.reset();
  } catch { /* Non-blocking by design. */ }
}
