export const BACKEND_URL = "https://trendit-4ocu.onrender.com";

export async function apiFetch(path: string, options: RequestInit = {}) {
  // Growth dashboard measurement now uses the immutable-baseline endpoint. Keep
  // existing callers working without touching Audit, Posts, Reviews, or OAuth.
  const growthMatch = path.match(/^\/api\/user\/growth\/([^?]+)(\?.*)?$/);
  const effectivePath = growthMatch
    ? `/api/user/growth-measurement/${growthMatch[1]}${growthMatch[2] || ""}`
    : path;
  const url = effectivePath.startsWith("http") ? effectivePath : `${BACKEND_URL}${effectivePath}`;
  console.log("apiFetch: Calling", url, "with options", options);

  const headers = {
    "Content-Type": "application/json",
    ...options.headers,
  };

  const token = typeof window !== "undefined" ? localStorage.getItem("trendit_token") : null;
  if (token) (headers as any)["Authorization"] = `Bearer ${token}`;

  const response = await fetch(url, { ...options, headers });

  if (typeof window !== "undefined" && path === "/oauth/callback" && response.ok) {
    try {
      localStorage.setItem("trendit_oauth_callback_completed_at", String(Date.now()));
    } catch {
      // Analytics marker must never affect the callback result.
    }
  }

  return response;
}
