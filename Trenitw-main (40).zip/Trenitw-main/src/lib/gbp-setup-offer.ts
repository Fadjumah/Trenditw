/**
 * Config for the paid, one-time "we create your Google Business Profile
 * for you" concierge offer. Separate from PRICING_PLANS (recurring
 * subscriptions) — this is a single purchase, fulfilled manually.
 */

export interface GbpSetupOffer {
  price: number;
  originalPrice: number;
  name: string;
  description: string;
  features: string[];
  turnaround: string;
  planIdEnvKey: string;
  defaultPlanId: string;
  ctaText: string;
}

export const GBP_SETUP_OFFER: GbpSetupOffer = {
  price: 59,
  originalPrice: 149,
  name: "Done-For-You Google Business Profile Setup",
  description:
    "No Business Profile on Google yet? We'll create it, fill it out correctly, and get it verified — so your business shows up on Google Search and Maps.",
  features: [
    "We create and configure your Business Profile listing",
    "Correct category, hours, service area and business details set up right the first time",
    "We guide you through Google's verification step (phone or postcard)",
    "Once verified, we connect it straight into your Trendit dashboard",
    "First month of Trendit Growth included free after setup",
  ],
  turnaround: "Typically live within 2–5 business days",
  planIdEnvKey: "VITE_FREEMIUS_GBP_SETUP_PLAN_ID",
  defaultPlanId: "65081",
  ctaText: "Get my business listed — $59",
};

export function getGbpSetupPlanId(): string {
  if (typeof window !== "undefined") {
    const envVal = (import.meta.env as Record<string, string | undefined>)[
      GBP_SETUP_OFFER.planIdEnvKey
    ];
    if (envVal) return envVal;
  }
  return GBP_SETUP_OFFER.defaultPlanId;
}
