export interface PricingTier {
  id: "free" | "pro" | string;
  name: string;
  badge?: string;
  popular?: boolean;
  price: number;
  originalPrice: number;
  discountPercent: number;
  period: string;
  description: string;
  features: string[];
  planIdEnvKey: string;
  defaultPlanId: string;
  hasTrial?: boolean;
  ctaText: string;
  sourceKey: string;
}

export const PRICING_PLANS: PricingTier[] = [
  {
    id: "free",
    name: "Trendit Free",
    price: 0,
    originalPrice: 0,
    discountPercent: 0,
    period: "/ forever",
    description: "A genuinely free way to start managing one Google Business Profile.",
    features: [
      "1 Google Business Profile location",
      "Basic profile preview",
      "1 published review reply per 24 hours",
      "Up to 10 review replies for the lifetime of the free business connection",
      "1 profile audit every 7 days",
      "Up to 10 autonomous posts in any 30-day period",
      "Choose your own posting frequency and time",
    ],
    planIdEnvKey: "",
    defaultPlanId: "",
    hasTrial: false,
    ctaText: "Start Free",
    sourceKey: "pricing_free_plan",
  },

  {
    id: "pro",
    name: "Trendit Pro",
    popular: true,
    badge: "30-Day Free Trial",
    price: 29,
    originalPrice: 58,
    discountPercent: 50,
    period: "/ month",
    description: "Full automated growth engine for serious local businesses.",
    features: [
      "Up to 2 Google Business Profile locations",
      "Daily autonomous posting (7 days/week schedule)",
      "Automated AI review auto-replies with SEO keywords",
      "Continuous profile health monitoring & issue detection",
      "Multi-location switcher & cross-location management",
      "Priority email & live chat support",
    ],
    planIdEnvKey: "VITE_FREEMIUS_GROWTH_PLAN_ID",
    defaultPlanId: "62230",
    hasTrial: true,
    ctaText: "Start 30-Day Free Trial",
    sourceKey: "pricing_pro_plan",
  },
];

export function getPricingPlan(id: string): PricingTier | undefined {
  return PRICING_PLANS.find((p) => p.id === id || (p.id === "pro" && (id === "growth" || id === "pro")));
}

export function getFreemiusPlanIdForTier(tier: PricingTier): string {
  if (typeof window !== "undefined") {
    const envVal = (import.meta.env as Record<string, string | undefined>)[
      tier.planIdEnvKey
    ];
    if (envVal) return envVal;
  }
  return tier.defaultPlanId;
}
