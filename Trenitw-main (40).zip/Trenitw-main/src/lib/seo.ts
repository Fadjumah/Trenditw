/**
 * Central SEO Configuration & Structured Data (JSON-LD) Library for Trendit.
 *
 * Implements comprehensive search engine metadata, Open Graph, Twitter cards,
 * canonical link generators, and Schema.org JSON-LD @graph builders.
 */

export const SITE_URL = "https://trendexhub.com";
export const PRODUCT_NAME = "Trendit";
export const COMPANY_NAME = "Trendexhub";
export const FOUNDER_NAME = "Lubega Fahad Juma";
export const DEFAULT_OG_IMAGE = `${SITE_URL}/logo.png?v=2`;
export const FOUNDER_IMAGE = `${SITE_URL}/founder.png`;
export const CONTACT_EMAIL = "info@trendexhub.com";
export const CONTACT_PHONE_1 = "+256 772 332 909";
export const CONTACT_PHONE_1_RAW = "+256772332909";
export const CONTACT_PHONE_2 = "+256 740 166 778";
export const CONTACT_PHONE_2_RAW = "+256740166778";
export const WHATSAPP_NUMBER = "+256 740 166 778";
export const WHATSAPP_LINK = "https://wa.me/256740166778";

export const DEFAULT_DESCRIPTION =
  "Trendit helps local businesses manage their Google Business Profile, audit profile health, automate localized post drafts, and manage customer review replies.";

export interface PageMetaOptions {
  title: string;
  description: string;
  canonicalPath?: string;
  image?: string;
  type?: "website" | "article" | "profile";
  keywords?: string[];
  noindex?: boolean;
}

/**
 * Generates an array of meta tags compatible with TanStack Router's head `meta` option.
 */
export function createPageMeta(options: PageMetaOptions) {
  const {
    title,
    description,
    canonicalPath = "",
    image = DEFAULT_OG_IMAGE,
    type = "website",
    keywords,
    noindex = false,
  } = options;

  const normalizedPath = canonicalPath.startsWith("/")
    ? canonicalPath
    : `/${canonicalPath}`;
  const url =
    normalizedPath === "/"
      ? `${SITE_URL}/`
      : `${SITE_URL}${normalizedPath.replace(/\/$/, "")}`;

  const metaList: Array<
    | { title: string }
    | { name: string; content: string }
    | { property: string; content: string }
  > = [
    { title },
    { name: "description", content: description },
    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:url", content: url },
    { property: "og:type", content: type },
    { property: "og:site_name", content: PRODUCT_NAME },
    { property: "og:image", content: image },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: title },
    { name: "twitter:description", content: description },
    { name: "twitter:image", content: image },
    { name: "robots", content: noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" },
    { name: "googlebot", content: noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" },
  ];

  if (keywords && keywords.length > 0) {
    metaList.push({ name: "keywords", content: keywords.join(", ") });
  }

  return metaList;
}

/**
 * Creates canonical link object for TanStack Router `links` option.
 */
export function createCanonicalLink(path: string = "") {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const href =
    normalizedPath === "/"
      ? `${SITE_URL}/`
      : `${SITE_URL}${normalizedPath.replace(/\/$/, "")}`;

  return {
    rel: "canonical",
    href,
  };
}

/**
 * Returns robots meta directive tag.
 */
export function createRobotsMeta(directive: string = "noindex, nofollow") {
  return [{ name: "robots", content: directive }];
}

/* ==========================================================================
   Schema.org JSON-LD @graph Builders
   ========================================================================== */

/**
 * Organization Schema: Trendexhub
 */
export function buildOrganizationSchema() {
  return {
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: COMPANY_NAME,
    url: SITE_URL,
    logo: `${SITE_URL}/logo.png?v=2`,
    address: {
      "@type": "PostalAddress",
      streetAddress: "Alice Reef Road, Protea Hotel Entebbe",
      addressLocality: "Entebbe",
      addressRegion: "Wakiso, Central Region",
      addressCountry: "Uganda",
    },
    contactPoint: [
      {
        "@type": "ContactPoint",
        telephone: CONTACT_PHONE_1,
        contactType: "customer service",
        availableLanguage: ["English"],
      },
      {
        "@type": "ContactPoint",
        telephone: CONTACT_PHONE_2,
        contactType: "WhatsApp & customer support",
        availableLanguage: ["English"],
      },
      {
        "@type": "ContactPoint",
        email: CONTACT_EMAIL,
        contactType: "customer support",
      },
    ],
  };
}

/**
 * WebSite Schema: Trendit
 */
export function buildWebSiteSchema() {
  return {
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    name: PRODUCT_NAME,
    url: SITE_URL,
    publisher: {
      "@id": `${SITE_URL}/#organization`,
    },
    description:
      "Local business growth and Google Business Profile management platform.",
  };
}

/**
 * SoftwareApplication Schema: Trendit
 */
export function buildSoftwareApplicationSchema() {
  return {
    "@type": "SoftwareApplication",
    "@id": `${SITE_URL}/#software`,
    name: PRODUCT_NAME,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: SITE_URL,
    description:
      "Autonomous Google Business Profile management, health auditing, automated review replies, and daily localized growth posts.",
    offers: [
      {
        "@type": "Offer",
        name: "Trendit Free",
        price: "0",
        priceCurrency: "USD",
        description: "Free access for one Google Business Profile with a basic profile preview and limited review-reply automation.",
      },
      {
        "@type": "Offer",
        name: "Trendit Pro",
        price: "29",
        priceCurrency: "USD",
        priceSpecification: {
          "@type": "UnitPriceSpecification",
          price: "29",
          priceCurrency: "USD",
          unitCode: "MON",
        },
        description:
          "Daily localized post drafts, automated AI review replies, and continuous profile monitoring across up to 2 locations with a 30-day free trial",
      },
    ],
  };
}

/**
 * Service Schema: Google Business Growth Program / Partnership
 */
export function buildGrowthPartnershipSchema() {
  return {
    "@type": "Service",
    "@id": `${SITE_URL}/growth-partnership#service`,
    name: "Google Business Growth Program",
    serviceType: "Google Business Profile & Local Search Growth",
    provider: {
      "@id": `${SITE_URL}/#organization`,
    },
    url: `${SITE_URL}/growth-partnership`,
    description:
      "Full-service Google Business Profile management and local search growth partnership helping businesses win more customer calls, direction requests, and website visits.",
    areaServed: "Worldwide",
    hasOfferCatalog: {
      "@type": "OfferCatalog",
      name: "Google Growth Services",
      itemListElement: [
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Google Business Profile Optimization & Audit",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Google Search & Maps Visibility Growth",
          },
        },
        {
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name: "Performance-Based Growth Partnership",
          },
        },
      ],
    },
  };
}

/**
 * WebPage Schema
 */
export function buildWebPageSchema({
  title,
  description,
  url,
  pageType = "WebPage",
}: {
  title: string;
  description: string;
  url: string;
  pageType?: "WebPage" | "AboutPage" | "FAQPage" | "ItemPage";
}) {
  return {
    "@type": pageType,
    "@id": `${url}#webpage`,
    url,
    name: title,
    description,
    isPartOf: {
      "@id": `${SITE_URL}/#website`,
    },
    about: {
      "@id": `${SITE_URL}/#software`,
    },
    inLanguage: "en-US",
  };
}

/**
 * Person Schema: Lubega Fahad Juma (Founder & CEO)
 */
export function buildPersonSchema() {
  return {
    "@type": "Person",
    "@id": `${SITE_URL}/about#founder`,
    name: FOUNDER_NAME,
    jobTitle: "Founder & CEO",
    worksFor: {
      "@id": `${SITE_URL}/#organization`,
    },
    image: FOUNDER_IMAGE,
    description:
      "Founder & CEO of Trendexhub and creator of Trendit, a platform helping local businesses grow their presence on Google Search and Maps.",
    url: `${SITE_URL}/about`,
  };
}

/**
 * AboutPage Schema: Connects AboutPage to Person & Organization
 */
export function buildAboutPageSchema() {
  return {
    "@type": "AboutPage",
    "@id": `${SITE_URL}/about#aboutpage`,
    url: `${SITE_URL}/about`,
    name: `About Trendexhub — Empowering Local Businesses Worldwide | ${PRODUCT_NAME}`,
    description:
      "Trendexhub is a technology company headquartered in Uganda, founded in 2021, helping businesses worldwide scale their presence and customer base on Google Search and Maps.",
    isPartOf: {
      "@id": `${SITE_URL}/#website`,
    },
    inLanguage: "en-US",
  };
}

/**
 * FAQPage Schema: Built from visible FAQ questions & answers
 */
export function buildFAQSchema(faqs: Array<{ q: string; a: string }>) {
  return {
    "@type": "FAQPage",
    "@id": `${SITE_URL}/#faqpage`,
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.a,
      },
    })),
  };
}

/**
 * BreadcrumbList Schema
 */
export function buildBreadcrumbSchema(
  items: Array<{ name: string; path: string }>,
) {
  return {
    "@type": "BreadcrumbList",
    "@id": `${SITE_URL}/#breadcrumbs`,
    itemListElement: items.map((item, index) => {
      const normalizedPath = item.path.startsWith("/")
        ? item.path
        : `/${item.path}`;
      const itemUrl =
        normalizedPath === "/"
          ? `${SITE_URL}/`
          : `${SITE_URL}${normalizedPath.replace(/\/$/, "")}`;

      return {
        "@type": "ListItem",
        position: index + 1,
        name: item.name,
        item: itemUrl,
      };
    }),
  };
}

/**
 * Builds the complete connected JSON-LD Schema @graph object
 */
export function buildSchemaGraph(entities: Array<Record<string, unknown>>) {
  return {
    "@context": "https://schema.org",
    "@graph": entities,
  };
}

/**
 * Formats the schema graph into a script element object for TanStack Router `scripts` head property.
 */
export function buildJsonLdScript(entities: Array<Record<string, unknown>>) {
  return {
    type: "application/ld+json",
    children: JSON.stringify(buildSchemaGraph(entities)),
  };
}
