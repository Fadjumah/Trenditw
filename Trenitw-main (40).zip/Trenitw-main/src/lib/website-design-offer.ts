/**
 * Config for the website design service — a manually fulfilled, one-time
 * project (not a subscription). Two tiers, priced to convert local Uganda
 * small-business leads while remaining worthwhile for solo delivery.
 */

export interface WebsiteDesignTier {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  tagline: string;
  bestFor: string;
  features: string[];
  ctaText: string;
  highlighted?: boolean;
  planIdEnvKey: string;
  pricingIdEnvKey: string;
  defaultPlanId?: string;
  defaultPricingId?: string;
}

export const WEBSITE_DESIGN_TIERS: WebsiteDesignTier[] = [
  {
    id: "starter",
    name: "Starter Site",
    price: 149,
    originalPrice: 297,
    tagline: "A clean, professional single-page site",
    bestFor: "Best for a first website or a simple service business",
    features: [
      "1 professional page (home, about, services, contact in one)",
      "Mobile-friendly design",
      "Click-to-call & WhatsApp button built in",
      "Contact form that emails you directly",
      "Delivered in 3–5 business days",
    ],
    ctaText: "Order Starter Site — $149",
    planIdEnvKey: "VITE_FREEMIUS_WEBSITE_DESIGN_STARTER_PLAN_ID",
    pricingIdEnvKey: "VITE_FREEMIUS_WEBSITE_DESIGN_STARTER_PRICING_ID",
    defaultPlanId: "68149",
    defaultPricingId: "90113",
  },
  {
    id: "business",
    name: "Business Site",
    price: 349,
    originalPrice: 697,
    tagline: "A full multi-page website that ranks and converts",
    bestFor: "Best for growing businesses that want to be found on Google",
    features: [
      "Up to 5 pages (home, about, services, gallery, contact)",
      "Mobile-friendly design",
      "Basic local SEO setup so you show up in search",
      "Click-to-call & WhatsApp button built in",
      "Contact form that emails you directly",
      "Connected to your Google Business Profile",
      "Delivered in 5–8 business days",
    ],
    ctaText: "Order Business Site — $349",
    highlighted: true,
    planIdEnvKey: "VITE_FREEMIUS_WEBSITE_DESIGN_BUSINESS_PLAN_ID",
    pricingIdEnvKey: "VITE_FREEMIUS_WEBSITE_DESIGN_BUSINESS_PRICING_ID",
    defaultPlanId: "68150",
    defaultPricingId: "90114",
  },
];

export const WEBSITE_DESIGN_TURNAROUND =
  "Most sites go live within a week of us receiving your details.";

export function getWebsiteDesignPlanId(tierId: string): string | undefined {
  const tier = WEBSITE_DESIGN_TIERS.find((t) => t.id === tierId);
  if (typeof import.meta !== "undefined" && import.meta.env) {
    if (tier) {
      const val = (import.meta.env as Record<string, string | undefined>)[
        tier.planIdEnvKey
      ];
      if (val) return val;
    }
    const genericVal = (import.meta.env as Record<string, string | undefined>)[
      "VITE_FREEMIUS_WEBSITE_DESIGN_PLAN_ID"
    ];
    if (genericVal) return genericVal;
  }
  return tier?.defaultPlanId;
}

export function getWebsiteDesignPricingId(tierId: string): string | undefined {
  const tier = WEBSITE_DESIGN_TIERS.find((t) => t.id === tierId);
  if (typeof import.meta !== "undefined" && import.meta.env) {
    if (tier) {
      const val = (import.meta.env as Record<string, string | undefined>)[
        tier.pricingIdEnvKey
      ];
      if (val) return val;
    }
    const genericVal = (import.meta.env as Record<string, string | undefined>)[
      "VITE_FREEMIUS_WEBSITE_DESIGN_PRICING_ID"
    ];
    if (genericVal) return genericVal;
  }
  return tier?.defaultPricingId;
}
