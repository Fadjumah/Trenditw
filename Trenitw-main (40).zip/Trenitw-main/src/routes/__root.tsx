import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";
import { LayoutDashboard } from "lucide-react";

import appCss from "../styles.css?url";
import siteDesignCss from "../site-design-system.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { initAnalytics, track } from "@/lib/analytics";
import { useAuthState } from "@/hooks/use-auth-state";
import { BrandLogo } from "@/components/brand-logo";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <Link to="/" className="inline-block mb-6" aria-label="Trendit home">
          <BrandLogo iconClassName="h-9 w-9" textClassName="text-[24px]" />
        </Link>
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">The page you're looking for doesn't exist or has been moved.</p>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">Go home</Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <a href="/" className="inline-block mb-6" aria-label="Trendit home">
          <BrandLogo iconClassName="h-9 w-9" textClassName="text-[24px]" />
        </a>
        <h1 className="text-xl font-semibold tracking-tight text-foreground">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong on our end. You can try refreshing or head back home.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">Try again</button>
          <a href="/" className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#0f0d0b" },
      { title: "Trendit — Win More Local Customers on Google Search & Maps" },
      { name: "description", content: "Trendit helps local businesses manage their Google Business Profile, audit profile health, automate localized post drafts, and manage customer review replies." },
      { name: "author", content: "Trendexhub" },
      { property: "og:site_name", content: "Trendit" },
      { property: "og:locale", content: "en_US" },
      { property: "og:title", content: "Trendit — Win More Local Customers on Google Search & Maps" },
      { property: "og:description", content: "Trendit helps local businesses manage their Google Business Profile, audit profile health, automate localized post drafts, and manage customer review replies." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "https://trendexhub.com/logo.png?v=2" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Trendit — Win More Local Customers on Google Search & Maps" },
      { name: "twitter:description", content: "Trendit helps local businesses manage their Google Business Profile, audit profile health, automate localized post drafts, and manage customer review replies." },
      { name: "twitter:image", content: "https://trendexhub.com/logo.png?v=2" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "stylesheet", href: siteDesignCss },
      { rel: "icon", href: "/favicon.svg?v=3", type: "image/svg+xml" },
      { rel: "icon", href: "/favicon.ico?v=3", sizes: "any" },
      { rel: "icon", href: "/favicon.png?v=3", type: "image/png" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png?v=3" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" },
    ],
    scripts: [
      { children: `(function(){try{var t=localStorage.getItem("trendit_theme");var theme=(t==="dark"||t==="light")?t:"dark";document.documentElement.classList.toggle("dark",theme==="dark")}catch(e){document.documentElement.classList.add("dark")}})();` },
      { src: "https://checkout.freemius.com/js/v1/", async: true },
      { src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5364167184723244", async: true, crossOrigin: "anonymous" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="overflow-x-hidden w-full max-w-full">
      <head><HeadContent /></head>
      <body className="overflow-x-hidden w-full max-w-full min-w-0 site-design-system">
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function GlobalDashboardShortcut() {
  const router = useRouter();
  const { hydrated, isAuthenticated } = useAuthState();
  const pathname = router.state.location.pathname;

  if (!hydrated || !isAuthenticated || pathname === "/dashboard") return null;

  return (
    <Link
      to="/dashboard"
      className="fixed bottom-4 right-4 z-[60] inline-flex h-11 items-center gap-2 rounded-full border border-border bg-card px-4 text-sm font-bold text-card-foreground shadow-[0_12px_30px_rgba(23,21,18,0.14)] backdrop-blur-xl transition hover:-translate-y-0.5 hover:bg-accent hover:text-accent-foreground sm:bottom-6 sm:right-6"
      aria-label="Return to dashboard"
    >
      <LayoutDashboard className="h-4 w-4" />
      Dashboard
    </Link>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();

  useEffect(() => {
    initAnalytics();
    const unsubscribe = router.subscribe("onResolved", () => {
      if (typeof window !== "undefined") {
        track("$pageview", { $current_url: window.location.href, $pathname: window.location.pathname });
      }
    });
    return () => unsubscribe();
  }, [router]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="site-design-system">
        <Outlet />
      </div>
      <GlobalDashboardShortcut />
      <Toaster />
    </QueryClientProvider>
  );
}