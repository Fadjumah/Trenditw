import React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { Button } from "@/components/ui/button";
import { GoogleConnectButton } from "@/components/google-connect-button";
import { BrandLogo } from "@/components/brand-logo";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  CheckCircle2,
  Globe2,
  Building2,
  Users,
  TrendingUp,
  ShieldCheck,
  Award,
  MapPin,
  Mail,
  Phone,
  Sparkles,
  BarChart3,
  Target,
  Briefcase,
  Lock,
  Zap,
} from "lucide-react";
import { WhatsAppIcon } from "@/components/social-icons";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildAboutPageSchema,
  buildJsonLdScript,
  CONTACT_PHONE_1,
  CONTACT_PHONE_1_RAW,
  CONTACT_PHONE_2,
  CONTACT_PHONE_2_RAW,
  WHATSAPP_LINK,
  WHATSAPP_NUMBER,
} from "@/lib/seo";

const aboutSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildAboutPageSchema(),
];

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: createPageMeta({
      title: "About Trendexhub — Empowering Local Businesses Worldwide | Trendit",
      description:
        "Founded in 2021 and based in Entebbe, Uganda, Trendexhub is a global technology company backed by hundreds of shareholders, helping businesses, multi-location brands, and agencies scale their customer base on Google Search and Maps.",
      canonicalPath: "/about",
      keywords: [
        "Trendexhub",
        "About Trendexhub",
        "Trendit",
        "Google Business Profile automation",
        "local SEO SaaS",
        "Uganda technology company",
        "multi-location local discovery",
      ],
    }),
    links: [createCanonicalLink("/about")],
    scripts: [buildJsonLdScript(aboutSchemaEntities)],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col justify-between overflow-x-hidden">
      <div>
        <SiteNav />

        <main className="pb-20">
          {/* 1. HERO SECTION */}
          <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 pb-16 pt-10 sm:px-8 lg:px-12 xl:px-16 lg:py-20">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-14 items-center">
              <div className="lg:col-span-7 space-y-6 text-left">
                <p className="text-xs sm:text-sm font-semibold uppercase tracking-[0.16em] text-[#b64b25] dark:text-[#f3a37f]">
                  About Trendexhub
                </p>
                <h1 className="font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl xl:text-[76px] text-[#171512] dark:text-white text-balance">
                  Empowering Businesses Worldwide to{" "}
                  <span className="italic text-[#b64b25] dark:text-[#f3a37f]">Dominate</span> Google Search &amp; Local Discovery.
                </h1>
                <p className="max-w-2xl text-lg sm:text-xl leading-8 text-black/65 dark:text-white/70">
                  Trendexhub is a technology company headquartered in Uganda dedicated
                  to helping businesses of all sizes scale their customer base, outrank competitors,
                  and automate their Google Business presence with verifiable precision.
                </p>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <Button
                    size="lg"
                    className="rounded-full bg-[#171512] dark:bg-white text-white dark:text-[#171512] px-7 py-3.5 text-sm font-semibold hover:bg-black/90 shadow-none"
                    asChild
                  >
                    <Link to="/subscribe">
                      <span>Get Started</span>
                      <ArrowRight size={16} className="ml-2" />
                    </Link>
                  </Button>

                  <Button
                    variant="outline"
                    size="lg"
                    className="rounded-full border border-black/15 dark:border-white/20 px-6 py-3.5 text-sm font-semibold hover:bg-black/5 dark:hover:bg-white/10 shadow-none"
                    asChild
                  >
                    <Link to="/how-it-works">
                      <span>How Trendit Works</span>
                    </Link>
                  </Button>
                </div>
              </div>

              {/* Right Column: 2x2 Fast Stats Grid filling desktop side */}
              <div className="lg:col-span-5 grid grid-cols-2 gap-4">
                <div className="p-6 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-1.5">
                  <div className="font-serif text-3xl sm:text-4xl font-bold text-[#171512] dark:text-white">2021</div>
                  <div className="text-xs font-semibold text-black/60 dark:text-white/60">Year Founded</div>
                  <p className="text-[11px] text-black/50 dark:text-white/50">Started with a 9-person core team</p>
                </div>

                <div className="p-6 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-1.5">
                  <div className="font-serif text-3xl sm:text-4xl font-bold text-[#171512] dark:text-white">100s+</div>
                  <div className="text-xs font-semibold text-black/60 dark:text-white/60">Global Shareholders</div>
                  <p className="text-[11px] text-black/50 dark:text-white/50">Institutional &amp; private backing</p>
                </div>

                <div className="p-6 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-1.5">
                  <div className="font-serif text-3xl sm:text-4xl font-bold text-[#171512] dark:text-white">Global</div>
                  <div className="text-xs font-semibold text-black/60 dark:text-white/60">Operating Worldwide</div>
                  <p className="text-[11px] text-black/50 dark:text-white/50">Serving users across dozens of nations</p>
                </div>

                <div className="p-6 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-1.5">
                  <div className="font-serif text-3xl sm:text-4xl font-bold text-[#171512] dark:text-white">SME to Ent</div>
                  <div className="text-xs font-semibold text-black/60 dark:text-white/60">Multi-Tier Delivery</div>
                  <p className="text-[11px] text-black/50 dark:text-white/50">From clinics to national agencies</p>
                </div>
              </div>
            </div>
          </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=1200&q=82", alt: "A distributed team collaborating", eyebrow: "People", title: "Built for businesses everywhere" },
          { src: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=1200&q=82", alt: "A local business serving customers", eyebrow: "Local business", title: "Growth starts close to home" },
          { src: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=82", alt: "A modern workspace with natural light", eyebrow: "Company", title: "Technology with a human feel" },
        ]} />

          {/* 2. THE STORY SECTION */}
          <section className="border-y border-black/10 dark:border-white/10 bg-white/45 dark:bg-white/5 py-20 px-5 sm:px-8 lg:px-12 xl:px-16">
            <div className="mx-auto max-w-7xl space-y-12">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                <div className="lg:col-span-5 space-y-4">
                  <div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25] dark:text-[#f3a37f]">
                    Our Origin &amp; Expansion
                  </div>
                  <h2 className="font-serif text-4xl leading-tight sm:text-5xl text-[#171512] dark:text-white">
                    From a 9-Person Mission to an International Growth Engine.
                  </h2>
                  <p className="text-lg leading-8 text-black/65 dark:text-white/70">
                    Trendexhub was founded in 2021 with a straightforward realization: over 80% of local
                    commercial decisions start on Google Search and Maps, yet business owners were losing
                    countless high-intent customers every month due to inactive profiles, unreplied reviews,
                    and opaque marketing retainers.
                  </p>
                </div>

                <div className="lg:col-span-7 space-y-5">
                  <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-3">
                    <div className="flex items-center gap-2.5 text-[#b64b25] dark:text-[#f3a37f] font-semibold text-sm">
                      <Users size={18} />
                      <span>Built from Deep Local SEO &amp; Engineering Roots</span>
                    </div>
                    <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                      We began with just 9 passionate software engineers and local search specialists. By
                      focusing relentlessly on verifiable Google Business Profile performance rather than
                      superficial vanity metrics, our results quickly drew international attention.
                    </p>
                  </div>

                  <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-3">
                    <div className="flex items-center gap-2.5 text-[#b64b25] dark:text-[#f3a37f] font-semibold text-sm">
                      <TrendingUp size={18} />
                      <span>Hundreds of Shareholders Backing a Unified Platform</span>
                    </div>
                    <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                      Today, Trendexhub has expanded into a globally distributed technology company owned by
                      hundreds of shareholders. Headquartered in Entebbe, Uganda, we power our flagship platform,{" "}
                      <strong className="text-[#171512] dark:text-white font-semibold">Trendit</strong>, serving trusted
                      businesses and marketing agencies across North America, Europe, Africa, and beyond.
                    </p>
                  </div>

                  <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none space-y-3">
                    <div className="flex items-center gap-2.5 text-[#b64b25] dark:text-[#f3a37f] font-semibold text-sm">
                      <ShieldCheck size={18} />
                      <span>Official Google Business Profile Standards</span>
                    </div>
                    <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                      We never compromise on security or stability. Trendexhub integrates directly with official
                      Google APIs, providing enterprise-grade token encryption, autonomous scheduling, and
                      multi-location controls that scale effortlessly with your business.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 3. WHO WE SERVE */}
          <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8 space-y-12">
            <div className="text-center space-y-3 max-w-2xl mx-auto">
              <div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25] dark:text-[#f3a37f]">
                Tailored For Scale
              </div>
              <h2 className="font-serif text-4xl leading-tight sm:text-5xl text-[#171512] dark:text-white">
                Designed for Every Stage of Business Growth
              </h2>
              <p className="text-lg leading-8 text-black/65 dark:text-white/70">
                Whether you are a single-practitioner medical clinic or a multi-client growth agency,
                Trendexhub delivers the exact infrastructure you need to win locally.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* SME Card */}
              <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="h-11 w-11 rounded-2xl bg-[#b64b25]/10 flex items-center justify-center text-[#b64b25] dark:text-[#f3a37f]">
                    <Building2 size={22} />
                  </div>
                  <h3 className="font-serif text-2xl text-[#171512] dark:text-white">
                    SMEs &amp; Local Practices
                  </h3>
                  <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                    Healthcare clinics, physio centers, legal practices, contractors, and retail shops.
                    Get high-ranking visibility on Google Maps and drive steady phone calls without spending
                    thousands on agency retainers.
                  </p>
                  <ul className="space-y-2.5 pt-2 text-sm text-black/75 dark:text-white/75">
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Autonomous daily Google Business updates</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Instant AI-suggested 5-star review replies</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>One-click profile health audits</span>
                    </li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full rounded-full border border-black/15 dark:border-white/20 text-xs font-semibold" asChild>
                  <Link to="/subscribe">Start Pro Free Trial</Link>
                </Button>
              </div>

              {/* Multi-Location Card */}
              <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border-2 border-[#b64b25] shadow-none flex flex-col justify-between space-y-6 relative">
                <div className="absolute -top-3.5 right-6">
                  <span className="rounded-full bg-[#b64b25] text-white text-[11px] font-semibold uppercase tracking-wider px-3.5 py-1">
                    Multi-Location
                  </span>
                </div>
                <div className="space-y-4">
                  <div className="h-11 w-11 rounded-2xl bg-[#b64b25]/15 flex items-center justify-center text-[#b64b25] dark:text-[#f3a37f]">
                    <Briefcase size={22} />
                  </div>
                  <h3 className="font-serif text-2xl text-[#171512] dark:text-white">
                    Multi-Location Brands &amp; Franchises
                  </h3>
                  <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                    Franchises, healthcare networks, and multi-branch commercial brands. Synchronize brand
                    standards across dozens of Google Business locations while maintaining granular regional control.
                  </p>
                  <ul className="space-y-2.5 pt-2 text-sm text-black/75 dark:text-white/75">
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Centralized multi-location management</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Brand-compliant post scheduling across timezones</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Aggregated multi-location performance insights</span>
                    </li>
                  </ul>
                </div>
                <Button size="sm" className="w-full rounded-full text-xs bg-[#b64b25] hover:bg-[#a03f1d] text-white font-semibold shadow-none" asChild>
                  <Link to="/growth-partnership">Explore Growth Program</Link>
                </Button>
              </div>

              {/* Agencies Card */}
              <div className="p-7 rounded-3xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 shadow-none flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="h-11 w-11 rounded-2xl bg-[#b64b25]/10 flex items-center justify-center text-[#b64b25] dark:text-[#f3a37f]">
                    <Target size={22} />
                  </div>
                  <h3 className="font-serif text-2xl text-[#171512] dark:text-white">
                    Agencies &amp; Growth Partners
                  </h3>
                  <p className="text-sm leading-7 text-black/60 dark:text-white/60">
                    Digital marketing agencies managing local search for 10 to 100+ clients. Deliver high-impact
                    local SEO results, automate daily client postings, and maximize client retention with zero manual busywork.
                  </p>
                  <ul className="space-y-2.5 pt-2 text-sm text-black/75 dark:text-white/75">
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Autonomous multi-client workflows</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>White-glove audit generation &amp; reporting</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <CheckCircle2 size={16} className="text-[#b64b25] dark:text-[#f3a37f] mt-0.5 shrink-0" />
                      <span>Save 20+ hours per client every month</span>
                    </li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full rounded-full border border-black/15 dark:border-white/20 text-xs font-semibold" asChild>
                  <Link to="/subscribe">Partner With Us</Link>
                </Button>
              </div>
            </div>
          </section>

          {/* 4. CORPORATE CREDENTIALS & UGANDA HQ */}
          <section className="border-y border-black/10 dark:border-white/10 bg-white/45 dark:bg-white/5 py-20 px-5 sm:px-8 lg:px-12 xl:px-16">
            <div className="mx-auto max-w-7xl space-y-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="space-y-5">
                  <div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25] dark:text-[#f3a37f]">
                    Institutional Governance
                  </div>
                  <h2 className="font-serif text-4xl leading-tight sm:text-5xl text-[#171512] dark:text-white text-balance">
                    Registered, Governed, &amp; Headquartered in Uganda.
                  </h2>
                  <p className="text-sm sm:text-base leading-relaxed text-black/65 dark:text-white/70">
                    Trendexhub operates under rigorous corporate compliance and data governance standards.
                    Whether handling OAuth profile authorizations, customer review pipelines, or subscription billing,
                    your business security is safeguarded by strict enterprise-level isolation.
                  </p>

                  <div className="space-y-3 pt-2">
                    <div className="flex items-start gap-3 p-4 rounded-2xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 text-xs">
                      <MapPin size={18} className="text-[#b64b25] shrink-0 mt-0.5" />
                      <div>
                        <div className="font-semibold text-[#171512] dark:text-white">Corporate Headquarters</div>
                        <div className="text-black/60 dark:text-white/60 mt-0.5">
                          Alice Reef Road, Protea Hotel Entebbe, Entebbe, Wakiso, Central Region, Uganda
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 rounded-2xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 text-xs">
                      <Mail size={18} className="text-[#b64b25] shrink-0 mt-0.5" />
                      <div>
                        <div className="font-semibold text-[#171512] dark:text-white">Official Corporate Correspondence</div>
                        <div className="text-black/60 dark:text-white/60 mt-0.5">
                          info@trendexhub.com · support@trendexhub.com
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 rounded-2xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 text-xs">
                      <Phone size={18} className="text-[#b64b25] shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <div className="font-semibold text-[#171512] dark:text-white">Direct Phone &amp; WhatsApp Support</div>
                        <div className="text-black/60 dark:text-white/60 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                          <a
                            href={`tel:${CONTACT_PHONE_1_RAW}`}
                            className="hover:text-black dark:hover:text-white transition-colors font-medium"
                          >
                            {CONTACT_PHONE_1}
                          </a>
                          <span>·</span>
                          <a
                            href={`tel:${CONTACT_PHONE_2_RAW}`}
                            className="hover:text-black dark:hover:text-white transition-colors font-medium"
                          >
                            {CONTACT_PHONE_2}
                          </a>
                          <span>·</span>
                          <a
                            href={WHATSAPP_LINK}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#25D366] hover:underline font-medium inline-flex items-center gap-1 transition-colors"
                          >
                            <WhatsAppIcon className="h-3.5 w-3.5 fill-current" />
                            <span>WhatsApp Helpline</span>
                          </a>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 rounded-2xl bg-white dark:bg-[#201d19] border border-black/10 dark:border-white/15 text-xs">
                      <Lock size={18} className="text-[#b64b25] shrink-0 mt-0.5" />
                      <div>
                        <div className="font-semibold text-[#171512] dark:text-white">Security &amp; Data Privacy</div>
                        <div className="text-black/60 dark:text-white/60 mt-0.5">
                          Row-Level Database Isolation, Official Google OAuth2 encryption, PCI-compliant billing via Freemius.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Visual Trust Card */}
                <div className="dark-surface p-8 sm:p-10 rounded-3xl bg-[#171512] text-white border border-white/15 shadow-none space-y-6 relative overflow-hidden">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <BrandLogo theme="dark" iconClassName="h-8 w-8" textClassName="text-[22px]" />
                    </div>
                    <span className="text-[10px] tracking-widest text-[#f3a37f] uppercase font-semibold">
                      Verified Platform
                    </span>
                  </div>

                  <div className="space-y-4 text-xs text-white/80 leading-relaxed">
                    <p className="italic font-serif text-sm sm:text-base text-white/95">
                      “Our objective has never changed since day one: make local businesses noticeably easier
                      to discover, trust, and convert on Google, while freeing operators from repetitive daily marketing chores.”
                    </p>
                    <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-white/60">
                      <span>Trendexhub Corporate Governance</span>
                      <span>Founded 2021 · Uganda</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center">
                      <div className="font-serif text-2xl font-bold text-white">100%</div>
                      <div className="text-[10px] text-white/60 mt-1">Google API Compliant</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center">
                      <div className="font-serif text-2xl font-bold text-white">24/7</div>
                      <div className="text-[10px] text-white/60 mt-1">Autonomous Execution</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 5. HIGH-CONVERSION BOTTOM CTA */}
          <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
            <div className="dark-surface rounded-3xl bg-[#171512] border border-white/15 text-white text-center p-8 sm:p-14 space-y-6 shadow-none">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/15 px-4 py-1.5 text-xs font-semibold text-[#f3a37f] uppercase tracking-wider">
                <Zap size={14} className="text-[#f3a37f]" />
                <span>Start Growing Your Local Profile Today</span>
              </div>

              <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-white max-w-3xl mx-auto leading-tight">
                Ready to Turn Google Searches Into Loyal Customers?
              </h2>

              <p className="text-base sm:text-lg text-white/70 max-w-xl mx-auto leading-relaxed">
                Join hundreds of trusted businesses and growth agencies scaling their Google Business Profile
                presence automatically with Trendit.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
                <Button
                  size="lg"
                  className="rounded-full px-8 text-sm font-semibold bg-[#b64b25] hover:bg-[#a03f1d] text-white w-full sm:w-auto shadow-none"
                  asChild
                >
                  <Link to="/" hash="pricing">
                    <span>Get Started Free</span>
                    <ArrowRight size={16} className="ml-2" />
                  </Link>
                </Button>

                <GoogleConnectButton
                  size="lg"
                  source="about_bottom_cta"
                  variant="outline"
                  className="rounded-full px-7 text-sm font-semibold border-white/20 text-white hover:bg-white/10 w-full sm:w-auto shadow-none justify-center"
                >
                  Connect Google Business Profile
                </GoogleConnectButton>
              </div>

              <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-white/50">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  Official Google API integration
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  No credit card required for audit
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  Cancel anytime with 1 click
                </span>
              </div>
            </div>
          </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=1200&q=82", alt: "A team reviewing a business plan", eyebrow: "Collaboration", title: "Ideas become practical growth" },
          { src: "https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&w=1200&q=82", alt: "A creative business meeting", eyebrow: "Momentum", title: "Move from strategy to action" },
          { src: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1200&q=82", alt: "A professional workspace with people working", eyebrow: "Execution", title: "Built for everyday business growth" },
        ]} />
        </main>
      </div>

      <SiteFooter />
    </div>
  );
}
