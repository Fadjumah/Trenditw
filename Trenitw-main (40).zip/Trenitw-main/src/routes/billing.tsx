import { useState, useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { FreemiusCheckoutButton } from "@/components/checkout-button";
import { useAuthState } from "@/hooks/use-auth-state";
import { Button } from "@/components/ui/button";
import { apiFetch } from "@/lib/api";
import { PRICING_PLANS, getFreemiusPlanIdForTier } from "@/lib/pricing-plans";
import {
  Check,
  CheckCircle2,
  ShieldCheck,
  Clock,
  ArrowRight,
  CreditCard,
  LayoutDashboard,
} from "lucide-react";

export const Route = createFileRoute("/billing")({
  validateSearch: (search: Record<string, unknown>) => ({
    customer_id: (search.customer_id as string) || undefined,
    location_id: (search.location_id as string) || undefined,
    email: (search.email as string) || undefined,
  }),
  head: () => ({
    meta: [
      { title: "Billing & Subscription — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: BillingPage,
});

function BillingPage() {
  const { customer_id, location_id, email } = Route.useSearch();
  const { isAuthenticated, customerId: authCustomerId } = useAuthState();
  const navigate = useNavigate();
  const [entitlement, setEntitlement] = useState<any>(null);
  const [loadingEntitlement, setLoadingEntitlement] = useState(true);

  const activeCustomerId =
    customer_id ||
    authCustomerId ||
    (typeof window !== "undefined"
      ? localStorage.getItem("trendit_customer_id")
      : null);

  const activeLocationId =
    location_id ||
    (typeof window !== "undefined"
      ? localStorage.getItem("trendit_location_id")
      : null);

  const activeEmail =
    email ||
    (typeof window !== "undefined"
      ? localStorage.getItem("trendit_email")
      : null);

  useEffect(() => {
    if (activeCustomerId) {
      apiFetch(`/api/user/entitlement/${activeCustomerId}`)
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data) setEntitlement(data);
        })
        .catch(() => null)
        .finally(() => setLoadingEntitlement(false));
    } else {
      setLoadingEntitlement(false);
    }
  }, [activeCustomerId]);

  const isFreePlan = entitlement?.plan === "free";

  const handleSuccess = async () => {
    if (!activeCustomerId) {
      return;
    }

    // Never assume that reaching/closing checkout means the trial or
    // subscription was activated. Confirm the authoritative entitlement first.
    try {
      const res = await apiFetch(`/api/user/entitlement/${activeCustomerId}`);
      const data = res.ok ? await res.json() : null;
      if (!data?.has_access) {
        setEntitlement(data);
        return;
      }

      setEntitlement(data);
      navigate({
        to: "/dashboard",
        search: {
          customer_id: activeCustomerId,
          location_id: activeLocationId || undefined,
          email: activeEmail || undefined,
        },
      });
    } catch {
      // Stay on billing if activation cannot be verified.
    }
  };



  return (
    <div className="app-editorial billing-editorial min-h-screen bg-background text-foreground flex flex-col justify-between">
      <SiteNav />

      <main className="flex-1 max-w-7xl 2xl:max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-12 sm:py-16 w-full">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3.5 py-1 text-xs font-semibold text-primary">
            <span>Billing & Subscription Management</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl tracking-tight text-foreground">
            {entitlement?.has_access ? "Your Subscription" : "Trendit Pro Subscription"}
          </h1>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
            {entitlement?.has_access
              ? "Manage your active subscription below."
              : "Start your 30-day free trial. Cancel or manage anytime."}
          </p>
        </div>

        {/* Active Subscription Banner */}
        {entitlement?.has_access && !isFreePlan && (
          <div className="max-w-4xl mx-auto mb-10 rounded-2xl border-2 border-emerald-500/40 bg-emerald-500/10 p-6 sm:p-8 space-y-6 shadow-md">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-foreground">
                    Active Subscription
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Your plan is active and in good standing. All growth tools are unlocked.
                  </p>
                </div>
              </div>
              <Button
                onClick={handleSuccess}
                className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-6 shrink-0"
              >
                <LayoutDashboard className="mr-2 h-4 w-4" />
                Go to Dashboard
              </Button>
            </div>
          </div>
        )}

        {/* Pro Card Container */}
        <div className="max-w-xl mx-auto">
          {PRICING_PLANS.filter((plan) => plan.id !== "free").map((plan) => {
            const isPopular = plan.popular;
            return (
              <div
                key={plan.id}
                className={`rounded-3xl p-7 sm:p-8 flex flex-col justify-between relative transition-all duration-200 border border-border/80 shadow-none bg-card ${
                  isPopular ? "lg:-translate-y-2 shadow-md" : ""
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-3.5 left-6">
                    <span className="rounded-full bg-[#b64b25] px-3.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div>
                  <div className="pb-6 border-b border-border/60">
                    <h3 className="font-serif text-2xl font-bold text-foreground">
                      {plan.name}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground leading-relaxed min-h-[34px]">
                      {plan.description}
                    </p>
                    <div className="mt-5 flex items-baseline gap-2.5">
                      <div className="flex items-baseline gap-1">
                        <span className="text-xs font-sans font-bold uppercase tracking-wider text-muted-foreground">
                          Was
                        </span>
                        <del className="font-serif text-2xl sm:text-3xl font-extrabold text-red-600 dark:text-red-400 line-through decoration-red-500 decoration-[2.5px]">
                          ${plan.originalPrice}
                        </del>
                      </div>
                      <span className="font-serif text-4xl sm:text-5xl font-bold text-foreground">
                        ${plan.price}
                      </span>
                      <span className="text-xs font-semibold text-muted-foreground">
                        {plan.period}
                      </span>
                    </div>
                  </div>

                  <div className="py-6 space-y-3 text-xs sm:text-sm text-foreground/90">
                    <p className="font-bold text-xs uppercase tracking-wider text-muted-foreground">
                      Included in {plan.name}:
                    </p>
                    {plan.features.map((item) => (
                      <div key={item} className="flex items-start gap-3">
                        <Check
                          size={16}
                          className="text-[#b64b25] shrink-0 mt-0.5"
                        />
                        <span className="leading-snug">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-border/60 space-y-2">
                  {entitlement?.has_access ? (
                    <Button
                      variant="outline"
                      className="w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none"
                      onClick={handleSuccess}
                    >
                      Plan Active
                    </Button>
                  ) : (
                    <FreemiusCheckoutButton
                      service="core"
                      planId={getFreemiusPlanIdForTier(plan)}
                      billingCycle="monthly"
                      trial={!!plan.hasTrial}
                      successPath="/dashboard"
                      onSuccess={handleSuccess}
                      className={`w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none ${
                        isPopular
                          ? "bg-[#b64b25] text-white hover:bg-[#a03f1d]"
                          : "bg-foreground text-background hover:bg-foreground/90"
                      }`}
                    >
                      {plan.ctaText}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </FreemiusCheckoutButton>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Trust & Guarantee */}
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mt-12">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <span>Secure 256-bit encrypted checkout powered by Freemius. Cancel or switch anytime.</span>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
