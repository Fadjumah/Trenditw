import {
  createFileRoute,
  useSearch,
  useNavigate,
} from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import {
  CheckCircle2,
  Clock,
  MessageSquare,
  Loader2,
  XCircle,
  Eye,
  AlertCircle,
  ShieldCheck,
  ArrowRight,
  Mail,
  ChevronDown,
  ChevronUp,
  Activity,
  Calendar,
  RefreshCw,
  Check,
  ExternalLink,
  Camera,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ReviewsDashboard } from "@/components/reviews/ReviewsDashboard";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { track } from "@/lib/analytics";
import { apiFetch } from "@/lib/api";
import { ManageConnection } from "@/components/manage-connection";
import {
  AuditChatModal,
  type AuditMessage,
} from "@/components/audit-chat-modal";
import { GrowthUpgradeModal } from "@/components/growth-upgrade-modal";
import { AutopilotScheduleCard } from "@/components/autopilot-schedule-card";
import { GrowthDashboard } from "@/components/growth-dashboard";
import { BusinessPerformanceMetrics } from "@/components/business-performance-metrics";

const dashboardSearchSchema = z.object({
  customer_id: z.string().optional(),
  location_id: z.string().optional(),
  email: z.string().optional(),
});

export const Route = createFileRoute("/dashboard")({
  validateSearch: dashboardSearchSchema,
  head: () => ({
    meta: [
      { title: "Dashboard — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Dashboard,
});

function formatDisplayTime(timeStr?: string) {
  if (!timeStr) return "9:00 AM";
  const parts = timeStr.split(":");
  if (parts.length < 2) return timeStr;
  const h = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  if (isNaN(h) || isNaN(m)) return timeStr;
  const period = h >= 12 ? "PM" : "AM";
  const displayH = h % 12 === 0 ? 12 : h % 12;
  const displayM = m < 10 ? `0${m}` : `${m}`;
  return `${displayH}:${displayM} ${period}`;
}

function Dashboard() {
  const { customer_id, location_id, email } = useSearch({ from: "/dashboard" });
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [fetchingProfile, setFetchingProfile] = useState(true);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [scheduleSettings, setScheduleSettings] = useState<{
    autopilot_enabled?: boolean;
    posting_time?: string;
    posting_timezone?: string;
    posting_frequency?: string;
    posting_days?: string[];
    last_autopilot_post_at?: string | null;
    next_scheduled_post?: {
      next_run_iso?: string;
      next_run_local?: string;
      timezone?: string;
      is_today?: boolean;
    } | null;
    next_run_at?: string | null;
  } | null>(null);
  const [processingAction, setProcessingAction] = useState<string | null>(null);
  const [auditId, setAuditId] = useState<string | null>(null);
  const [auditProgress, setAuditProgress] = useState(0);
  const [auditStep, setAuditStep] = useState("");
  const [auditStatus, setAuditStatus] = useState<
    "idle" | "running" | "complete" | "completed_with_warnings" | "failed"
  >("idle");
  const [auditError, setAuditError] = useState<string | null>(null);
  const [auditResult, setAuditResult] = useState<any>(null);
  const [emailingReport, setEmailingReport] = useState(false);
  const [reportEmailed, setReportEmailed] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [auditSummaryExpanded, setAuditSummaryExpanded] = useState(false);
  const [draftExpanded, setDraftExpanded] = useState(false);
  const [auditMessages, setAuditMessages] = useState<AuditMessage[]>([]);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [upgradeModalConfig, setUpgradeModalConfig] = useState({
    title: "Unlock Trendit Pro",
    description:
      "Take your Google Business Profile to the next level with automated daily activity and smart review management.",
    highlightFeature: "",
  });
  const auditStreamEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    auditStreamEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [auditMessages]);

  const [entitlement, setEntitlement] = useState<{
    has_subscription: boolean;
    has_access?: boolean;
    plan?: string | null;
    status?: string;
    is_trial?: boolean;
    limits?: {
      audit_available?: boolean;
      next_audit_at?: string | null;
      posts_30d?: number;
      posts_30d_limit?: number;
      posts_available?: boolean;
      next_post_reset_at?: string | null;
    } | null;
    entitlement?: {
      license_id?: string;
      product_id?: string;
      plan_id?: string;
      pricing_id?: string;
      type?: string;
      status?: string;
      is_trial?: boolean;
      trial_ends_at?: string | null;
      expiration?: string | null;
      last_synced_at?: string | null;
    } | null;
  } | null>(null);

  const fetchEntitlement = async (id: string, userEmailAddress?: string) => {
    try {
      const response = await apiFetch(`/api/user/entitlement/${id}`);
      if (response.ok) {
        const data = await response.json();
        setEntitlement(data);

        // Entitlement is authoritative. Never attempt to create/sync a
        // purchase from the dashboard just because a user has reached checkout.
        // Purchase synchronization is performed only by the Freemius
        // purchase-completed callback after a verified license is returned.
      } else if (response.status === 401 || response.status === 403) {
        setEntitlement(null);
      }
    } catch (e) {
      console.error("Failed to fetch entitlement:", e);
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedCustomerId =
        customer_id || localStorage.getItem("trendit_customer_id");
      const storedToken = localStorage.getItem("trendit_token");

      if (!storedCustomerId || !storedToken) {
        navigate({ to: "/" });
        return;
      }

      let changed = false;
      const storedEmail = email || localStorage.getItem("trendit_email");

      if (customer_id) {
        localStorage.setItem("trendit_customer_id", customer_id);
        changed = true;
      }
      if (location_id) {
        localStorage.setItem("trendit_location_id", location_id);
        changed = true;
      }
      if (email) {
        localStorage.setItem("trendit_email", email);
        changed = true;
      }

      setUserEmail(storedEmail);

      if (changed && customer_id) {
        toast.success("Welcome back!", {
          description: "Your session has been restored.",
        });
      }

      if (storedCustomerId) {
        fetchProfile(storedCustomerId);
        fetchScheduleSettings(storedCustomerId);
        fetchEntitlement(storedCustomerId, storedEmail || undefined);
      }
    }
  }, [customer_id, location_id, email]);

  // Listen for real-time schedule updates from AutopilotScheduleCard
  useEffect(() => {
    const handleScheduleUpdated = (e: any) => {
      if (e.detail) {
        setScheduleSettings(e.detail);
      }
    };
    window.addEventListener("trendit_schedule_updated", handleScheduleUpdated);
    return () => {
      window.removeEventListener("trendit_schedule_updated", handleScheduleUpdated);
    };
  }, []);

  // Dedicated polling effect to avoid stale closures
  useEffect(() => {
    const storedCustomerId =
      customer_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_customer_id")
        : null);
    if (!storedCustomerId) return;

    const shouldPoll = profile?.onboarding_status !== "complete" || generating;
    if (shouldPoll) {
      const interval = setInterval(() => {
        fetchProfile(storedCustomerId);
        fetchScheduleSettings(storedCustomerId);
      }, 10000);
      return () => clearInterval(interval);
    }
  }, [profile?.onboarding_status, generating, customer_id]);

  // Billing webhooks may arrive shortly after checkout. Keep the dashboard
  // authoritative and automatically transition a newly-paid user to active.
  useEffect(() => {
    const storedCustomerId =
      customer_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_customer_id")
        : null);
    if (!storedCustomerId || entitlement?.has_access === true) return;

    const interval = setInterval(() => {
      fetchEntitlement(storedCustomerId);
    }, 3000);

    return () => clearInterval(interval);
  }, [customer_id, entitlement?.has_access]);

  const fetchProfile = async (id: string) => {
    try {
      const response = await apiFetch(`/api/user/profile/${id}`);
      if (response.ok) {
        const data = await response.json();
        setProfile(data);
        if (data.email) {
          setUserEmail(data.email);
          localStorage.setItem("trendit_email", data.email);
        }
        if (data.location_id) {
          localStorage.setItem("trendit_location_id", data.location_id);
        }
        if (data.business_name) {
          localStorage.setItem("trendit_business_name", data.business_name);
        }
        window.dispatchEvent(new Event("trendit_auth_change"));
      }
    } catch (e) {
      console.error("Failed to fetch profile:", e);
    } finally {
      setFetchingProfile(false);
    }
  };

  const fetchScheduleSettings = async (id: string) => {
    try {
      const response = await apiFetch(`/api/user/schedule-settings/${id}`);
      if (response.ok) {
        const data = await response.json();
        setScheduleSettings(data);
        if (generating) {
          setGenerating(false);
        }
      }
    } catch (e) {
      console.error("Failed to fetch schedule settings:", e);
    }
  };

  const reconnectGoogle = () => {
    const backendUrl =
      import.meta.env.VITE_BACKEND_URL || "https://trendit-4ocu.onrender.com";
    track("google_reconnect_requested", {
      user_id:
        profile?.customer_id ||
        customer_id ||
        localStorage.getItem("trendit_customer_id") ||
        undefined,
      source: "dashboard_google_auth_recovery",
    });
    window.location.href = `${backendUrl}/oauth/google?state=reauth`;
  };

  const handleGenerateDraft = async () => {
    const cid =
      profile?.customer_id ||
      customer_id ||
      localStorage.getItem("trendit_customer_id");
    const lid =
      profile?.location_id ||
      location_id ||
      localStorage.getItem("trendit_location_id");
    if (!cid || !lid) {
      toast.error("Missing profile info. Please reconnect your GBP.");
      return;
    }

    setGenerating(true);
    track("manual_generation_click", {
      user_id: cid,
      business_id: lid,
      location_id: lid,
    });

    try {
      const response = await apiFetch("/api/user/generate-draft", {
        method: "POST",
        body: JSON.stringify({
          customer_id: cid,
          location_id: lid,
          post_type: "standard",
        }),
      });

      if (response.ok) {
        const data = await response.json().catch(() => ({}));
        if (data?.status === "duplicate_blocked") {
          toast.info("Active Draft Present", {
            description:
              data.message ||
              "A Growth Post draft is already waiting for your approval below.",
          });
        } else {
          toast.success("Growth Post Ready!", {
            description:
              "Trendit prepared a new post tailored to your services.",
          });
        }
        await fetchScheduleSettings(cid);
        setGenerating(false);
      } else if (response.status === 409) {
        setGenerating(false);
        let detail: any = null;
        try {
          detail = await response.json();
        } catch {}
        if (detail?.detail?.code === "GOOGLE_REAUTH_REQUIRED") {
          toast.error("Google Reconnection Required", {
            description:
              "Your Google Business Profile authorization has expired or been revoked. Reconnect your Google account to generate Growth Posts.",
            action: { label: "Reconnect Google", onClick: reconnectGoogle },
          });
        } else {
          toast.error("Growth Post unavailable", {
            description: detail?.detail?.message || "Please try again.",
          });
        }
      } else if (response.status === 402) {
        setGenerating(false);
        setUpgradeModalConfig({
          title: "Unlock Daily Automated Posts",
          description:
            "You have used your 1 free sample post draft. Unlock continuous daily localized drafts, AI images, and automated post queue scheduling with Trendit Pro (30-day free trial).",
          highlightFeature: "Daily automated post drafts & scheduling",
        });
        setUpgradeModalOpen(true);
      } else {
        toast.error("Drafting failed. Please try again in a moment.");
        setGenerating(false);
      }
    } catch (err) {
      console.error("Generation error:", err);
      toast.error("An unexpected error occurred.");
      setGenerating(false);
    }
  };

  const connectAuditStream = (id: string) => {
    setAuditMessages([]);
    setAuditProgress(5);
    setAuditStep("Connecting to Google Business Profile…");

    apiFetch(`/api/user/audit/${id}/stream`)
      .then(async (res) => {
        if (!res.ok || !res.body) {
          pollAuditStatus(id);
          return;
        }
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            try {
              const msg: AuditMessage = JSON.parse(line.slice(6));
              if (msg.progress_pct !== undefined && msg.progress_pct !== null) {
                setAuditProgress(msg.progress_pct);
              }
              if (msg.type === "thought") {
                setAuditStep(msg.text.replace(/\*\*/g, "").slice(0, 80));
              } else if (msg.type === "section") {
                setAuditStep(msg.text.replace(/\*\*/g, ""));
              }
              if (msg.type === "done") {
                setAuditProgress(100);
                const fullRes = await apiFetch(`/api/user/audit/${id}`);
                if (fullRes.ok) {
                  const full = await fullRes.json();
                  setAuditResult(full);
                  setAuditStatus((msg.status as any) ?? "complete");
                  if (msg.status === "completed_with_warnings") {
                    if (full.needs_reauth) {
                      toast.error("Google Reconnection Required", {
                        description:
                          "Your Google Business Profile authorization has expired or been revoked. Reconnect your Google account to restore full audit access.",
                        action: {
                          label: "Reconnect Google",
                          onClick: reconnectGoogle,
                        },
                      });
                    } else {
                      toast.warning("Audit Complete (with warnings)", {
                        description: `Your GBP scored Grade ${full.overall_grade} (${full.overall_score}/100) with some partial data.`,
                      });
                    }
                  } else {
                    toast.success("Audit Complete!", {
                      description: `Your GBP scored Grade ${full.overall_grade} (${full.overall_score}/100).`,
                    });
                  }
                } else {
                  setAuditStatus("complete");
                  toast.success("Audit Complete!");
                }
              }
            } catch (e) {
              console.warn("Error parsing SSE audit message", e);
            }
          }
        }
      })
      .catch((err) => {
        console.warn("Audit SSE stream error, falling back to polling", err);
        pollAuditStatus(id);
      });
  };

  const handleAuditGBP = async () => {
    const cid =
      profile?.customer_id ||
      customer_id ||
      localStorage.getItem("trendit_customer_id");
    const lid =
      profile?.location_id ||
      location_id ||
      localStorage.getItem("trendit_location_id");
    if (!cid || !lid) {
      toast.error("Missing profile info. Please reconnect your GBP.");
      return;
    }

    setAuditStatus("running");
    setAuditProgress(0);
    setAuditStep("Initializing GBP audit…");
    setAuditError(null);
    setAuditResult(null);
    setAuditMessages([]);
    setIsAuditModalOpen(true);

    track("audit_initiated", {
      user_id: cid,
      business_id: lid,
      location_id: lid,
    });

    try {
      const res = await apiFetch("/api/user/audit/start", {
        method: "POST",
        body: JSON.stringify({ customer_id: cid, location_id: lid }),
      });
      if (res.status === 429) {
        setAuditStatus("idle");
        let detail: any = null;
        try {
          detail = await res.json();
        } catch {}
        toast.info("Free audit limit reached", {
          description:
            detail?.detail?.message ||
            "Free tier audits are available once every 7 days. Your audit will unlock automatically after the waiting period.",
        });
        return;
      }
      if (res.status === 402) {
        setAuditStatus("idle");
        setUpgradeModalConfig({
          title: "Unlock Deep Audit Fixes",
          description:
            "Automated profile health optimization and continuous monitoring require an active Trendit subscription.",
          highlightFeature:
            "Automated profile audits and continuous monitoring",
        });
        setUpgradeModalOpen(true);
        return;
      }
      if (res.status === 409) {
        setAuditStatus("idle");
        let detail: any = null;
        try {
          detail = await res.json();
        } catch {}
        if (detail?.detail?.code === "GOOGLE_REAUTH_REQUIRED") {
          toast.error("Google Reconnection Required", {
            description:
              "Your Google Business Profile authorization has expired or been revoked. Reconnect your Google account before running an audit.",
            action: { label: "Reconnect Google", onClick: reconnectGoogle },
          });
        } else {
          toast.error("Couldn't start the audit", {
            description: detail?.detail?.message || "Please try again.",
          });
        }
        return;
      }
      if (!res.ok) throw new Error("start failed");
      const { audit_id } = await res.json();
      setAuditId(audit_id);
      connectAuditStream(audit_id);
    } catch (err) {
      console.error("Audit start error:", err);
      toast.error("Couldn't start the audit. Please try again.");
      setAuditStatus("idle");
    }
  };

  const pollAuditStatus = (id: string) => {
    const interval = setInterval(async () => {
      try {
        const res = await apiFetch(`/api/user/audit/${id}/status`);
        if (!res.ok) return;
        const data = await res.json();
        setAuditProgress(data.progress_pct);
        setAuditStep(data.current_step || "");

        if (
          data.status === "complete" ||
          data.status === "completed_with_warnings"
        ) {
          clearInterval(interval);
          const fullRes = await apiFetch(`/api/user/audit/${id}`);
          const full = await fullRes.json();
          setAuditResult(full);
          setAuditStatus(data.status);
          if (data.status === "completed_with_warnings") {
            if (full.needs_reauth) {
              toast.error("Google Reconnection Required", {
                description:
                  "Your Google Business Profile authorization has expired or been revoked. Reconnect your Google account to restore audit access.",
                action: { label: "Reconnect Google", onClick: reconnectGoogle },
              });
            } else {
              toast.warning("Audit Complete (with warnings)", {
                description: `Your GBP scored Grade ${full.overall_grade} (${full.overall_score}/100) with some partial data.`,
              });
            }
          } else {
            toast.success("Audit Complete!", {
              description: `Your GBP scored Grade ${full.overall_grade} (${full.overall_score}/100).`,
            });
          }
        } else if (data.status === "failed") {
          clearInterval(interval);
          const fullRes = await apiFetch(`/api/user/audit/${id}`);
          const full = fullRes.ok ? await fullRes.json() : null;
          const reason =
            full?.error_message ||
            data.error_message ||
            "Audit could not be completed.";
          setAuditError(reason);
          setAuditStatus("failed");
          if (reason.startsWith("needs_reauth:")) {
            toast.error("Google Reconnection Required", {
              description:
                "Your Google Business Profile authorization has expired or been revoked. Reconnect your Google account to run the audit.",
              action: { label: "Reconnect Google", onClick: reconnectGoogle },
            });
          } else {
            toast.error("Audit failed", { description: reason });
          }
        }
      } catch (err) {
        console.error("Poll error:", err);
      }
    }, 900);
  };

  const handleEmailReport = async () => {
    if (!auditId) return;
    setEmailingReport(true);
    try {
      const res = await apiFetch(`/api/user/audit/${auditId}/email`, {
        method: "POST",
      });
      if (res.ok) {
        setReportEmailed(true);
        toast.success("Report sent!", {
          description: "Check your inbox for the full audit.",
        });
      } else {
        toast.error("Couldn't send the report. Please try again.");
      }
    } catch (err) {
      toast.error("Couldn't send the report. Please try again.");
    } finally {
      setEmailingReport(false);
    }
  };



  const scoreColor = (score?: number) => {
    if (!score && score !== 0) return "text-rose-700 dark:text-rose-400";
    if (score >= 90) return "text-emerald-700 dark:text-emerald-400";
    if (score >= 75) return "text-blue-700 dark:text-blue-400";
    if (score >= 60) return "text-amber-700 dark:text-amber-400";
    if (score >= 40) return "text-orange-700 dark:text-orange-400";
    return "text-rose-700 dark:text-rose-400";
  };

  const scoreBg = (score?: number) => {
    if (!score && score !== 0)
      return "bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-400";
    if (score >= 90)
      return "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-400";
    if (score >= 75)
      return "bg-blue-500/10 border-blue-500/30 text-blue-700 dark:text-blue-400";
    if (score >= 60)
      return "bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400";
    if (score >= 40)
      return "bg-orange-500/10 border-orange-500/30 text-orange-700 dark:text-orange-400";
    return "bg-rose-500/10 border-rose-500/30 text-rose-700 dark:text-rose-400";
  };



  const businessDisplayName = fetchingProfile
    ? "Loading business…"
    : profile?.business_name || "Business Workspace";

  const isAuditComplete =
    auditStatus === "complete" || auditStatus === "completed_with_warnings";

  return (
    <div className="dashboard-editorial min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col justify-between overflow-x-hidden">
      <div>
        <SiteNav />

        <main className="mx-auto w-full max-w-7xl 2xl:max-w-[1536px] px-5 py-8 sm:px-8 lg:px-12 sm:py-12">
          <div className="space-y-8 sm:space-y-10">
            {/* 1. DASHBOARD HEADER (Editorial Workspace Header) */}
            <div className="pb-8 border-b border-black/10 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
              <div className="space-y-1.5 min-w-0 flex-1">
                <div className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
                  Trendit · Business Workspace
                </div>
                <h1 className="font-serif text-3xl leading-tight tracking-tight sm:text-4xl truncate">
                  {businessDisplayName}
                </h1>
                <div className="mt-4 max-w-5xl">
                  <BusinessPerformanceMetrics
                    customerId={
                      profile?.customer_id || customer_id ||
                      (typeof window !== "undefined" ? localStorage.getItem("trendit_customer_id") || "" : "")
                    }
                    locationId={
                      profile?.location_id || location_id ||
                      (typeof window !== "undefined" ? localStorage.getItem("trendit_location_id") || undefined : undefined)
                    }
                  />
                </div>
                <p className="mt-2 text-sm text-black/60">
                  Signed in as{" "}
                  <span className="text-sm font-medium">
                    {userEmail || "..."}
                  </span>
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 sm:gap-3 shrink-0">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-xs font-medium">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  <span>Connected to Google</span>
                </div>

                {profile?.business_name && (
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      profile.business_name
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-muted/60 hover:bg-muted text-foreground text-xs font-medium transition-all shadow-2xs"
                    title="View live public listing on Google Maps / Search"
                  >
                    <span>View on Google</span>
                    <ExternalLink size={12} className="text-muted-foreground" />
                  </a>
                )}

                {profile?.customer_id && (
                  <ManageConnection
                    customerId={profile.customer_id}
                    businessName={profile.business_name}
                    currentLocationId={location_id || profile.location_id}
                    hasAccess={Boolean(entitlement?.has_access)}
                  />
                )}
              </div>
            </div>

            {/* 2. BUSINESS CONTEXT STRIP */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-0 rounded-3xl border border-black/10 bg-white overflow-hidden">
              <div className="space-y-2 p-5 sm:p-6 sm:border-r sm:border-black/10">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-black/45">
                  Business
                </span>
                <p className="text-sm font-semibold truncate">
                  {businessDisplayName}
                </p>
              </div>

              <div className="space-y-2 p-5 sm:p-6 sm:border-r sm:border-black/10">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-black/45">
                  Google Business Profile
                </span>
                <p className="text-sm font-medium flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                  <span>Connected</span>
                </p>
              </div>

              <div className="space-y-2 flex flex-col justify-between p-5 sm:p-6">
                <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-black/45">
                  Subscription Plan
                </span>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium text-foreground">
                    {entitlement?.has_access
                      ? "Active Subscription"
                      : "Inactive"}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      navigate({
                        to: "/billing",
                        search: {
                          customer_id:
                            customer_id ||
                            localStorage.getItem("trendit_customer_id") ||
                            undefined,
                          location_id:
                            location_id ||
                            localStorage.getItem("trendit_location_id") ||
                            undefined,
                          email: userEmail || undefined,
                        },
                      })
                    }
                    className="text-xs font-semibold text-accent hover:underline cursor-pointer shrink-0"
                  >
                    {entitlement?.has_access ? "Manage" : "Subscribe"} →
                  </button>
                </div>
              </div>
            </div>

            {/* 4. PRODUCT WORKFLOW STATUS (Editorial Numbered Sequence) */}
            <section className="space-y-3">
              <div className="text-[11px] font-mono font-bold uppercase tracking-widest text-muted-foreground">
                Trendit Workflow
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
                <div className="p-4 sm:p-5 rounded-3xl border border-black/10 dark:border-white/15 bg-card shadow-none space-y-1">
                  <div className="text-xs font-mono font-bold text-accent">
                    01
                  </div>
                  <div className="text-xs font-semibold text-foreground">
                    Profile
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {auditResult ? "Completed" : "Ready to check"}
                  </div>
                </div>

                <div className="p-4 sm:p-5 rounded-3xl border border-black/10 dark:border-white/15 bg-card shadow-none space-y-1">
                  <div className="text-xs font-mono font-bold text-accent">
                    02
                  </div>
                  <div className="text-xs font-semibold text-foreground">
                    Autopilot
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {scheduleSettings?.autopilot_enabled ? "Active" : "Paused"}
                  </div>
                </div>

                <div className="p-4 sm:p-5 rounded-3xl border border-black/10 dark:border-white/15 bg-card shadow-none space-y-1">
                  <div className="text-xs font-mono font-bold text-accent">
                    03
                  </div>
                  <div className="text-xs font-semibold text-foreground">
                    Schedule
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {scheduleSettings?.posting_time
                      ? scheduleSettings.posting_frequency === "daily" ||
                        !scheduleSettings.posting_days ||
                        scheduleSettings.posting_days.length === 7
                        ? `Daily at ${scheduleSettings.posting_time}`
                        : `${scheduleSettings.posting_days.length} days/wk at ${scheduleSettings.posting_time}`
                      : "Configured"}
                  </div>
                </div>

                <div className="p-4 sm:p-5 rounded-3xl border border-black/10 dark:border-white/15 bg-card shadow-none space-y-1">
                  <div className="text-xs font-mono font-bold text-accent">
                    04
                  </div>
                  <div className="text-xs font-semibold text-foreground">
                    Publish
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {scheduleSettings?.autopilot_enabled
                      ? "Autonomous"
                      : "Manual"}
                  </div>
                </div>
              </div>
            </section>

            {/* 5. TABS / WORKSPACE NAVIGATION */}
            <Tabs
              value={activeTab}
              onValueChange={(value) => {
                if (value === "audit" && entitlement?.has_access !== true) {
                  setUpgradeModalConfig({
                    title: "Unlock Profile Audit",
                    description:
                      "Profile auditing requires an active Trendit Pro subscription or trial. Complete checkout to access the GBP Audit.",
                    highlightFeature: "22-point Google Business Profile audit and diagnostics",
                  });
                  setUpgradeModalOpen(true);
                  return;
                }
                setActiveTab(value);
              }}
              className="space-y-6"
            >
              <div className="border-b border-border/40">
                <TabsList className="bg-transparent p-0 h-auto gap-4 sm:gap-8 flex justify-start rounded-none">
                  <TabsTrigger
                    value="overview"
                    className="rounded-none border-b-2 border-transparent px-1 py-2.5 text-xs sm:text-sm font-medium text-muted-foreground data-[state=active]:border-accent data-[state=active]:text-foreground data-[state=active]:font-semibold data-[state=active]:shadow-none bg-transparent hover:text-foreground transition-all"
                  >
                    Overview
                  </TabsTrigger>
                  <TabsTrigger
                    value="audit"
                    className="rounded-none border-b-2 border-transparent px-1 py-2.5 text-xs sm:text-sm font-medium text-muted-foreground data-[state=active]:border-accent data-[state=active]:text-foreground data-[state=active]:font-semibold data-[state=active]:shadow-none bg-transparent hover:text-foreground transition-all flex items-center gap-1.5"
                  >
                    <span>GBP Audit</span>
                    {auditResult && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-accent/15 text-accent font-bold">
                        {auditResult.overall_score}/100
                      </span>
                    )}
                  </TabsTrigger>
                  <TabsTrigger
                    value="growth"
                    className="rounded-none border-b-2 border-transparent px-1 py-2.5 text-xs sm:text-sm font-medium text-muted-foreground data-[state=active]:border-accent data-[state=active]:text-foreground data-[state=active]:font-semibold data-[state=active]:shadow-none bg-transparent hover:text-foreground transition-all"
                  >
                    Growth
                  </TabsTrigger>
                  <TabsTrigger
                    value="reviews"
                    className="rounded-none border-b-2 border-transparent px-1 py-2.5 text-xs sm:text-sm font-medium text-muted-foreground data-[state=active]:border-accent data-[state=active]:text-foreground data-[state=active]:font-semibold data-[state=active]:shadow-none bg-transparent hover:text-foreground transition-all"
                  >
                    Reviews
                  </TabsTrigger>
                </TabsList>
              </div>

              {/* OVERVIEW TAB CONTENT */}
              <TabsContent value="overview" className="space-y-6 pt-1">
                <div className="grid gap-6 md:grid-cols-2">
                  {/* LEFT: AUTOPILOT SCHEDULE MODULE */}
                  <AutopilotScheduleCard
                    customerId={
                      profile?.customer_id ||
                      customer_id ||
                      (typeof window !== "undefined"
                        ? localStorage.getItem("trendit_customer_id") || ""
                        : "")
                    }
                    locationId={
                      profile?.location_id ||
                      location_id ||
                      (typeof window !== "undefined"
                        ? localStorage.getItem("trendit_location_id") || ""
                        : "")
                    }
                    businessName={profile?.business_name}
                    hasAccess={!!entitlement?.has_access}
                    freeUsage={entitlement?.plan === "free" ? entitlement?.limits : null}
                    onUpgradeRequired={() => {
                      setUpgradeModalConfig({
                        title: "Unlock Automated Daily Posting",
                        description:
                          "Autonomous daily publishing to Google Business Profile requires an active Trendit Pro subscription.",
                        highlightFeature: "Daily automated post generation & live publishing",
                      });
                      setUpgradeModalOpen(true);
                    }}
                  />

                  {/* RIGHT: PROFILE HEALTH MODULE */}
                  <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-card p-6 sm:p-7 shadow-none flex flex-col justify-between space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-muted-foreground">
                          Profile Health
                        </span>
                        {auditResult && (
                          <span
                            className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${scoreBg(auditResult.overall_score)}`}
                          >
                            {auditResult.overall_score}/100
                          </span>
                        )}
                      </div>

                      {auditStatus === "running" ? (
                        <div className="space-y-2.5 py-4">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground font-medium">
                              {auditStep || "Inspecting profile factors…"}
                            </span>
                            <span className="font-mono font-bold text-accent">
                              {auditProgress}%
                            </span>
                          </div>
                          <Progress value={auditProgress} className="h-1.5" />
                        </div>
                      ) : auditResult ? (
                        <div className="space-y-3">
                          <p
                            className={`text-xs text-foreground/85 leading-relaxed ${
                              auditSummaryExpanded ? "" : "line-clamp-3"
                            }`}
                          >
                            {auditResult.summary_text}
                          </p>
                          {auditResult.summary_text && (
                            <button
                              type="button"
                              onClick={() =>
                                setAuditSummaryExpanded((prev) => !prev)
                              }
                              className="text-xs text-accent hover:underline font-medium inline-flex items-center gap-1 cursor-pointer"
                            >
                              <span>
                                {auditSummaryExpanded
                                  ? "Show less"
                                  : "Read more"}
                              </span>
                              {auditSummaryExpanded ? (
                                <ChevronUp size={12} />
                              ) : (
                                <ChevronDown size={12} />
                              )}
                            </button>
                          )}

                        </div>
                      ) : (
                        <div className="space-y-2">
                          <h3 className="font-serif text-lg font-bold text-foreground">
                            Not reviewed yet
                          </h3>
                          <p className="text-xs text-muted-foreground leading-relaxed">
                            22 key profile, ranking, and trust factors are ready
                            to be checked.
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="pt-4 border-t border-border/40 flex flex-wrap gap-2">
                      {auditResult ? (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setActiveTab("audit")}
                            className="flex-1 text-xs min-h-[38px] font-medium"
                          >
                            <span>View Full Audit</span>
                            <ArrowRight size={13} />
                          </Button>
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => setIsAuditModalOpen(true)}
                            className="text-xs min-h-[38px] gap-1.5 font-medium"
                          >
                            <Activity size={13} />
                            <span>Assistant</span>
                          </Button>
                        </>
                      ) : (
                        <Button
                          onClick={handleAuditGBP}
                          disabled={
                            !(
                              profile?.location_id ||
                              location_id ||
                              (typeof window !== "undefined" &&
                                localStorage.getItem("trendit_location_id"))
                            )
                          }
                          className="w-full text-xs min-h-[38px] bg-foreground text-background hover:bg-foreground/90 font-medium gap-1.5"
                        >
                          <Activity size={14} />
                          <span>Run Profile Audit</span>
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* GBP AUDIT TAB CONTENT */}
              <TabsContent value="audit" className="space-y-6 pt-1">
                <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-card p-5 sm:p-7 shadow-none space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1 max-w-xl">
                      <div className="text-[10px] font-mono font-bold uppercase tracking-widest text-muted-foreground">
                        Profile Diagnostic Center
                      </div>
                      <h2 className="font-serif text-xl sm:text-2xl font-bold text-foreground">
                        GBP Diagnostic Center
                      </h2>
                      <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                        Evaluate your Google Business Profile against 22 key
                        ranking, trust, and conversion factors.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <Button
                        onClick={() => setIsAuditModalOpen(true)}
                        className="text-xs sm:text-sm min-h-[40px] px-5 bg-foreground text-background hover:bg-foreground/90 font-medium gap-1.5 rounded-full"
                      >
                        <Activity size={15} />
                        <span>Diagnostic Assistant</span>
                      </Button>
                      <Button
                        onClick={handleAuditGBP}
                        disabled={auditStatus === "running"}
                        variant="outline"
                        className="text-xs sm:text-sm min-h-[40px] px-5 font-medium gap-1.5 rounded-full"
                      >
                        <RefreshCw
                          size={14}
                          className={
                            auditStatus === "running" ? "animate-spin" : ""
                          }
                        />
                        <span>
                          {auditStatus === "running"
                            ? "Auditing…"
                            : "Run Audit"}
                        </span>
                      </Button>
                    </div>
                  </div>

                  {auditStatus === "running" && (
                    <div className="pt-3 border-t border-border/40 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground flex items-center gap-2">
                          <Loader2
                            className="animate-spin text-accent"
                            size={14}
                          />
                          Auditing Google Business Profile data points…
                        </span>
                        <span className="font-mono font-bold text-accent">
                          {auditProgress}%
                        </span>
                      </div>
                      <Progress value={auditProgress} className="h-1.5" />
                    </div>
                  )}
                </div>

                {auditStatus === "failed" && (
                  <div className="rounded-3xl border border-destructive/25 bg-destructive/[0.06] p-6 sm:p-7 text-center max-w-lg mx-auto shadow-none space-y-3">
                    <AlertCircle
                      className="text-destructive mx-auto"
                      size={32}
                    />
                    <h3 className="font-serif text-lg font-bold text-destructive">
                      Audit Could Not Complete
                    </h3>
                    <p className="text-xs text-muted-foreground text-left bg-background/80 p-4 rounded-2xl border border-destructive/15">
                      {auditError ||
                        "The audit could not be completed. Please verify your Google connection and try again."}
                    </p>
                    <div className="flex justify-center gap-2 pt-1">
                      <Button
                        onClick={handleAuditGBP}
                        variant="outline"
                        size="sm"
                        className="text-xs gap-1.5 rounded-full"
                      >
                        <RefreshCw size={13} />
                        <span>Retry Audit</span>
                      </Button>
                      <Button
                        onClick={reconnectGoogle}
                        size="sm"
                        className="text-xs gap-1.5 bg-destructive text-destructive-foreground hover:bg-destructive/90 rounded-full"
                      >
                        <span>Reconnect Google</span>
                      </Button>
                    </div>
                  </div>
                )}

                {auditResult && (
                  <div className="space-y-6">
                    {/* Score Overview */}
                    <div className="grid gap-4 sm:grid-cols-2 items-center rounded-3xl border border-black/10 dark:border-white/15 bg-card p-5 sm:p-6 shadow-none">
                      <div>
                        <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground font-semibold">
                          Overall Score
                        </div>
                        <div
                          className={`font-serif text-4xl sm:text-5xl font-bold mt-1 ${scoreColor(auditResult.overall_score)}`}
                        >
                          {auditResult.overall_score}
                          <span className="text-sm text-muted-foreground font-normal">
                            {" "}
                            / 100
                          </span>
                        </div>
                      </div>

                      <div className="flex justify-start sm:justify-end gap-2 flex-wrap">
                        <Button
                          variant="secondary"
                          size="sm"
                          className="gap-2 text-xs min-h-[38px] px-5 font-medium rounded-full"
                          onClick={handleEmailReport}
                          disabled={emailingReport || reportEmailed}
                        >
                          <Mail size={14} />
                          <span>
                            {reportEmailed
                              ? "Report Emailed"
                              : emailingReport
                                ? "Sending…"
                                : "Email Full Report"}
                          </span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2 text-xs min-h-[38px] px-5 font-medium rounded-full"
                          onClick={() => setIsAuditModalOpen(true)}
                        >
                          <Activity size={14} />
                          <span>View Diagnostic</span>
                        </Button>
                      </div>
                    </div>

                    {/* Executive Summary */}
                    <div className="p-5 sm:p-6 bg-card rounded-3xl border border-black/10 dark:border-white/15 text-xs sm:text-sm text-foreground/85 leading-relaxed shadow-none space-y-1.5">
                      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground font-semibold">
                        Executive Summary
                      </div>
                      <p>{auditResult.summary_text}</p>
                    </div>

                    {/* Visual Optimization & Media Health */}
                    {(() => {
                      const photosCat = (auditResult.category_scores || []).find(
                        (c: any) =>
                          c.key === "photos" ||
                          (c.label || "").toLowerCase().includes("photo")
                      );
                      if (!photosCat) return null;

                      const checks = photosCat.checks || [];
                      const passedChecks = checks.filter((c: any) => c.passed);
                      const gapChecks = checks.filter(
                        (c: any) => !c.passed && c.status !== "UNAVAILABLE"
                      );

                      const volumeCheck = checks.find((c: any) =>
                        (c.name || "").toLowerCase().includes("volume")
                      );
                      const photoCount =
                        typeof volumeCheck?.evidence === "number"
                          ? volumeCheck.evidence
                          : volumeCheck?.value && !isNaN(parseInt(volumeCheck.value))
                            ? parseInt(volumeCheck.value)
                            : null;

                      const identityCheck = checks.find((c: any) =>
                        (c.name || "").toLowerCase().includes("identity")
                      );

                      const catCheck = checks.find((c: any) =>
                        (c.name || "").toLowerCase().includes("category coverage")
                      );
                      const categoriesList = Array.isArray(catCheck?.evidence)
                        ? catCheck.evidence
                        : [];

                      const freshnessCheck = checks.find((c: any) =>
                        (c.name || "").toLowerCase().includes("90 days")
                      );
                      const recencyText =
                        typeof freshnessCheck?.evidence === "string"
                          ? freshnessCheck.evidence
                          : freshnessCheck?.passed
                            ? "Within 90 days"
                            : "Stale";

                      return (
                        <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-card p-5 sm:p-7 shadow-none space-y-5">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/40 pb-4">
                            <div className="flex items-center gap-2.5">
                              <div className="p-2 rounded-xl bg-accent/10 text-accent">
                                <Camera size={18} />
                              </div>
                              <div>
                                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground font-semibold">
                                  Visual Optimization (22-Point Audit Rubric)
                                </div>
                                <h3 className="font-serif text-lg font-bold text-foreground">
                                  Visual Optimization & Media Health
                                </h3>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-medium text-muted-foreground">
                                Visual Score:
                              </span>
                              <Badge
                                variant={
                                  photosCat.earned_points >= 12
                                    ? "default"
                                    : photosCat.earned_points >= 8
                                      ? "secondary"
                                      : "outline"
                                }
                                className="font-mono text-xs px-2.5 py-0.5"
                              >
                                {photosCat.earned_points} / {photosCat.max_points || 15} pts (
                                {photosCat.pct ??
                                  Math.round(
                                    (photosCat.earned_points /
                                      (photosCat.max_points || 15)) *
                                      100
                                  )}
                                %)
                              </Badge>
                            </div>
                          </div>

                          {/* Quick Diagnostic Metrics */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            <div className="p-3.5 rounded-2xl bg-muted/30 space-y-1">
                              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                                Library Volume
                              </div>
                              <div className="font-serif text-xl font-bold text-foreground">
                                {photoCount !== null && photoCount !== undefined
                                  ? `${photoCount} Photos`
                                  : `${checks.length} checks`}
                              </div>
                              <div className="text-[11px] text-muted-foreground truncate">
                                {volumeCheck?.passed
                                  ? "Meets target volume"
                                  : "Below target volume"}
                              </div>
                            </div>

                            <div className="p-3.5 rounded-2xl bg-muted/30 space-y-1">
                              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                                Brand Identity
                              </div>
                              <div className="font-serif text-xl font-bold text-foreground">
                                {identityCheck?.passed ? "Verified" : "Incomplete"}
                              </div>
                              <div className="text-[11px] text-muted-foreground truncate">
                                {identityCheck?.passed
                                  ? "Logo / Cover verified"
                                  : "Missing logo or cover"}
                              </div>
                            </div>

                            <div className="p-3.5 rounded-2xl bg-muted/30 space-y-1">
                              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                                Coverage
                              </div>
                              <div className="font-serif text-xl font-bold text-foreground">
                                {categoriesList.length > 0
                                  ? `${categoriesList.length} Categories`
                                  : catCheck?.passed
                                    ? "Good"
                                    : "Limited"}
                              </div>
                              <div className="text-[11px] text-muted-foreground truncate">
                                {catCheck?.passed
                                  ? "Contextual coverage"
                                  : "Needs category diversity"}
                              </div>
                            </div>

                            <div className="p-3.5 rounded-2xl bg-muted/30 space-y-1">
                              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                                90-Day Freshness
                              </div>
                              <div className="font-serif text-xl font-bold text-foreground">
                                {freshnessCheck?.passed ? "Fresh" : "Stale"}
                              </div>
                              <div className="text-[11px] text-muted-foreground truncate">
                                {recencyText}
                              </div>
                            </div>
                          </div>

                          {/* Detected Media Badges */}
                          {categoriesList.length > 0 && (
                            <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                              <span className="text-[11px] font-mono text-muted-foreground mr-1 uppercase">
                                Verified Types:
                              </span>
                              {categoriesList.map((catName: string, idx: number) => (
                                <Badge
                                  key={idx}
                                  variant="outline"
                                  className="text-[10px] uppercase font-mono py-0.5 px-2 bg-muted/20"
                                >
                                  {catName.replace(/_/g, " ")}
                                </Badge>
                              ))}
                            </div>
                          )}

                          {/* Strengths */}
                          <div className="pt-1">
                            <div className="space-y-2.5">
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                                <CheckCircle2 size={14} />
                                <span>Visual Strengths ({passedChecks.length})</span>
                              </div>
                              <div className="space-y-2">
                                {passedChecks.length > 0 ? (
                                  passedChecks.map((ck: any, idx: number) => (
                                    <div
                                      key={idx}
                                      className="p-3.5 rounded-2xl bg-emerald-500/[0.06] text-xs space-y-1"
                                    >
                                      <div className="font-medium text-foreground flex items-center justify-between">
                                        <span>{ck.name || ck.label}</span>
                                        <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                                          +{ck.weight} pts
                                        </span>
                                      </div>
                                      {ck.evidence &&
                                        typeof ck.evidence === "string" && (
                                          <p className="text-[11px] text-muted-foreground">
                                            Evidence: {ck.evidence}
                                          </p>
                                        )}
                                    </div>
                                  ))
                                ) : (
                                  <p className="text-xs text-muted-foreground italic">
                                    No visual strengths verified yet.
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Run/Re-run Audit buttons */}
                          <div className="flex flex-wrap gap-2 pt-3">
                            <Button
                              onClick={handleAuditGBP}
                              variant="outline"
                              className="gap-2 text-xs min-h-[38px] px-5 font-medium rounded-full"
                            >
                              <RefreshCw size={14} />
                              <span>Re-run Audit</span>
                            </Button>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </TabsContent>

              {/* GROWTH TAB CONTENT */}
              <TabsContent value="growth" className="pt-1">
                <GrowthDashboard
                  customerId={profile?.customer_id || customer_id || ""}
                  locationId={profile?.location_id || location_id || undefined}
                />
              </TabsContent>

              {/* REVIEWS TAB CONTENT */}
              <TabsContent value="reviews" className="pt-1">
                <ReviewsDashboard
                  customerId={profile?.customer_id || customer_id || undefined}
                />
              </TabsContent>
            </Tabs>

            {/* Enclosed Chatbot Modal */}
            <AuditChatModal
              open={isAuditModalOpen}
              onOpenChange={setIsAuditModalOpen}
              businessName={profile?.business_name || "Your Business"}
              auditId={auditId || auditResult?.id}
              customerId={profile?.customer_id || customer_id || undefined}
              locationId={profile?.location_id || location_id || undefined}
              hasActiveSubscription={entitlement?.has_access === true}
              auditStatus={auditStatus}
              auditProgress={auditProgress}
              auditStep={auditStep}
              auditMessages={auditMessages}
              auditResult={auditResult}
              auditError={auditError}
              onStartAudit={handleAuditGBP}
              onEmailReport={handleEmailReport}
              onReconnectGoogle={reconnectGoogle}
              onNavigateToReviews={() => setActiveTab("reviews")}
              onGeneratePostDraft={handleGenerateDraft}
              onRequireGrowthUpgrade={(feature) => {
                setUpgradeModalConfig({
                  title: "Unlock 1-Click Publishing",
                  description:
                    "Publish directly to Google Search & Maps in 1-click with Trendit Pro.",
                  highlightFeature: feature,
                });
                setUpgradeModalOpen(true);
              }}
              emailingReport={emailingReport}
              reportEmailed={reportEmailed}
              hasLocationId={
                !!(
                  profile?.location_id ||
                  location_id ||
                  (typeof window !== "undefined" &&
                    localStorage.getItem("trendit_location_id"))
                )
              }
            />

            {/* Contextual Growth Upgrade Modal */}
            <GrowthUpgradeModal
              open={upgradeModalOpen}
              onOpenChange={setUpgradeModalOpen}
              title={upgradeModalConfig.title}
              description={upgradeModalConfig.description}
              highlightFeature={upgradeModalConfig.highlightFeature}
              onSuccess={() => {
                const cid =
                  profile?.customer_id ||
                  customer_id ||
                  (typeof window !== "undefined"
                    ? localStorage.getItem("trendit_customer_id")
                    : null);
                if (cid) fetchEntitlement(cid);
              }}
            />
          </div>
        </main>
      </div>

      <SiteFooter />
    </div>
  );
}
