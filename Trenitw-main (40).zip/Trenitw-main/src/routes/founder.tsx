import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, Mail, MapPin } from "lucide-react";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildPersonSchema,
  buildAboutPageSchema,
  buildJsonLdScript,
  FOUNDER_IMAGE,
} from "@/lib/seo";

const founderSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildPersonSchema(),
  buildAboutPageSchema(),
];

export const Route = createFileRoute("/founder")({
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
  head: () => ({
    meta: createPageMeta({
      title: "Lubega Fahad Juma — Founder & CEO of Trendexhub | Trendit",
      description:
        "Meet Lubega Fahad Juma, Founder & CEO of Trendexhub and creator of Trendit, a platform helping local businesses grow their presence on Google Search and Maps.",
      canonicalPath: "/founder",
      image: FOUNDER_IMAGE,
      type: "profile",
      keywords: [
        "Lubega Fahad Juma",
        "Trendexhub founder",
        "Trendit CEO",
        "local SEO SaaS founder",
        "Google Business Profile management founder",
      ],
      noindex: true,
    }),
    links: [createCanonicalLink("/founder")],
    scripts: [buildJsonLdScript(founderSchemaEntities)],
  }),
  component: FounderPage,
});

function FounderPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />

      <main className="container-page pb-24">
        <section className="pt-10 sm:pt-20 md:pt-32">
          <div className="grid gap-10 sm:gap-12 lg:grid-cols-[1fr_400px] items-start">
            <div className="space-y-6 sm:space-y-8">
              <div className="space-y-3 sm:space-y-4">
                <div className="inline-flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1 text-[11px] sm:text-xs font-semibold tracking-wider text-accent uppercase">
                  Founder & CEO, Trendexhub
                </div>
                <h1 className="font-serif text-3xl min-[400px]:text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-tight tracking-tight text-foreground">
                  <span>Lubega</span>{" "}
                  <span className="italic text-accent">Fahad</span>{" "}
                  <span>Juma</span>
                </h1>
              </div>

              <p className="max-w-xl text-lg sm:text-xl md:text-2xl font-medium leading-snug text-foreground/90">
                Building practical technology that helps local businesses become
                easier to find, trust, and choose on Google.
              </p>

              <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-4 pt-2 sm:pt-4">
                <Button
                  variant="default"
                  className="rounded-full px-8 w-full sm:w-auto justify-center"
                  asChild
                >
                  <Link to="/" hash="pricing">
                    Get started free
                    <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <div className="flex items-center justify-center sm:justify-start gap-6 px-2 sm:px-4">
                  <a
                    href="mailto:info@trendexhub.com"
                    className="text-muted-foreground hover:text-foreground transition-colors p-2"
                    title="Email Trendexhub"
                  >
                    <Mail className="h-5 w-5" />
                  </a>
                  <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>Entebbe, Uganda</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative aspect-[4/5] max-w-sm mx-auto lg:max-w-none w-full overflow-hidden rounded-3xl bg-cream-deep border border-border shadow-lg group">
              <img
                src="/founder.png"
                alt="Lubega Fahad Juma — Founder & CEO of Trendexhub"
                className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent opacity-60 pointer-events-none" />
            </div>
          </div>
        </section>

        <section className="mt-16 sm:mt-24 md:mt-32 grid gap-10 md:grid-cols-[200px_1fr]">
          <aside className="space-y-6 sm:space-y-8">
            <div className="md:sticky md:top-24 space-y-6 sm:space-y-8">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground mb-3 sm:mb-4">
                  Company & Leadership
                </div>
                <div className="space-y-4">
                  <div>
                    <div className="text-sm font-semibold">Trendexhub</div>
                    <div className="text-xs text-muted-foreground">
                      Technology company
                    </div>
                  </div>
                  <div className="md:border-t md:border-border/50 md:pt-4">
                    <div className="text-sm font-semibold">
                      Lubega Fahad Juma
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Founder & CEO
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          <div className="max-w-2xl space-y-8 sm:space-y-12 text-base sm:text-lg leading-relaxed text-foreground/80">
            <div className="space-y-4 sm:space-y-6">
              <p>
                <strong>Trendexhub</strong> is a technology company focused on
                building practical software for businesses that depend on local
                discovery. Its flagship product,{" "}
                <Link
                  to="/"
                  className="text-accent hover:underline font-medium"
                >
                  Trendit
                </Link>
                , helps local businesses manage and grow their presence across
                Google Search and Maps.
              </p>
              <p>
                Lubega Fahad Juma founded Trendexhub after seeing how much
                ongoing work is required for a local business to maintain a
                strong and professional presence on Google. Publishing updates,
                responding to customers, monitoring visibility, and keeping
                business information current can become a significant
                operational burden.
              </p>
              <p>
                Trendit was built to turn that recurring work into a simpler,
                more manageable system, giving business owners practical tools
                to stay active and visible on Google while they remain focused
                on serving their customers.
              </p>
            </div>

            <div className="rounded-2xl sm:rounded-3xl bg-card border border-border p-5 sm:p-8 space-y-4 sm:space-y-6 shadow-sm">
              <h3 className="font-serif text-xl sm:text-2xl text-foreground">
                Why Trendit Exists
              </h3>
              <p className="text-sm sm:text-base leading-relaxed">
                Local businesses increasingly depend on Google Search and Maps
                for discovery. Yet maintaining a strong presence requires
                consistent attention. Trendit is designed to reduce that
                operational workload and make the process easier for owners and
                their teams.
              </p>
            </div>

            <p className="text-sm sm:text-base leading-relaxed">
              Lubega Fahad Juma combines software development and
              entrepreneurship with direct experience working with service-based
              businesses. That practical perspective shapes Trendexhub&apos;s
              approach: build focused tools that solve real operational problems
              rather than adding unnecessary complexity.
            </p>

            <div className="pt-8 sm:pt-12 border-t border-border/50">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-6 mb-6 sm:mb-8">
                <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl tracking-tight text-foreground">
                  About Trendit
                </h2>
                <Button
                  variant="outline"
                  className="rounded-full w-fit"
                  asChild
                >
                  <Link to="/" hash="features">Explore Platform Features</Link>
                </Button>
              </div>
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="space-y-2 sm:space-y-3">
                  <div className="text-xs sm:text-sm font-bold uppercase tracking-wider text-accent/80 underline decoration-2 underline-offset-4">
                    The Platform
                  </div>
                  <p className="text-xs sm:text-base text-foreground/70 leading-relaxed">
                    Trendit gives local businesses practical tools to maintain
                    an active, professional presence across Google Search and
                    Maps.
                  </p>
                </div>
                <div className="space-y-2 sm:space-y-3">
                  <div className="text-xs sm:text-sm font-bold uppercase tracking-wider text-accent/80 underline decoration-2 underline-offset-4">
                    The Goal
                  </div>
                  <p className="text-xs sm:text-base text-foreground/70 leading-relaxed">
                    Make it easier for businesses to capture high-intent local
                    searches and turn Google visibility into real customer
                    opportunities.
                  </p>
                </div>
              </div>
              <p className="mt-6 sm:mt-8 text-sm sm:text-base leading-relaxed">
                Trendexhub is building Trendit as a focused, founder-led
                technology product with a clear objective: give local businesses
                a simpler way to manage the work behind a strong Google
                presence.
              </p>
              <div className="mt-8 sm:mt-10 p-6 sm:p-8 rounded-2xl bg-foreground text-background text-center space-y-4">
                <div className="text-lg sm:text-xl font-serif italic">
                  Ready to grow your business on Google?
                </div>
                <Button
                  size="lg"
                  asChild
                  className="w-full sm:w-auto justify-center rounded-full bg-background text-foreground hover:bg-background/90 border-none"
                >
                  <Link to="/" hash="pricing">
                    Get started free
                    <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
