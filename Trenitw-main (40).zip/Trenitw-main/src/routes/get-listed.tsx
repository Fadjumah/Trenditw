import { useState } from "react";
import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { z } from "zod";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { ContactCtaBanner } from "@/components/contact-cta-banner";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  CheckCircle2,
  MapPin,
  Search,
  Star,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  Phone,
} from "lucide-react";
import { GoogleConnectButton } from "@/components/google-connect-button";
import { GbpSetupOfferCard } from "@/components/gbp-setup-offer-card";
import { GBP_SETUP_OFFER } from "@/lib/gbp-setup-offer";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildFAQSchema,
  buildJsonLdScript,
  SITE_URL,
} from "@/lib/seo";

const GET_LISTED_INTRO =
  "If your business isn't on Google yet, we'll create your Business Profile, fill it out correctly, and get it verified for you — so customers can find you on Search and Maps.";

const GET_LISTED_FAQS = [
  {
    q: "Do I need a website already?",
    a: "No. A Google Business Profile is separate from a website — it's what shows up on Google Search and Maps with your hours, phone number, reviews and directions.",
  },
  {
    q: "How long does it take to go live?",
    a: "Typically 2–5 business days. Most of that time is Google's own verification step, which we guide you through.",
  },
  {
    q: "What if Google needs to verify by postcard?",
    a: "Some categories are verified by a postcard mailed to your business address instead of a phone call. We'll tell you exactly what to expect for your category and walk you through entering the code once it arrives.",
  },
  {
    q: "What happens after my listing is live?",
    a: "We'll email you to connect it to your Trendit dashboard, where you get your first month of automated posts and review management free.",
  },
  {
    q: "I already have a Business Profile — is this for me?",
    a: "This service is specifically for businesses that don't have one yet. If you already have a profile, just connect it directly to Trendit instead.",
  },
];

const getListedSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildWebPageSchema({
    title: "Get Your Business Listed on Google — Done For You | Trendit",
    description:
      "Don't have a Google Business Profile yet? We'll create it, fill it out correctly and get it verified so your business shows up on Google Search and Maps.",
    url: `${SITE_URL}/get-listed`,
  }),
  buildFAQSchema(GET_LISTED_FAQS),
];

const getListedSearchSchema = z.object({
  ordered: z.string().optional(),
});

export const Route = createFileRoute("/get-listed")({
  validateSearch: getListedSearchSchema,
  head: () => ({
    meta: createPageMeta({
      title: "Get Your Business Listed on Google — Done For You | Trendit",
      description:
        "Get your business on Google Search and Maps without the hassle. We create, configure and verify your Google Business Profile for you — starting at $59 one-time.",
      canonicalPath: "/get-listed",
      keywords: [
        "get listed on google",
        "create google business profile",
        "google business profile setup service",
        "get my business on google maps",
        "google my business setup",
      ],
    }),
    links: [createCanonicalLink("/get-listed")],
    scripts: [buildJsonLdScript(getListedSchemaEntities)],
  }),
  component: GetListedPage,
});

function GetListedPage() {
  const { ordered } = useSearch({ from: "/get-listed" });

  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col overflow-x-hidden">
      <SiteNav />
      <main className="flex-1">
        {ordered === "1" && (
          <div className="bg-emerald-600 text-white px-5 py-4 text-center text-sm font-semibold flex items-center justify-center gap-2">
            <CheckCircle2 size={18} className="shrink-0" />
            <span>
              Payment received! We're preparing your Google Business Profile setup. We'll reach out to your email shortly to collect your details.
            </span>
          </div>
        )}
        {/* Hero — expansive dark band with 2-column desktop layout */}
        <section className="dark-surface bg-[#171512] px-5 py-16 sm:px-8 lg:px-12 xl:px-16 lg:py-24 text-white">
          <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              <div className="lg:col-span-7 space-y-6 text-left">
                <div className="inline-flex items-center gap-2 rounded-full bg-white/10 text-[#f3a37f] px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em]">
                  <Sparkles size={14} /> Done-for-you setup
                </div>
                <h1 className="font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl xl:text-[76px] text-white">
                  Get your business on Google Search &amp; Maps — without the
                  paperwork
                </h1>
                <p className="text-lg sm:text-xl leading-8 text-white/70 max-w-2xl">
                  {GET_LISTED_INTRO}
                </p>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      document.getElementById("order")?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="h-12 min-h-[48px] inline-flex items-center justify-center gap-2 rounded-full bg-[#b64b25] px-8 text-sm font-semibold text-white shadow-none hover:bg-[#a03f1d] cursor-pointer transition-colors"
                  >
                    <span>Get My Business Listed — $59</span>
                    <ArrowRight size={16} />
                  </button>
                  <GoogleConnectButton
                    size="lg"
                    source="get_listed_hero_secondary"
                    variant="outline"
                    className="h-12 min-h-[48px] justify-center rounded-full border-white/20 text-white hover:bg-white/10"
                  >
                    I already have a profile
                  </GoogleConnectButton>
                </div>
              </div>

              {/* Right Column: Google Profile Verified Preview */}
              <div className="lg:col-span-5">
                <div className="rounded-3xl border border-white/15 bg-[#201d19] p-6 sm:p-8 space-y-5 text-left shadow-xl">
                  <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2">
                      <span className="flex h-2.5 w-2.5 rounded-full bg-[#34a853]" />
                      <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Google Verified Listing</span>
                    </div>
                    <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/10 text-white/70 font-mono">3-Pack Ready</span>
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs text-[#f3a37f] font-semibold uppercase tracking-wider">Local Business Profile</div>
                    <div className="font-serif text-2xl font-bold text-white">Your Business Name</div>
                    <div className="flex items-center gap-2 pt-1 text-xs">
                      <div className="flex text-amber-400">★★★★★</div>
                      <span className="font-bold text-white">5.0</span>
                      <span className="text-white/60">(First 10 verified reviews)</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-white/80 pt-2">
                    <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                      <MapPin size={14} className="text-[#f3a37f] shrink-0" />
                      <span className="truncate">Accurate Maps Pin</span>
                    </div>
                    <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                      <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                      <span className="truncate">NAP Consistency</span>
                    </div>
                    <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                      <Search size={14} className="text-blue-400 shrink-0" />
                      <span className="truncate">Rank-Optimized</span>
                    </div>
                    <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                      <Phone size={14} className="text-amber-400 shrink-0" />
                      <span className="truncate">Click-to-Call Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1200&q=82", alt: "A storefront ready to be discovered", eyebrow: "Visibility", title: "Put your business on the map" },
          { src: "https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?auto=format&fit=crop&w=1200&q=82", alt: "A local business with customers", eyebrow: "Discovery", title: "Help nearby customers find you" },
          { src: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1200&q=82", alt: "A business owner serving a customer", eyebrow: "Trust", title: "Give customers a real place to start" },
        ]} />

        {/* Why it matters — cream band */}
        <section className="border-y border-black/10 bg-white/45 px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
          <div className="mx-auto grid gap-6 sm:grid-cols-3 max-w-7xl 2xl:max-w-[1440px]">
            <div className="rounded-3xl border border-black/10 bg-white p-8 text-center shadow-none space-y-2">
              <Search className="mx-auto mb-4 text-[#b64b25]" size={30} />
              <h3 className="font-serif text-2xl text-[#171512]">
                Show up in search
              </h3>
              <p className="text-sm leading-7 text-black/60">
                Without a Business Profile, you're invisible when people
                search for what you do near them on Google Search.
              </p>
            </div>
            <div className="rounded-3xl border border-black/10 bg-white p-8 text-center shadow-none space-y-2">
              <MapPin className="mx-auto mb-4 text-[#b64b25]" size={30} />
              <h3 className="font-serif text-2xl text-[#171512]">
                Show up on Maps
              </h3>
              <p className="text-sm leading-7 text-black/60">
                Get directions, opening hours, photos, and direct calls straight from your Google
                Maps 3-Pack listing.
              </p>
            </div>
            <div className="rounded-3xl border border-black/10 bg-white p-8 text-center shadow-none space-y-2">
              <Star className="mx-auto mb-4 text-[#b64b25]" size={30} />
              <h3 className="font-serif text-2xl text-[#171512]">
                Collect real reviews
              </h3>
              <p className="text-sm leading-7 text-black/60">
                A verified Google profile gives happy clients a trustworthy place to leave 5-star reviews that convert new buyers.
              </p>
            </div>
          </div>
        </section>

        {/* Offer detail — 2-column layout on desktop */}
        <section id="order" className="border-b border-black/10 px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
          <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-14 items-start">
              {/* Left Column: What's included and guarantee */}
              <div className="lg:col-span-6 space-y-6">
                <div className="inline-flex items-center gap-2 rounded-full bg-[#b64b25]/10 px-3.5 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
                  Turnkey Package
                </div>
                <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#171512] leading-tight">
                  Everything handled from setup to official Google verification.
                </h2>
                <p className="text-base sm:text-lg leading-8 text-black/65">
                  Setting up a Google Business Profile manually requires navigating strict verification policies, postal codes, category rules, and attribute checklists. One minor error can trigger listing suspension. Our specialists do the entire setup by the book.
                </p>

                <div className="grid sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-5 rounded-2xl bg-white border border-black/10 space-y-1.5">
                    <div className="font-bold text-sm text-[#171512]">Official Google API Methods</div>
                    <p className="text-xs text-black/60 leading-relaxed">No password sharing, zero shady hacks, and 100% compliant with Google guidelines.</p>
                  </div>
                  <div className="p-5 rounded-2xl bg-white border border-black/10 space-y-1.5">
                    <div className="font-bold text-sm text-[#171512]">Fast {GBP_SETUP_OFFER.turnaround} Delivery</div>
                    <p className="text-xs text-black/60 leading-relaxed">We get your business submitted and live so local customers can find you immediately.</p>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-white/70 border border-black/10 space-y-2">
                  <div className="font-semibold text-sm text-[#171512] flex items-center gap-2">
                    <ShieldCheck size={18} className="text-[#b64b25]" />
                    <span>Already have a Business Profile?</span>
                  </div>
                  <p className="text-xs text-black/60 leading-relaxed">
                    If your business is already on Google, you don't need this setup service. You can connect your existing profile directly to Trendit:
                  </p>
                  <GoogleConnectButton
                    size="sm"
                    source="get_listed_already_have"
                    variant="outline"
                    className="mt-2 text-xs rounded-full border-black/20"
                  >
                    Connect Existing Profile
                  </GoogleConnectButton>
                </div>
              </div>

              {/* Right Column: The Interactive Order & Checkout Card */}
              <div className="lg:col-span-6">
                <GbpSetupOfferCard source="get_listed_page" />
              </div>
            </div>
          </div>
        </section>

        {/* Contact CTA — call/WhatsApp banner */}
        <section className="px-5 py-16 sm:px-8 lg:px-12 xl:px-16">
          <div className="mx-auto max-w-4xl 2xl:max-w-5xl">
            <ContactCtaBanner
              source="get_listed_page"
              heading="Not sure if this is right for your business?"
              subheading="Call or WhatsApp us — tell us about your business and we'll tell you exactly what to expect, no pressure."
            />
          </div>
        </section>

        {/* FAQ — 2-column layout on desktop */}
        <section className="border-t border-black/10 bg-white/45 px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
          <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
              <div className="lg:col-span-5 space-y-4 lg:sticky lg:top-28 text-left">
                <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
                  FAQ
                </p>
                <h2 className="font-serif text-4xl sm:text-5xl text-[#171512] leading-tight">
                  Frequently asked questions
                </h2>
                <p className="text-base text-black/65 leading-relaxed">
                  Everything you need to know about getting your business profile created and verified on Google Maps.
                </p>
                <div className="pt-2">
                  <p className="text-sm text-black/60">
                    Need a full website instead of just a listing?{" "}
                    <Link
                      to="/website-design"
                      className="font-semibold text-[#b64b25] underline underline-offset-2 hover:text-[#a03f1d]"
                    >
                      See our web design packages →
                    </Link>
                  </p>
                </div>
              </div>

              <div className="lg:col-span-7">
                <Accordion type="single" collapsible className="w-full space-y-4">
                  {GET_LISTED_FAQS.map((faq, i) => (
                    <AccordionItem
                      key={faq.q}
                      value={`faq-${i}`}
                      className="rounded-3xl border border-black/10 bg-white px-6 py-2 shadow-none"
                    >
                      <AccordionTrigger className="font-serif text-lg font-semibold text-[#171512] hover:no-underline text-left py-4">
                        {faq.q}
                      </AccordionTrigger>
                      <AccordionContent className="text-sm leading-7 text-black/65 pb-4">
                        {faq.a}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>
          </div>
        </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=82", alt: "A professional working at a laptop", eyebrow: "Setup", title: "Get the details right from the start" },
          { src: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=82", alt: "A small team planning together", eyebrow: "Process", title: "A clear path to getting listed" },
          { src: "https://images.unsplash.com/photo-1529502669401-57d9f0b5c7d1?auto=format&fit=crop&w=1200&q=82", alt: "A business storefront in a neighborhood", eyebrow: "Presence", title: "Be ready when customers search" },
        ]} />
      </main>
      <SiteFooter />
    </div>
  );
}
