import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Search, Phone, Star, MapPin, FileCheck2 } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { createPageMeta, createCanonicalLink, buildOrganizationSchema, buildWebSiteSchema, buildWebPageSchema, buildBreadcrumbSchema, buildFAQSchema, buildJsonLdScript, SITE_URL } from "@/lib/seo";

const faqs = [
  { q: "What is a Google Business Profile audit?", a: "An audit is a structured review of the information, completeness, customer-facing content and available performance signals associated with a Business Profile." },
  { q: "Does an audit guarantee higher rankings?", a: "No. An audit identifies issues and opportunities; it cannot guarantee a particular Google ranking because local search results depend on many factors and can change over time." },
  { q: "What should I do after an audit?", a: "Prioritize factual corrections first, then work through profile completeness, customer trust signals, content and ongoing measurement. The important part is turning the findings into a repeatable process." },
];

export const Route = createFileRoute("/google-business-profile-audit")({
  head: () => ({
    meta: createPageMeta({
      title: "Google Business Profile Audit: What to Check and Why It Matters | Trendit",
      description: "Learn how to audit a Google Business Profile for accuracy, completeness, customer trust, content and performance, with a practical checklist for local businesses.",
      canonicalPath: "/google-business-profile-audit",
      keywords: ["Google Business Profile audit", "GBP audit", "Google Maps audit", "Google profile audit", "local SEO audit"],
    }),
    links: [createCanonicalLink("/google-business-profile-audit")],
    scripts: [buildJsonLdScript([
      buildOrganizationSchema(), buildWebSiteSchema(),
      buildWebPageSchema({ title: "Google Business Profile Audit: What to Check and Why It Matters | Trendit", description: "A practical Google Business Profile audit checklist.", url: `${SITE_URL}/google-business-profile-audit` }),
      buildBreadcrumbSchema([{ name: "Home", path: "/" }, { name: "Google Business Profile Audit", path: "/google-business-profile-audit" }]),
      buildFAQSchema(faqs),
    ])],
  }),
  component: Page,
});

function Page() {
  const checks = [
    ["01","Core information","Check business name, primary category, phone, website, address or service area, hours and the services customers actually need."],
    ["02","Profile completeness","Look for relevant missing fields, weak descriptions, outdated information and gaps that make it harder for customers to understand the business."],
    ["03","Customer trust","Review ratings, review volume, recent feedback, response activity and the quality of genuine photos and customer-facing information."],
    ["04","Content activity","Check whether updates are useful and current. Content should support real customers rather than exist simply to create activity."],
    ["05","Local relevance","Make sure your profile and website clearly communicate the services you offer and the places you genuinely serve."],
    ["06","Customer actions","Review available performance data such as calls, website interactions, direction requests and other profile actions."],
  ];
  return <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col"><SiteNav/><main className="flex-1">
    <section className="mx-auto max-w-5xl px-5 pb-16 pt-14 sm:px-8 lg:pt-24"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Free guide</p><h1 className="mt-4 max-w-4xl font-serif text-5xl leading-[0.98] sm:text-6xl lg:text-7xl">Google Business Profile audit: find the gaps before your customers do.</h1><p className="mt-7 max-w-3xl text-lg leading-8 text-black/65">A Business Profile audit is not about chasing a magic score. It is about checking whether the information customers see is accurate, complete, trustworthy and connected to the way your business actually operates.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><Link to="/subscribe" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Audit with Trendit <ArrowRight size={17}/></Link><Link to="/google-business-profile-management" className="inline-flex items-center justify-center rounded-full border border-black/15 px-7 py-4 text-sm font-semibold">Management guide</Link></div></section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=82", alt: "A close-up of business analytics", eyebrow: "Audit", title: "Find the gaps that matter" },
          { src: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=82", alt: "Research and planning on a laptop", eyebrow: "Action", title: "Turn findings into practical fixes" },
          { src: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=82", alt: "A storefront in a local neighborhood", eyebrow: "Visibility", title: "Make the profile match the business" },
        ]} />

    <section className="bg-[#171512] text-white"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">The audit mindset</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Ask one question: what would a customer see and do next?</h2><p className="mt-5 text-lg leading-8 text-white/65">A useful audit connects profile data to customer experience. If the phone number is wrong, the customer cannot call. If hours are outdated, the customer may arrive at the wrong time. If services are unclear, a searcher may choose another business. If reviews go unanswered, an opportunity to demonstrate responsiveness is missed.</p></div><div className="mt-10 grid gap-4 sm:grid-cols-3">{[[Phone,"Can they contact you?"],[MapPin,"Can they find you?"],[Star,"Can they trust you?"]].map(([Icon,t])=><div key={t as string} className="rounded-3xl border border-white/10 bg-white/5 p-7"><Icon size={22} className="text-[#f3a37f]"/><p className="mt-5 font-semibold">{t as string}</p></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">The checklist</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Six areas worth reviewing.</h2><p className="mt-5 text-lg leading-8 text-black/65">Start with facts, then move toward customer experience and measurement. Fixing a factual problem is usually more important than polishing a cosmetic detail.</p></div><div className="mt-10 grid gap-5 md:grid-cols-2">{checks.map(([n,t,b])=><div key={n} className="rounded-3xl border border-black/10 bg-white p-7"><span className="text-sm font-semibold text-[#b64b25]">{n}</span><h3 className="mt-5 font-serif text-2xl">{t}</h3><p className="mt-2 text-sm leading-7 text-black/60">{b}</p></div>)}</div></section>

    <section className="border-y border-black/10 bg-white/50"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="grid gap-10 lg:grid-cols-[0.9fr_1fr]"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Prioritize the findings</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Not every audit item deserves the same attention.</h2></div><div className="space-y-5"><div className="rounded-3xl bg-white border border-black/10 p-7"><h3 className="font-semibold">First: accuracy</h3><p className="mt-2 text-sm leading-7 text-black/60">Fix incorrect phone numbers, hours, locations and service information.</p></div><div className="rounded-3xl bg-white border border-black/10 p-7"><h3 className="font-semibold">Next: customer confidence</h3><p className="mt-2 text-sm leading-7 text-black/60">Improve clarity, genuine photos, review responses and useful service information.</p></div><div className="rounded-3xl bg-white border border-black/10 p-7"><h3 className="font-semibold">Then: consistency and measurement</h3><p className="mt-2 text-sm leading-7 text-black/60">Keep the profile aligned with the website and watch available customer actions over time.</p></div></div></div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="grid gap-10 lg:grid-cols-[1fr_0.82fr]"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Turn the audit into action</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">An audit is useful only if the work continues.</h2><p className="mt-5 text-lg leading-8 text-black/65">Trendit is built around that next step. After identifying gaps, you can use the platform to manage recurring Google Business Profile work, from content and reviews to ongoing profile monitoring.</p><p className="mt-5 text-base leading-7 text-black/60">Think of the audit as a baseline, not a finish line.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-6 py-3.5 text-sm font-semibold text-white">Start with Trendit <ArrowRight size={16}/></Link></div><div className="rounded-3xl border border-black/10 bg-white p-7"><FileCheck2 size={24} className="text-[#b64b25]"/><h3 className="mt-6 font-serif text-2xl">Audit → action → measurement</h3><div className="mt-5 space-y-3">{["Identify the issue","Make the correction","Keep the profile active","Watch what changes"].map(x=><div key={x} className="flex gap-3 text-sm"><Check size={18} className="mt-0.5 shrink-0 text-[#b64b25]"/>{x}</div>)}</div></div></div></section>

    <section className="border-t border-black/10 bg-white/45"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">FAQ</p><div className="mt-8 divide-y divide-black/10">{faqs.map(f=><div key={f.q} className="py-6"><h2 className="text-lg font-semibold">{f.q}</h2><p className="mt-2 max-w-3xl text-sm leading-7 text-black/60">{f.a}</p></div>)}</div></div></section>
    <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="rounded-3xl bg-[#e9ddd0] p-8 text-center sm:p-12"><h2 className="font-serif text-4xl sm:text-5xl">Know what needs work. Then make the work repeatable.</h2><p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-black/60">Use Trendit to bring your Google Business Profile audit and ongoing management into one workflow.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Explore Trendit <ArrowRight size={17}/></Link></div></section>
  </main><SiteFooter/></div>;
}
