import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Search, MessageSquare, BarChart3, MapPin } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { createPageMeta, createCanonicalLink, buildOrganizationSchema, buildWebSiteSchema, buildWebPageSchema, buildBreadcrumbSchema, buildFAQSchema, buildJsonLdScript, SITE_URL } from "@/lib/seo";

const faqs = [
  { q: "What does Google Business Profile management include?", a: "It includes keeping core business information accurate, improving profile completeness, publishing useful updates, monitoring customer actions and reviews, and maintaining the profile over time." },
  { q: "Is Google Business Profile management the same as SEO?", a: "They overlap, but they are not identical. A Business Profile is a major local-search asset, while local SEO also includes your website, local relevance, citations, links and other signals." },
  { q: "Can I manage my profile myself?", a: "Yes. Trendit is designed for businesses that want to reduce repetitive work while keeping control of their Google presence and connected locations." },
];

export const Route = createFileRoute("/google-business-profile-management")({
  head: () => ({
    meta: createPageMeta({
      title: "Google Business Profile Management: A Practical Guide for Local Businesses | Trendit",
      description: "Learn what Google Business Profile management involves, what to keep updated, how reviews and posts fit into local search, and how Trendit helps businesses manage the ongoing work.",
      canonicalPath: "/google-business-profile-management",
      keywords: ["Google Business Profile management", "Google Business Profile optimization", "GBP management", "Google Maps marketing", "local SEO"],
    }),
    links: [createCanonicalLink("/google-business-profile-management")],
    scripts: [buildJsonLdScript([
      buildOrganizationSchema(), buildWebSiteSchema(),
      buildWebPageSchema({ title: "Google Business Profile Management: A Practical Guide for Local Businesses | Trendit", description: "A practical guide to managing and improving a Google Business Profile.", url: `${SITE_URL}/google-business-profile-management` }),
      buildBreadcrumbSchema([{ name: "Home", path: "/" }, { name: "Google Business Profile Management", path: "/google-business-profile-management" }]),
      buildFAQSchema(faqs),
    ])],
  }),
  component: Page,
});

function Page() {
  return <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col"><SiteNav /><main className="flex-1">
    <section className="mx-auto max-w-5xl px-5 pb-16 pt-14 sm:px-8 lg:pt-24">
      <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Local search guide</p>
      <h1 className="mt-4 max-w-4xl font-serif text-5xl leading-[0.98] tracking-tight sm:text-6xl lg:text-7xl">Google Business Profile management that keeps your business ready to be found.</h1>
      <p className="mt-7 max-w-3xl text-lg leading-8 text-black/65">Your Google Business Profile is often the first place a potential customer encounters your business. Managing it well is not a one-time setup. It is an ongoing job of keeping information accurate, publishing useful updates, responding to customers and understanding what people do after they find you.</p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row"><Link to="/subscribe" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Start with Trendit <ArrowRight size={17}/></Link><Link to="/how-it-works" className="inline-flex items-center justify-center rounded-full border border-black/15 px-7 py-4 text-sm font-semibold">See how it works</Link></div>
    </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1200&q=82", alt: "A storefront ready for customers", eyebrow: "Presence", title: "Keep your profile active" },
          { src: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=82", alt: "Local business analytics", eyebrow: "Visibility", title: "Understand your search performance" },
          { src: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=82", alt: "A neighborhood cafe with customers", eyebrow: "Customers", title: "Be easier to discover nearby" },
        ]} />

    <section className="border-y border-black/10 bg-white/50"><div className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="grid gap-6 md:grid-cols-3">
      {[[Search,"Be discoverable","Make the information customers see in Google clear, accurate and useful."],[MessageSquare,"Build trust","Keep reviews, replies and profile content active and helpful."],[BarChart3,"Measure activity","Watch the customer actions generated from your Google presence."]].map(([Icon,title,body])=><div key={title as string} className="rounded-3xl bg-white p-7 border border-black/10"><Icon size={23} className="text-[#b64b25]"/><h2 className="mt-6 text-xl font-semibold">{title as string}</h2><p className="mt-2 text-sm leading-7 text-black/60">{body as string}</p></div>)}
    </div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">What management really means</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">A healthy profile is maintained, not merely created.</h2><p className="mt-5 text-lg leading-8 text-black/65">A profile can be technically complete and still become stale. Business hours change. Services change. Customers leave reviews. New photos become available. Competitors publish updates. Searchers ask new questions. Good management keeps the profile aligned with the business customers can actually buy from today.</p></div>
      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {["Business information: name, category, phone, website, hours and service details should remain accurate.","Profile content: useful posts, photos and updates can give searchers more context before they contact you.","Reviews and replies: responding professionally shows customers that their experience matters and gives future customers more information.","Performance monitoring: calls, website visits, direction requests and other available profile insights help you understand whether activity is changing.","Consistency: your Google presence should match the information customers encounter on your website and other important business listings.","Ongoing improvement: management should create a repeatable process instead of relying on occasional bursts of attention."].map(item=><div key={item} className="flex gap-3 rounded-2xl border border-black/10 bg-white p-6"><Check className="mt-0.5 shrink-0 text-[#b64b25]" size={18}/><p className="text-sm leading-7 text-black/65">{item}</p></div>)}
      </div>
    </section>

    <section className="bg-[#171512] text-white"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">Why local businesses care</p><h2 className="mt-3 max-w-3xl font-serif text-4xl leading-tight sm:text-5xl">Search visibility matters because local searches often lead somewhere.</h2><p className="mt-5 max-w-3xl text-lg leading-8 text-white/65">Someone searching for a service near them may be deciding between several businesses. Your profile helps them answer practical questions quickly: What do you offer? Where are you? When are you open? Can I call you? What do other customers say? A strong profile does not guarantee a ranking or a sale, but it can make the decision easier when a customer is already looking.</p>
      <div className="mt-10 grid gap-5 md:grid-cols-3">{[[MapPin,"Maps","Help customers understand where you are and how to reach you."],[MessageSquare,"Reviews","Give customers a place to see experiences and your response."],[BarChart3,"Actions","Track available customer actions and compare performance over time."]].map(([Icon,title,body])=><div key={title as string} className="rounded-3xl border border-white/10 bg-white/5 p-7"><Icon size={22} className="text-[#f3a37f]"/><h3 className="mt-5 text-lg font-semibold">{title as string}</h3><p className="mt-2 text-sm leading-7 text-white/60">{body as string}</p></div>)}</div>
    </div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="grid gap-10 lg:grid-cols-[1fr_0.8fr]"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Where Trendit fits</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">Turn the recurring work into a system.</h2><p className="mt-5 text-lg leading-8 text-black/65">Trendit connects to your Google Business Profile and brings recurring management into one workflow. You can audit profile health, work with localized post drafts, manage review replies and monitor profile activity without rebuilding the process every week.</p><p className="mt-5 text-base leading-7 text-black/60">The aim is not to promise a particular Google ranking. It is to make the work of maintaining a useful, active business presence easier to execute consistently.</p><div className="mt-7 flex gap-3"><Link to="/subscribe" className="inline-flex items-center gap-2 rounded-full bg-[#171512] px-6 py-3.5 text-sm font-semibold text-white">Try Trendit <ArrowRight size={16}/></Link><Link to="/google-business-profile-audit" className="inline-flex items-center gap-2 rounded-full border border-black/15 px-6 py-3.5 text-sm font-semibold">Read the audit guide</Link></div></div><div className="rounded-3xl border border-black/10 bg-white p-7"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#b64b25]">A simple operating rhythm</p>{["Check what customers see","Improve incomplete or outdated information","Publish useful updates","Respond to reviews","Review performance and repeat"].map((x,i)=><div key={x} className="flex gap-4 border-b border-black/8 py-4 last:border-0"><span className="text-sm font-semibold text-[#b64b25]">0{i+1}</span><span className="text-sm leading-6">{x}</span></div>)}</div></div></section>

    <section className="border-t border-black/10 bg-white/45"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">FAQ</p><div className="mt-8 divide-y divide-black/10">{faqs.map(f=><div key={f.q} className="py-6"><h2 className="text-lg font-semibold">{f.q}</h2><p className="mt-2 max-w-3xl text-sm leading-7 text-black/60">{f.a}</p></div>)}</div></div></section>
    <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="rounded-3xl bg-[#e9ddd0] p-8 text-center sm:p-12"><h2 className="font-serif text-4xl sm:text-5xl">Make Google management part of your operating system.</h2><p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-black/60">Trendit helps local businesses keep their Google presence active, measurable and easier to manage.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Start Trendit <ArrowRight size={17}/></Link></div></section>
  </main><SiteFooter/></div>;
}
