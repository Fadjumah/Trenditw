import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, CalendarDays, MessageSquare, Image, BarChart3, MapPin } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { createPageMeta, createCanonicalLink, buildOrganizationSchema, buildWebSiteSchema, buildWebPageSchema, buildBreadcrumbSchema, buildFAQSchema, buildJsonLdScript, SITE_URL } from "@/lib/seo";

const faqs = [
  { q: "What are Google Business Profile posts?", a: "Posts are updates that can appear on a Business Profile and give customers timely information about offers, events, products, services or other useful updates." },
  { q: "How often should a business publish Google Business Profile posts?", a: "There is no universal frequency that guarantees better rankings. A practical approach is to publish when you have something genuinely useful to communicate and maintain a consistent workflow." },
  { q: "Can posts alone improve my Google ranking?", a: "No. Posts are one part of a broader Business Profile and local-search strategy. They should support customer communication rather than be treated as a ranking shortcut." },
];

export const Route = createFileRoute("/google-business-profile-posts")({
  head: () => ({
    meta: createPageMeta({
      title: "Google Business Profile Posts: What to Publish and How to Stay Consistent | Trendit",
      description: "Learn how Google Business Profile posts work, what local businesses can publish, how to create useful updates and how to build a sustainable posting workflow.",
      canonicalPath: "/google-business-profile-posts",
      keywords: ["Google Business Profile posts", "Google Business Profile post ideas", "Google Maps posts", "GBP posts", "local business content"],
    }),
    links: [createCanonicalLink("/google-business-profile-posts")],
    scripts: [buildJsonLdScript([
      buildOrganizationSchema(), buildWebSiteSchema(),
      buildWebPageSchema({ title: "Google Business Profile Posts: What to Publish and How to Stay Consistent | Trendit", description: "A practical guide to Google Business Profile posts for local businesses.", url: `${SITE_URL}/google-business-profile-posts` }),
      buildBreadcrumbSchema([{ name: "Home", path: "/" }, { name: "Google Business Profile Posts", path: "/google-business-profile-posts" }]),
      buildFAQSchema(faqs),
    ])],
  }),
  component: Page,
});

function Page() {
  const ideas = [
    [CalendarDays,"Events and timely updates","Tell customers about events, seasonal changes, new opening hours or important dates."],
    [Image,"Products and services","Show a real product, service, treatment, menu item or project and explain why it matters."],
    [MessageSquare,"Helpful answers","Turn common customer questions into short, useful updates that remove uncertainty."],
    [MapPin,"Local relevance","Connect an update to the area you genuinely serve without stuffing location keywords into every sentence."],
  ];
  return <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col"><SiteNav/><main className="flex-1">
    <section className="mx-auto max-w-5xl px-5 pb-16 pt-14 sm:px-8 lg:pt-24"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Local content guide</p><h1 className="mt-4 max-w-4xl font-serif text-5xl leading-[0.98] sm:text-6xl lg:text-7xl">Google Business Profile posts: keep your local presence useful, current and worth checking.</h1><p className="mt-7 max-w-3xl text-lg leading-8 text-black/65">A customer who finds your business on Google may still have questions before they call or visit. Useful posts give you another way to communicate what is happening in the business and give searchers more context.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><Link to="/subscribe" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Automate the workflow with Trendit <ArrowRight size={17}/></Link><Link to="/google-business-profile-management" className="inline-flex items-center justify-center rounded-full border border-black/15 px-7 py-4 text-sm font-semibold">Management guide</Link></div></section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=82", alt: "A business owner working from a laptop", eyebrow: "Content", title: "Keep your profile fresh" },
          { src: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=82", alt: "A small business serving customers", eyebrow: "Local business", title: "Content connected to the real business" },
          { src: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=82", alt: "A clear performance dashboard", eyebrow: "Measure", title: "Learn what gets attention" },
        ]} />

    <section className="border-y border-black/10 bg-white/50"><div className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="grid gap-5 md:grid-cols-2">{ideas.map(([Icon,title,body])=><div key={title as string} className="rounded-3xl border border-black/10 bg-white p-7"><Icon size={22} className="text-[#b64b25]"/><h2 className="mt-5 text-xl font-semibold">{title as string}</h2><p className="mt-2 text-sm leading-7 text-black/60">{body as string}</p></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">What makes a post useful?</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Write for the customer who has already found you.</h2><p className="mt-5 text-lg leading-8 text-black/65">The best local updates are not written to impress an algorithm. They help someone decide whether your business is relevant, available and worth contacting.</p></div><div className="mt-10 grid gap-5 md:grid-cols-3">{[
      ["Clear","Say what is happening without forcing the reader through marketing language."],
      ["Specific","Mention the actual service, product, event or update rather than making vague claims."],
      ["Useful","Give the customer a reason to care or a next step when appropriate."],
    ].map(([t,b])=><div key={t} className="rounded-3xl border border-black/10 bg-white p-7"><h3 className="font-serif text-2xl">{t}</h3><p className="mt-2 text-sm leading-7 text-black/60">{b}</p></div>)}</div></section>

    <section className="bg-[#171512] text-white"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">A repeatable content system</p><h2 className="mt-3 max-w-3xl font-serif text-4xl sm:text-5xl">You do not need endless ideas. You need a reliable process.</h2><p className="mt-5 max-w-3xl text-lg leading-8 text-white/65">Most businesses do not struggle because they have nothing to say. They struggle because posting competes with serving customers. A simple system turns normal business activity into useful updates: collect real moments, draft the message, add an appropriate image when available, schedule it and review what happened.</p><div className="mt-10 grid gap-4 sm:grid-cols-5">{["Collect","Draft","Review","Publish","Measure"].map((x,i)=><div key={x} className="rounded-2xl border border-white/10 bg-white/5 p-5"><span className="text-sm text-[#f3a37f]">0{i+1}</span><h3 className="mt-4 text-sm font-semibold">{x}</h3></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="grid gap-10 lg:grid-cols-[1fr_0.82fr]"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Where Trendit fits</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Take the repetitive part off your plate.</h2><p className="mt-5 text-lg leading-8 text-black/65">Trendit helps businesses turn Google Business Profile posting into an ongoing workflow. You can work with localized post drafts, choose a posting schedule and manage the process from the same platform used for profile audits and review work.</p><p className="mt-5 text-base leading-7 text-black/60">Automation should make consistency easier, not replace judgment. Review the content, keep it truthful and make sure it represents the real business.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-6 py-3.5 text-sm font-semibold text-white">Start Trendit <ArrowRight size={16}/></Link></div><div className="rounded-3xl border border-black/10 bg-white p-7"><BarChart3 size={24} className="text-[#b64b25]"/><h3 className="mt-6 font-serif text-2xl">A sensible content mix</h3>{["Service spotlight","Helpful customer answer","Real business update","Seasonal information","Customer-focused announcement"].map(x=><div key={x} className="flex gap-3 border-b border-black/8 py-4 last:border-0"><Check size={18} className="mt-0.5 shrink-0 text-[#b64b25]"/><span className="text-sm">{x}</span></div>)}</div></div></section>

    <section className="border-t border-black/10 bg-white/45"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">FAQ</p><div className="mt-8 divide-y divide-black/10">{faqs.map(f=><div key={f.q} className="py-6"><h2 className="text-lg font-semibold">{f.q}</h2><p className="mt-2 max-w-3xl text-sm leading-7 text-black/60">{f.a}</p></div>)}</div></div></section>
    <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="rounded-3xl bg-[#e9ddd0] p-8 text-center sm:p-12"><h2 className="font-serif text-4xl sm:text-5xl">Your Google presence should not go quiet because you got busy.</h2><p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-black/60">Use Trendit to make useful local content part of a repeatable Google Business Profile workflow.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Explore Trendit <ArrowRight size={17}/></Link></div></section>
  </main><SiteFooter/></div>;
}
