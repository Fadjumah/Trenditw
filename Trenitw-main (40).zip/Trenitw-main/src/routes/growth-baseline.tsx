import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowRight, BarChart3, CheckCircle2, Clock3, Loader2, LockKeyhole, RefreshCw, ShieldCheck, AlertTriangle } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { apiFetch } from "@/lib/api";
import { toast } from "sonner";

const METRICS = [
  ["calls", "Google calls"],
  ["website_clicks", "Website clicks"],
  ["direction_requests", "Direction requests"],
  ["search_desktop", "Search impressions · desktop"],
  ["search_mobile", "Search impressions · mobile"],
  ["maps_desktop", "Maps impressions · desktop"],
  ["maps_mobile", "Maps impressions · mobile"],
] as const;

type Month = { label: string; start: string; end: string; metrics: Record<string, number | null> };
type MetricDetail = {
  months_available: number;
  monthly_values: Record<string, number>;
  calculation: "3_month_average" | "2_month_average" | "single_month_actual" | "insufficient_data" | string;
  baseline: number | null;
  label: string;
};
type Baseline = {
  status: "calculating" | "complete" | "incomplete" | "collecting_history" | "confirmed" | "failed";
  maturity: "standard" | "provisional_2_month" | "provisional_1_month" | "collecting_history";
  business_name?: string;
  location_id?: string;
  complete_months_available: number;
  months_used: Month[];
  baseline_metrics: Record<string, number | null>;
  metric_details?: Record<string, MetricDetail>;
  phone_calls?: MetricDetail;
  unavailable_metrics?: Record<string, string[]>;
  period_start?: string;
  period_end?: string;
  calculation_version?: string;
  established_at?: string;
};

export const Route = createFileRoute("/growth-baseline")({
  validateSearch: (search: Record<string, unknown>) => ({
    customer_id: typeof search.customer_id === "string" ? search.customer_id : undefined,
    location_id: typeof search.location_id === "string" ? search.location_id : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Establish Your Google Baseline — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: GrowthBaselinePage,
});

function fmt(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "—";
  return Number.isInteger(value) ? value.toLocaleString() : value.toLocaleString(undefined, { maximumFractionDigits: 1 });
}

function getCalculationLabel(detail?: MetricDetail | null, monthsAvailable?: number) {
  if (detail?.label) return detail.label;
  if (detail?.calculation === "3_month_average" || monthsAvailable === 3) return "3-month average";
  if (detail?.calculation === "2_month_average" || monthsAvailable === 2) return "2-month average";
  if (detail?.calculation === "single_month_actual" || monthsAvailable === 1) return "Based on 1 month of actual data";
  return "Building baseline";
}

function maturityLabel(maturity?: Baseline["maturity"], monthsAvailable = 0) {
  if (maturity === "standard" || monthsAvailable >= 3) return "3-month average";
  if (maturity === "provisional_2_month" || monthsAvailable === 2) return "2-month average";
  if (maturity === "provisional_1_month" || monthsAvailable === 1) return "Based on 1 month of actual data";
  return "Building baseline";
}


function GrowthBaselinePage() {
  const navigate = useNavigate();
  const { customer_id: customerId, location_id: locationId } = Route.useSearch();
  const [baseline, setBaseline] = useState<Baseline | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const query = useMemo(() => {
    const params = new URLSearchParams();
    if (customerId) params.set("customer_id", customerId);
    if (locationId) params.set("location_id", locationId);
    return params.toString() ? `?${params.toString()}` : "";
  }, [customerId, locationId]);

  const load = useCallback(async (manual = false) => {
    if (!customerId) {
      setError("We could not identify the Growth Program customer. Return to the dashboard and try again.");
      setLoading(false);
      return;
    }
    manual ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      const response = await apiFetch(`/api/user/growth-baseline/${encodeURIComponent(customerId)}${query}`);
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data?.detail || "Unable to establish your Google performance baseline.");
      setBaseline(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to establish your Google performance baseline.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [customerId, query]);

  useEffect(() => { load(); }, [load]);

  const confirmBaseline = async () => {
    if (!customerId || !baseline || baseline.maturity === "collecting_history") return;
    setConfirming(true);
    try {
      const response = await apiFetch(`/api/user/growth-baseline/${encodeURIComponent(customerId)}/confirm`, {
        method: "POST",
        body: JSON.stringify({ location_id: locationId || baseline.location_id }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data?.detail || "Unable to lock this baseline.");
      toast.success("Baseline confirmed and locked.");
      navigate({ to: "/dashboard", search: { customer_id: customerId, location_id: locationId || baseline.location_id } as any });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Unable to confirm baseline.");
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col">
      <SiteNav />
      <main className="flex-1">
        <section className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14 lg:px-12 lg:py-18">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <Link to="/dashboard" search={{ customer_id: customerId, location_id: locationId } as any} className="text-sm font-semibold text-black/55 hover:text-[#171512]">← Back to dashboard</Link>
            <Button variant="outline" size="sm" onClick={() => load(true)} disabled={refreshing} className="rounded-full gap-2 border-black/15">
              <RefreshCw size={13} className={refreshing ? "animate-spin" : ""} /> Refresh data
            </Button>
          </div>

          <div className="mt-10 max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#b64b25]/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#b64b25]">
              <BarChart3 size={14} /> Growth Program · Baseline
            </div>
            <h1 className="mt-5 font-serif text-4xl leading-tight tracking-tight sm:text-5xl lg:text-6xl">Establish the starting point for your growth.</h1>
            <p className="mt-5 text-lg leading-8 text-black/65">Trendit pulls your Google Business Profile performance history directly from Google and calculates the baseline automatically. The current partial month is never used.</p>
          </div>

          {loading ? (
            <div className="mt-10 rounded-3xl bg-white border border-black/10 p-12 flex items-center justify-center gap-3 text-sm text-black/60"><Loader2 size={18} className="animate-spin text-[#b64b25]" /> Analyzing your Google performance history…</div>
          ) : error ? (
            <div className="mt-10 rounded-3xl bg-white border border-black/10 p-8 space-y-4"><div className="font-semibold">Baseline could not be loaded</div><p className="text-sm leading-6 text-black/60">{error}</p><Button onClick={() => load(true)} className="rounded-full gap-2 bg-[#171512] text-white"><RefreshCw size={14} /> Try again</Button></div>
          ) : baseline ? (
            <>
              <div className="mt-10 rounded-3xl bg-white border border-black/10 p-6 sm:p-8 shadow-sm">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-[#b64b25]">{baseline.business_name || "Connected Google Business Profile"}</div>
                    <h2 className="mt-2 font-serif text-2xl sm:text-3xl">{maturityLabel(baseline.maturity, baseline.complete_months_available)}</h2>
                    <p className="mt-2 text-sm leading-6 text-black/60">
                      {baseline.complete_months_available > 0
                        ? `${baseline.complete_months_available} complete month${baseline.complete_months_available === 1 ? "" : "s"} of usable Google history were found before enrollment.`
                        : "Not enough complete historical data yet. Trendit will establish the baseline as more GBP performance data becomes available."}
                    </p>
                  </div>
                  <div className="inline-flex w-fit items-center gap-2 rounded-full border border-black/10 bg-[#f7f3eb] px-3 py-1.5 text-xs font-semibold"><ShieldCheck size={14} className="text-[#b64b25]" /> {baseline.status === "confirmed" ? "Locked" : baseline.status}</div>
                </div>

                {baseline.maturity === "collecting_history" || baseline.complete_months_available === 0 ? (
                  <div className="mt-8 rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5 flex gap-3"><Clock3 size={18} className="mt-0.5 shrink-0 text-amber-700" /><div><div className="font-semibold">Building baseline</div><p className="mt-1 text-sm leading-6 text-black/65">Not enough complete historical data yet. Trendit will establish the baseline as more GBP performance data becomes available.</p></div></div>
                ) : (
                  <>
                    <div className="mt-8 overflow-x-auto">
                      <table className="w-full min-w-[680px] text-sm">
                        <thead><tr className="border-b border-black/10 text-left text-xs uppercase tracking-wide text-black/45"><th className="pb-3 pr-4">Metric</th>{baseline.months_used.map((month) => <th key={month.start} className="pb-3 px-3">{month.label}</th>)}<th className="pb-3 pl-3">Baseline</th><th className="pb-3 pl-3">Calculation</th></tr></thead>
                        <tbody>{METRICS.map(([key, label]) => {
                          const detail = baseline.metric_details?.[key];
                          const metricLabel = getCalculationLabel(detail, detail?.months_available);
                          const isInsufficient = detail?.calculation === "insufficient_data" || detail?.months_available === 0 || baseline.baseline_metrics[key] == null;
                          return (
                            <tr key={key} className="border-b border-black/5">
                              <td className="py-4 pr-4 font-medium">{label}</td>
                              {baseline.months_used.map((month) => (
                                <td key={month.start} className="py-4 px-3 tabular-nums">{fmt(month.metrics[key])}</td>
                              ))}
                              <td className="py-4 pl-3 font-semibold tabular-nums">{isInsufficient ? "—" : fmt(baseline.baseline_metrics[key])}</td>
                              <td className="py-4 pl-3 text-xs">
                                <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                                  isInsufficient ? "bg-amber-500/10 text-amber-700" : "bg-black/5 text-black/75"
                                }`}>
                                  {metricLabel}
                                </span>
                              </td>
                            </tr>
                          );
                        })}</tbody>
                      </table>
                    </div>
                    {Object.keys(baseline.unavailable_metrics || {}).length > 0 && <div className="mt-5 rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 flex gap-3 text-sm"><AlertTriangle size={17} className="mt-0.5 shrink-0 text-amber-700" /><p className="leading-6 text-black/65">Some metrics have incomplete Google history. Trendit keeps them unavailable rather than treating missing data as zero; unavailable metrics are not eligible for performance billing until their measurement data is reliable.</p></div>}

                    <div className="mt-7 grid gap-4 sm:grid-cols-3">
                      <div className="rounded-2xl bg-[#f7f3eb] p-4"><div className="text-[11px] uppercase tracking-wide text-black/45">Measurement window</div><div className="mt-1 text-sm font-semibold">{baseline.period_start && baseline.period_end ? `${baseline.period_start} → ${baseline.period_end}` : "Collecting data"}</div></div>
                      <div className="rounded-2xl bg-[#f7f3eb] p-4"><div className="text-[11px] uppercase tracking-wide text-black/45">Calculation</div><div className="mt-1 text-sm font-semibold">{maturityLabel(baseline.maturity, baseline.complete_months_available)}</div></div>
                      <div className="rounded-2xl bg-[#f7f3eb] p-4"><div className="text-[11px] uppercase tracking-wide text-black/45">Version</div><div className="mt-1 text-sm font-semibold">{baseline.calculation_version || "Growth baseline v3"}</div></div>
                    </div>

                    <div className="mt-7 flex flex-col gap-3 rounded-2xl border border-black/10 bg-[#171512] p-5 text-white sm:flex-row sm:items-center sm:justify-between"><div className="flex gap-3"><LockKeyhole size={19} className="mt-0.5 shrink-0 text-[#f3a37f]" /><div><div className="font-semibold">Confirm and lock this baseline</div><p className="mt-1 text-xs leading-5 text-white/65">Once confirmed, the enrollment baseline is immutable. Later months are measured against this starting point and never silently rewrite it.</p></div></div><Button onClick={confirmBaseline} disabled={confirming || baseline.status === "confirmed" || baseline.complete_months_available === 0} className="shrink-0 rounded-full bg-white text-[#171512] hover:bg-white/90 gap-2">{confirming ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />} {baseline.status === "confirmed" ? "Baseline locked" : "Confirm baseline"}</Button></div>
                  </>
                )}
              </div>
            </>
          ) : null}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
