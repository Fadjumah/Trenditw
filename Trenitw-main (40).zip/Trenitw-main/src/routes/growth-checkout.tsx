import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, BarChart3, Check, ShieldCheck } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { FreemiusCheckoutButton } from "@/components/checkout-button";

export const Route = createFileRoute("/growth-checkout")({
  head: () => ({
    meta: [
      { title: "Start the Google Business Growth Program — Trendit" },
      {
        name: "description",
        content:
          "Set up your billing details for Trendit's performance-based Google Business Growth Program. No upfront program charge; billing is based on agreed additional growth.",
      },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: GrowthCheckoutPage,
});

function GrowthCheckoutPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col">
      <SiteNav />

      <main className="flex-1">
        <section className="mx-auto w-full max-w-6xl px-5 py-12 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
          <Link
            to="/growth-partnership"
            className="inline-flex items-center gap-2 text-sm font-semibold text-black/55 hover:text-[#171512] transition-colors"
          >
            <ArrowLeft size={16} />
            Back to Growth Program
          </Link>

          <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_0.85fr] lg:items-start lg:gap-16">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-[#b64b25]/20 bg-[#b64b25]/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-[#b64b25]">
                <BarChart3 size={14} />
                Google Business Growth Program
              </div>

              <h1 className="mt-6 max-w-2xl font-serif text-4xl leading-tight tracking-tight sm:text-5xl lg:text-6xl">
                Start growing first. Pay when the growth is there.
              </h1>

              <p className="mt-5 max-w-2xl text-lg leading-8 text-black/65">
                Set up your billing details to start the program. There is no upfront program charge. After checkout, Trendit takes you through a separate baseline establishment step using your actual Google Business Profile history before performance measurement begins.
              </p>

              <div className="mt-8 space-y-3">
                {[
                  "No upfront program charge",
                  "Your exact connected Google Business Profile is used",
                  "The system excludes the current partial month",
                  "Three complete months are used when available; newer profiles use a transparent provisional baseline",
                  "Missing Google data is never silently converted to zero",
                  "The confirmed enrollment baseline is locked and used for future measurement",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3 text-sm leading-6 text-black/70">
                    <Check size={18} className="mt-0.5 shrink-0 text-[#b64b25]" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-3xl border border-black/10 bg-white p-7 shadow-xl sm:p-9">
              <div className="border-b border-black/10 pb-6">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#b64b25]">
                  Secure billing setup
                </p>
                <h2 className="mt-2 font-serif text-2xl sm:text-3xl">
                  Enter your billing details
                </h2>
                <p className="mt-3 text-sm leading-6 text-black/55">
                  Freemius securely collects the billing details required for your Growth Program agreement. After successful setup, Trendit moves you to baseline establishment rather than treating checkout itself as the baseline.
                </p>
              </div>

              <div className="mt-6 rounded-2xl bg-[#f7f3eb] p-4 text-sm leading-6 text-black/65">
                <div className="flex items-start gap-3">
                  <ShieldCheck size={19} className="mt-0.5 shrink-0 text-[#b64b25]" />
                  <p>
                    <strong className="text-[#171512]">No upfront program charge.</strong> Billing setup is separate from baseline measurement. Actual performance billing should only use the agreed fee metrics and the locked enrollment baseline.
                  </p>
                </div>
              </div>

              <div className="mt-7">
                <FreemiusCheckoutButton
                  service="growth_program"
                  isGrowthProgram
                  planId={import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PLAN_ID || "68083"}
                  pricingId={import.meta.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRICING_ID || "89986"}
                  allowGuest
                  trial
                  billingCycle="monthly"
                  successPath="/growth-baseline"
                  onSuccess={(data: any) => {
                    const customerId = data?.customer_id || data?.customer?.id || data?.user?.customer_id;
                    const locationId = typeof window !== "undefined" ? localStorage.getItem("trendit_location_id") : null;
                    if (customerId) {
                      const params = new URLSearchParams({ customer_id: String(customerId) });
                      if (locationId) params.set("location_id", locationId);
                      navigate({ to: `/growth-baseline?${params.toString()}` as any });
                    } else {
                      navigate({ to: "/manage-connection?growth_enrolled=1" as any });
                    }
                  }}
                  className="w-full rounded-full bg-[#171512] px-6 py-4 text-sm font-semibold text-white hover:bg-black/90"
                >
                  Continue to Secure Checkout <ArrowRight size={17} />
                </FreemiusCheckoutButton>
              </div>

              <p className="mt-4 text-center text-xs leading-5 text-black/40">
                After billing setup, Trendit will establish your Google performance baseline before Growth measurement starts.
              </p>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
