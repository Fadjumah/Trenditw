import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Check, Phone, Globe, MapPin, BarChart3 } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { Link } from "@tanstack/react-router";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildGrowthPartnershipSchema,
  buildBreadcrumbSchema,
  buildJsonLdScript,
  SITE_URL,
} from "@/lib/seo";

const growthPartnershipSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildGrowthPartnershipSchema(),
  buildWebPageSchema({
    title: "Google Business Growth Program — Trendexhub | Trendit",
    description:
      "Full-service Google Business Profile management and local search growth partnership helping businesses win more customer calls, direction requests, and website visits.",
    url: `${SITE_URL}/growth-partnership`,
  }),
  buildBreadcrumbSchema([
    { name: "Home", path: "/" },
    { name: "Growth Partnership", path: "/growth-partnership" },
  ]),
];

export const Route = createFileRoute("/growth-partnership")({
  head: () => ({
    meta: createPageMeta({
      title: "Google Business Growth Program — Trendexhub | Trendit",
      description:
        "We manage and improve your Google presence to help generate more calls, enquiries and customer opportunities. When your Google performance grows, our commercial model grows with it.",
      canonicalPath: "/growth-partnership",
      keywords: [
        "Google Business Profile management",
        "Google Business Profile optimization",
        "Google Maps marketing",
        "local SEO program",
        "GBP management service",
        "performance-based business growth",
        "Trendexhub",
        "Trendit",
      ],
    }),
    links: [createCanonicalLink("/growth-partnership")],
    scripts: [buildJsonLdScript(growthPartnershipSchemaEntities)],
  }),
  component: GrowthPartnership,
});

export default function GrowthPartnership() {
  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col">
      <SiteNav />
      <main className="flex-1">
        <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 pb-16 pt-10 sm:px-8 lg:px-12 xl:px-16 lg:py-20">
          <div className="grid lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            <div className="lg:col-span-7 space-y-6 text-left">
              <p className="text-xs sm:text-sm font-semibold uppercase tracking-[0.16em] text-[#b64b25]">Google Business Growth Program</p>
              <h1 className="font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl xl:text-[76px] text-[#171512]">Get more customers from Google Search &amp; Maps.</h1>
              <p className="max-w-2xl text-lg sm:text-xl leading-8 text-black/65">We manage and improve your Google presence to help generate more calls, enquiries and customer opportunities. When your Google performance grows, our commercial model grows with it.</p>
              <div className="pt-2 flex flex-col gap-3 sm:flex-row">
                <Link to="/growth-checkout" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white hover:bg-black/90 transition-colors">Start My Growth Program <ArrowRight size={17} /></Link>
                <a href="#how-it-works" className="inline-flex items-center justify-center rounded-full border border-black/15 px-7 py-4 text-sm font-semibold hover:bg-black/5 transition-colors">See how it works</a>
              </div>
              <p className="text-sm text-black/50">No upfront program charge. Billing is based on agreed additional growth.</p>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl border border-black/10 bg-white p-7 sm:p-9 space-y-5 shadow-xl text-left">
                <div className="flex items-center justify-between border-b border-black/8 pb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#b64b25]">Growth Partnership</span>
                  <span className="text-xs font-mono text-emerald-600 font-semibold flex items-center gap-1">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                    Performance-Based
                  </span>
                </div>
                <div className="space-y-3">
                  <div className="p-3.5 rounded-2xl bg-[#f7f3eb] border border-black/5 flex items-center justify-between"><span className="text-xs text-black/70">Starting Historical Baseline</span><span className="text-xs font-bold text-[#171512]">Established</span></div>
                  <div className="p-3.5 rounded-2xl bg-[#f7f3eb] border border-black/5 flex items-center justify-between"><span className="text-xs text-black/70">Ongoing Management &amp; Content</span><span className="text-xs font-bold text-emerald-600">Done For You</span></div>
                  <div className="p-3.5 rounded-2xl bg-[#f7f3eb] border border-black/5 flex items-center justify-between"><span className="text-xs text-black/70">Google Verified Customer Inquiries</span><span className="text-xs font-bold text-[#b64b25]">Tracked Live</span></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=82", alt: "A business owner welcoming a customer", eyebrow: "Local growth", title: "More customers finding you" },
          { src: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=82", alt: "Business owners discussing a plan", eyebrow: "Partnership", title: "A practical growth plan" },
          { src: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=82", alt: "Business performance data on screen", eyebrow: "Outcomes", title: "Track the activity that matters" },
        ]} />

        <section className="border-y border-black/10 bg-white/45"><div className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-16 sm:px-8 lg:px-12 xl:px-16"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">The opportunity</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">How many customers is Google sending you right now?</h2><p className="mt-5 text-lg leading-8 text-black/65">Your business is already being searched for. People are looking for the products and services you provide on Google every day. The question is how much of that demand is reaching your business.</p></div><div className="mt-10 grid gap-6 sm:grid-cols-3">{[[Phone,"Calls","People choosing to contact your business."],[Globe,"Website visits","People moving from Google to your website."],[MapPin,"Direction requests","People asking Google how to reach you."]].map(([Icon,title,body]) => <div key={title as string} className="rounded-3xl border border-black/10 bg-white p-7 shadow-none"><Icon size={24} className="text-[#b64b25]"/><h3 className="mt-7 text-xl font-semibold">{title as string}</h3><p className="mt-2 text-sm leading-relaxed text-black/60">{body as string}</p></div>)}</div></div></section>

        <section id="how-it-works" className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">The program</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">We work on your Google presence. You focus on your business.</h2><p className="mt-5 text-lg leading-8 text-black/65">You don't need to become an expert in Google Business Profile management. We handle the ongoing work with one goal: help your business generate more customer opportunities from Google.</p></div><div className="mt-12 grid gap-6 md:grid-cols-2">{[['01','We establish where you are today','We look at your existing Google performance so there is a clear starting point.'],['02','We improve your Google presence','We manage the profile, content and ongoing optimization that can help your business compete for more attention.'],['03','We work toward more opportunities','The goal is simple: more relevant people discovering, contacting and choosing your business.'],['04','We measure what changed','We compare your ongoing Google performance with your previous performance so you can see whether you are growing.']].map(([number,title,body])=><div key={number} className="rounded-3xl border border-black/10 bg-white p-8 shadow-none"><span className="text-sm font-semibold text-[#b64b25]">{number}</span><h3 className="mt-6 font-serif text-2xl sm:text-3xl">{title}</h3><p className="mt-3 leading-relaxed text-black/60">{body}</p></div>)}</div></section>

        <section className="dark-surface bg-[#171512] px-5 py-20 text-white sm:px-8 lg:px-12 xl:px-16"><div className="mx-auto max-w-7xl 2xl:max-w-[1440px]"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">A simple example</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">What if Google brought you 12 more customer opportunities this month?</h2><p className="mt-5 text-lg leading-8 text-white/65">Imagine your business normally receives around 20 Google enquiries a month. After your Google presence is actively managed and improved, that becomes 32.</p></div><div className="mt-12 grid gap-6 md:grid-cols-3">{[['Before','20','Google enquiries / month'],['After','32','Google enquiries / month'],['Growth','+12','additional opportunities']].map(([label,value,sub])=><div key={label} className="rounded-3xl border border-white/15 p-8 shadow-none"><p className="text-sm text-white/50">{label}</p><p className="mt-3 text-5xl font-semibold">{value}</p><p className="mt-2 text-white/60">{sub}</p></div>)}</div><div className="mt-8 max-w-3xl rounded-3xl bg-white/8 p-8 border border-white/10"><p className="text-lg leading-8 text-white/75">If one customer is worth $100 to your business, 12 additional customers could represent $1,200 in additional business.</p><p className="mt-3 text-sm leading-6 text-white/45">Example only. Actual results vary by business, market, customer value and Google demand.</p></div></div></section>

        <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="grid gap-12 lg:grid-cols-[1fr_0.9fr] lg:items-start"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">The business model</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">Your growth matters to us too.</h2><p className="mt-5 text-lg leading-8 text-black/65">Instead of simply charging for marketing tasks, the program is designed around measurable Google growth. We establish your starting performance, improve your presence, monitor the results and calculate the agreed performance fee from the additional growth.</p></div><div className="rounded-3xl border border-black/10 bg-white p-8 shadow-none">{['Establish your historical Google performance','Manage and improve your Google presence','Track Google-generated customer actions','Compare results against your previous performance','Apply the agreed performance terms'].map(item=><div key={item} className="flex gap-3 border-b border-black/8 py-4 last:border-0"><Check className="mt-0.5 shrink-0 text-[#b64b25]" size={18}/><span className="leading-6">{item}</span></div>)}</div></div></section>

        <section className="border-y border-black/10 bg-white/50"><div className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">What we actually do</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">The work happens behind the scenes.</h2></div><div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{[['Google Business Profile management','Keep your profile active, complete and properly managed.'],['Content & Google Posts','Publish relevant content that keeps your Google presence useful and active.'],['Performance monitoring','Monitor the actions people take after finding you on Google.'],['Continuous optimization','Identify opportunities to improve how your business appears and competes.'],['Growth tracking','See how your Google performance changes over time.'],['Ongoing management','This is not a one-time setup. We keep working.']].map(([title,body])=><div key={title} className="rounded-3xl border border-black/10 bg-white p-7 shadow-none"><h3 className="font-semibold text-lg">{title}</h3><p className="mt-2 text-sm leading-relaxed text-black/60">{body}</p></div>)}</div></div></section>

        <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Who it's for</p><h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">Built for businesses where another customer is worth real money.</h2><p className="mt-5 text-lg leading-8 text-black/65">If your business depends on customers finding you locally, a stronger flow from Google can have a meaningful impact on revenue.</p></div><div className="mt-9 flex flex-wrap gap-3">{['Healthcare practices','Restaurants','Salons & beauty','Automotive','Home services','Professional services','Local retailers','Hospitality'].map(item=><span key={item} className="rounded-full border border-black/10 bg-white px-5 py-2.5 text-sm font-medium">{item}</span>)}</div></section>

        <section id="apply" className="bg-[#e9ddd0] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="mx-auto max-w-7xl 2xl:max-w-[1440px] rounded-3xl bg-white/60 p-8 sm:p-14 border border-black/10 text-center"><BarChart3 className="mx-auto text-[#b64b25]" size={36}/><h2 className="mt-5 font-serif text-4xl leading-tight sm:text-5xl">Your next customer could already be searching for you.</h2><p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-black/65">The question is whether they're finding and choosing your business. Let us help you turn more Google searches into customer opportunities.</p><Link to="/growth-checkout" className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#171512] px-8 py-4 text-sm font-semibold text-white hover:bg-black/90 transition-colors">Start My Growth Program <ArrowRight size={17}/></Link><p className="mt-4 text-sm text-black/50">No upfront program charge. Billing is based on agreed additional growth.</p></div></section>

        <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 xl:px-16"><div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-start"><div className="lg:col-span-5 space-y-4 lg:sticky lg:top-28 text-left"><p className="text-xs sm:text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">FAQ</p><h2 className="font-serif text-4xl sm:text-5xl text-[#171512]">Questions business owners ask</h2><p className="text-base text-black/65">How baseline measurement, performance attribution, and our partnership terms work.</p></div><div className="lg:col-span-7 divide-y divide-black/10">{[['Do I need to manage my Google Business Profile myself?','No. We handle the ongoing Google Business Profile work for you.'],['Do you guarantee a specific number of customers?','No. Google demand, competition, market conditions and customer decisions are outside our control. We focus on improving your Google presence and measuring the resulting customer activity.'],['How do you measure growth?','We establish your historical Google performance and compare ongoing results against that starting point.'],['What customer opportunities do you measure?','Depending on your business, this can include calls, website visits and direction requests generated through your Google Business Profile.'],['How quickly will I see results?','It depends on your market, competition, existing Google presence and search demand. Meaningful growth generally requires ongoing work.']].map(([question,answer])=><details key={question} className="group py-6"><summary className="cursor-pointer list-none pr-8 text-lg font-semibold">{question}</summary><p className="mt-3 max-w-3xl leading-7 text-black/60">{answer}</p></details>)}</div></div></section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&w=1200&q=82", alt: "A focused business strategy meeting", eyebrow: "Strategy", title: "A plan shaped around your business" },
          { src: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=1200&q=82", alt: "Professionals discussing performance", eyebrow: "Review", title: "See the work and the outcome" },
          { src: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=82", alt: "Business owners working through a plan", eyebrow: "Growth", title: "Turn local demand into opportunity" },
        ]} />
      </main>
      <SiteFooter />
    </div>
  );
}
