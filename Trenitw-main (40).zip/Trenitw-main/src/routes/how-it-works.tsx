import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Search, Star, TrendingUp, FileText, ArrowRight } from "lucide-react";
import { GoogleConnectButton } from "@/components/google-connect-button";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildFAQSchema,
  buildJsonLdScript,
  SITE_URL,
} from "@/lib/seo";

const HOW_IT_WORKS_FAQS = [
  {
    q: "How does Trendit connect to my Google Business Profile?",
    a: "Trendit connects through official Google OAuth. You sign in with the Google account that manages your profile and never share your password.",
  },
  {
    q: "Does Trendit publish posts automatically?",
    a: "You can review and approve posts yourself, or use the available scheduling and automation controls to keep your profile active.",
  },
  {
    q: "Can I manage more than one location?",
    a: "Yes. Trendit is designed for single businesses, service-area businesses and multi-location operations.",
  },
];

const howItWorksSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildWebPageSchema({
    title: "How It Works — Google Business Profile Growth | Trendit",
    description:
      "See how Trendit connects to your Google Business Profile, audits it, keeps it active and tracks customer discovery.",
    url: `${SITE_URL}/how-it-works`,
  }),
  buildFAQSchema(HOW_IT_WORKS_FAQS),
];

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: createPageMeta({
      title: "How It Works — Google Business Profile Growth | Trendit",
      description:
        "See how Trendit connects to your Google Business Profile, audits it, keeps it active and tracks customer discovery.",
      canonicalPath: "/how-it-works",
      keywords: [
        "how Trendit works",
        "Google Business Profile automation",
        "local SEO automation",
        "Google Maps business growth",
      ],
    }),
    links: [createCanonicalLink("/how-it-works")],
    scripts: [buildJsonLdScript(howItWorksSchemaEntities)],
  }),
  component: HowItWorksPage,
});

const WORKFLOW_STAGES = [
  {
    step: "01",
    title: "Connect & audit",
    summary:
      "Connect your Google Business Profile through official Google OAuth. Trendit checks the profile and surfaces the areas that need attention.",
    details: ["Profile information and categories", "Hours and service details", "Photos and key profile completeness"],
    icon: Search,
  },
  {
    step: "02",
    title: "Keep it active",
    summary:
      "Use Trendit to prepare and schedule relevant Google Business Profile posts so your listing stays fresh without adding another weekly task to your calendar.",
    details: ["Localized business content", "Scheduling and publishing controls", "Visual content support"],
    icon: FileText,
  },
  {
    step: "03",
    title: "Stay responsive",
    summary:
      "Monitor new customer reviews and prepare contextual responses so important customer feedback does not sit unanswered.",
    details: ["New review monitoring", "Contextual response drafts", "Simple approval workflow"],
    icon: Star,
  },
  {
    step: "04",
    title: "Measure discovery",
    summary:
      "Track the customer actions available from your Google Business Profile and use the data to decide what to improve next.",
    details: ["Phone calls and direction requests", "Website and discovery activity", "Clear performance trends"],
    icon: TrendingUp,
  },
];

function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col">
      <SiteNav />

      <main className="flex-1 pb-16">
        <section className="mx-auto max-w-7xl 2xl:max-w-[1440px] px-5 pb-14 pt-10 sm:px-8 lg:px-12 xl:px-16 lg:py-20">
          <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
            <div className="space-y-6 lg:col-span-7">
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#b64b25] sm:text-sm">
                How Trendit works
              </p>
              <h1 className="font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl text-balance">
                From Google profile to a more active{" "}
                <span className="italic text-[#b64b25]">customer engine.</span>
              </h1>
              <p className="max-w-2xl text-lg leading-8 text-black/65 sm:text-xl">
                Connect once, see what needs attention, keep your profile active,
                respond to customers and measure the discovery actions that matter.
              </p>
              <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:items-center">
                <GoogleConnectButton
                  variant="default"
                  size="lg"
                  source="how_it_works_hero"
                  className="h-12 justify-center rounded-full bg-[#171512] px-7 text-sm font-semibold text-white shadow-none hover:bg-black/90"
                >
                  Connect your business free
                </GoogleConnectButton>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-12 rounded-full border border-black/15 px-6 text-sm font-semibold shadow-none"
                  onClick={() => document.getElementById("stages")?.scrollIntoView({ behavior: "smooth" })}
                >
                  See the 4 steps ↓
                </Button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <figure className="group overflow-hidden rounded-[28px] bg-white dark:bg-[#201d19]">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=84"
                    alt="Business team planning a growth strategy"
                    loading="lazy"
                    decoding="async"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/5 to-transparent" />
                  <figcaption className="absolute inset-x-0 bottom-0 p-6 sm:p-8 text-white">
                    <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/70">
                      One simple loop
                    </div>
                    <div className="font-serif text-2xl leading-tight sm:text-3xl">
                      Connect → improve → stay active → measure
                    </div>
                  </figcaption>
                </div>
              </figure>
            </div>
          </div>
        </section>

        <PublicVisualStrip
          className="py-6 sm:py-8 lg:py-10"
          items={[
            {
              src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=82",
              alt: "Business analytics on a laptop",
              eyebrow: "Measure",
              title: "Work from real business signals",
            },
            {
              src: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=82",
              alt: "Business owner working from a laptop",
              eyebrow: "Automate",
              title: "Reduce repetitive marketing work",
            },
            {
              src: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=82",
              alt: "People collaborating around a table",
              eyebrow: "Improve",
              title: "Know what to work on next",
            },
          ]}
        />

        <section id="stages" className="border-y border-black/10 bg-white/45 px-5 py-16 sm:px-8 lg:px-12 xl:px-16">
          <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
            <div className="mb-10 max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#b64b25] sm:text-sm">The workflow</p>
              <h2 className="mt-2 font-serif text-4xl leading-tight sm:text-5xl">Four steps. No unnecessary complexity.</h2>
            </div>

            <div className="grid gap-5 lg:grid-cols-2">
              {WORKFLOW_STAGES.map((stage) => {
                const Icon = stage.icon;
                return (
                  <article key={stage.step} className="rounded-[28px] bg-white p-7 sm:p-9">
                    <div className="flex items-center justify-between gap-4">
                      <span className="rounded-full bg-[#b64b25]/10 px-3 py-1 text-xs font-semibold tracking-wider text-[#b64b25]">
                        {stage.step}
                      </span>
                      <Icon className="h-6 w-6 text-[#b64b25]" />
                    </div>
                    <h3 className="mt-5 font-serif text-2xl sm:text-3xl">{stage.title}</h3>
                    <p className="mt-3 text-sm leading-7 text-black/65 sm:text-base">{stage.summary}</p>
                    <ul className="mt-5 space-y-2.5">
                      {stage.details.map((detail) => (
                        <li key={detail} className="flex items-start gap-2.5 text-sm text-black/70">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#b64b25]" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-16 text-center sm:px-8 lg:py-20">
          <div className="rounded-[30px] bg-[#171512] p-8 text-white sm:p-12">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">Ready when you are</p>
            <h2 className="mx-auto mt-3 max-w-2xl font-serif text-4xl leading-tight sm:text-5xl">
              Give your Google profile a system behind it.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base leading-7 text-white/65">
              Connect your business and start with the information already in your Google Business Profile.
            </p>
            <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <GoogleConnectButton
                variant="default"
                size="lg"
                source="how_it_works_bottom"
                className="h-12 rounded-full bg-[#b64b25] px-7 text-sm font-semibold text-white shadow-none hover:bg-[#a03f1d]"
              >
                Connect your business
              </GoogleConnectButton>
              <Button asChild variant="outline" size="lg" className="h-12 rounded-full border-white/20 bg-transparent px-7 text-sm font-semibold text-white hover:bg-white/10">
                <Link to="/" hash="pricing" className="inline-flex items-center gap-2">
                  Explore plans <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
