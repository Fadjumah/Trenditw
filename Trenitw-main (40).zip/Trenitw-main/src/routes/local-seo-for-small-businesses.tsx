import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Search, Globe, MapPin, BarChart3 } from "lucide-react";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { createPageMeta, createCanonicalLink, buildOrganizationSchema, buildWebSiteSchema, buildWebPageSchema, buildBreadcrumbSchema, buildFAQSchema, buildJsonLdScript, SITE_URL } from "@/lib/seo";

const faqs = [
  { q: "What is local SEO?", a: "Local SEO is the work of making a business more relevant and discoverable for searches connected to a place, service area or local intent." },
  { q: "Does local SEO only mean Google Maps?", a: "No. Google Business Profile is important, but local SEO also involves your website, location and service information, reviews, links, citations and the overall consistency of your business information." },
  { q: "How long does local SEO take?", a: "There is no universal timeline. Results depend on the market, competition, existing visibility, website quality, profile history, demand and the work being done." },
];

export const Route = createFileRoute("/local-seo-for-small-businesses")({
  head: () => ({
    meta: createPageMeta({
      title: "Local SEO for Small Businesses: A Practical Guide to Getting Found Locally | Trendit",
      description: "A practical guide to local SEO for small businesses: Google Business Profile, website relevance, reviews, local content, measurement and the recurring work that supports local visibility.",
      canonicalPath: "/local-seo-for-small-businesses",
      keywords: ["local SEO for small businesses", "local SEO", "small business SEO", "Google Maps SEO", "local search marketing"],
    }),
    links: [createCanonicalLink("/local-seo-for-small-businesses")],
    scripts: [buildJsonLdScript([
      buildOrganizationSchema(), buildWebSiteSchema(),
      buildWebPageSchema({ title: "Local SEO for Small Businesses: A Practical Guide to Getting Found Locally | Trendit", description: "A practical guide to local SEO for small businesses.", url: `${SITE_URL}/local-seo-for-small-businesses` }),
      buildBreadcrumbSchema([{ name: "Home", path: "/" }, { name: "Local SEO for Small Businesses", path: "/local-seo-for-small-businesses" }]),
      buildFAQSchema(faqs),
    ])],
  }),
  component: Page,
});

function Page() {
  const pillars = [
    [Search,"Search relevance","Make it obvious what your business does, who it serves and which locations or service areas matter."],
    [MapPin,"Local presence","Keep your Google Business Profile and other important business information accurate and consistent."],
    [Globe,"Website usefulness","Create pages that genuinely answer the questions people have before contacting you."],
    [MessageSquareIcon,"Customer trust","Reviews, responses, real photos and clear service information help people evaluate you."],
    [BarChart3,"Measurement","Use available performance data to learn which parts of your local presence are generating activity."],
  ];
  return <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col"><SiteNav/><main className="flex-1">
    <section className="mx-auto max-w-5xl px-5 pb-16 pt-14 sm:px-8 lg:pt-24"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Local SEO guide</p><h1 className="mt-4 max-w-4xl font-serif text-5xl leading-[0.98] sm:text-6xl lg:text-7xl">Local SEO for small businesses: get easier to find when people are looking nearby.</h1><p className="mt-7 max-w-3xl text-lg leading-8 text-black/65">Local SEO is not one trick or one ranking factor. It is the connected work of making your business understandable, credible and useful across the places customers search. For many local businesses, Google Search and Maps are central to that journey.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><Link to="/subscribe" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Put it into practice <ArrowRight size={17}/></Link><Link to="/google-business-profile-management" className="inline-flex items-center justify-center rounded-full border border-black/15 px-7 py-4 text-sm font-semibold">Google Business Profile guide</Link></div></section>

        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1200&q=82", alt: "A small business owner at work", eyebrow: "Small business", title: "Compete where customers search" },
          { src: "https://images.unsplash.com/photo-1529502669401-57d9f0b5c7d1?auto=format&fit=crop&w=1200&q=82", alt: "A team working around a table", eyebrow: "Strategy", title: "Build visibility around real demand" },
          { src: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=82", alt: "Customers enjoying a local business", eyebrow: "Discovery", title: "Get found by nearby customers" },
        ]} />

    <section className="border-y border-black/10 bg-white/50"><div className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="grid gap-5 md:grid-cols-2">{pillars.map(([Icon,title,body])=><div key={title as string} className="rounded-3xl border border-black/10 bg-white p-7"><Icon size={22} className="text-[#b64b25]"/><h2 className="mt-5 text-xl font-semibold">{title as string}</h2><p className="mt-2 text-sm leading-7 text-black/60">{body as string}</p></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="max-w-3xl"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Start with the fundamentals</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Make your business easy for both people and search systems to understand.</h2><p className="mt-5 text-lg leading-8 text-black/65">A local customer should not have to work out what you do, where you operate or how to contact you. The same clarity helps search engines connect a business with relevant local queries.</p></div><div className="mt-10 space-y-5">{[
      ["1","Get the core facts right","Business name, primary category, phone number, website, hours, address or service area and services should reflect the real business."],
      ["2","Build a useful Google Business Profile","Complete relevant fields, use accurate categories and add genuine photos and information that help a potential customer make a decision."],
      ["3","Create useful website pages","Write pages around real customer needs: services, locations, pricing context, frequently asked questions and practical information. Avoid creating thin pages simply to target keywords."],
      ["4","Earn and respond to reviews","Ask genuine customers for reviews in appropriate ways and respond professionally. Reviews can influence how people evaluate a business even when they do not directly determine rankings."],
      ["5","Keep the ecosystem consistent","Important business details should not conflict across your website, Google profile and other trusted listings."],
      ["6","Measure customer actions","Where data is available, monitor calls, website visits, direction requests and other profile interactions rather than judging success only by impressions."],
    ].map(([n,t,b])=><div key={n} className="grid gap-4 rounded-3xl border border-black/10 bg-white p-7 sm:grid-cols-[48px_1fr]"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#fff0e8] text-sm font-semibold text-[#b64b25]">{n}</span><div><h3 className="font-serif text-2xl">{t}</h3><p className="mt-2 text-sm leading-7 text-black/60">{b}</p></div></div>)}</div></section>

    <section className="bg-[#171512] text-white"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#f3a37f]">Avoid the common trap</p><h2 className="mt-3 max-w-3xl font-serif text-4xl sm:text-5xl">Local SEO works better as a routine than a one-off project.</h2><p className="mt-5 max-w-3xl text-lg leading-8 text-white/65">Many businesses optimize a profile once, publish a few posts, then stop. The problem is that the business continues to change and customers continue to ask new questions. A repeatable operating rhythm makes it easier to keep information fresh, respond to customers and learn from performance.</p><div className="mt-10 grid gap-4 md:grid-cols-4">{["Audit","Improve","Publish","Measure"].map((x,i)=><div key={x} className="rounded-2xl border border-white/10 p-6"><span className="text-sm text-[#f3a37f]">0{i+1}</span><h3 className="mt-5 text-lg font-semibold">{x}</h3></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><div className="grid gap-10 lg:grid-cols-[1fr_0.82fr]"><div><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">Where Trendit helps</p><h2 className="mt-3 font-serif text-4xl sm:text-5xl">Make the Google side of local SEO less manual.</h2><p className="mt-5 text-lg leading-8 text-black/65">Trendit focuses on the part of local growth that businesses repeatedly struggle to maintain: the Google Business Profile. It brings auditing, content workflows, review management and performance monitoring into one place.</p><p className="mt-5 text-base leading-7 text-black/60">It is not a promise of instant rankings. It is infrastructure for consistently doing the work that supports a useful Google presence.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-6 py-3.5 text-sm font-semibold text-white">Start Trendit <ArrowRight size={16}/></Link></div><div className="rounded-3xl border border-black/10 bg-white p-7"><h3 className="font-serif text-2xl">A practical weekly checklist</h3>{["Review profile accuracy","Check new customer reviews","Publish useful local content","Look at available customer actions","Record what changed"].map(x=><div key={x} className="flex gap-3 border-b border-black/8 py-4 last:border-0"><Check size={18} className="mt-0.5 shrink-0 text-[#b64b25]"/><span className="text-sm">{x}</span></div>)}</div></div></section>

    <section className="border-t border-black/10 bg-white/45"><div className="mx-auto max-w-5xl px-5 py-20 sm:px-8"><p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">FAQ</p><div className="mt-8 divide-y divide-black/10">{faqs.map(f=><div key={f.q} className="py-6"><h2 className="text-lg font-semibold">{f.q}</h2><p className="mt-2 max-w-3xl text-sm leading-7 text-black/60">{f.a}</p></div>)}</div></div></section>
    <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8"><div className="rounded-3xl bg-[#e9ddd0] p-8 text-center sm:p-12"><h2 className="font-serif text-4xl sm:text-5xl">Build local visibility one useful improvement at a time.</h2><p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-black/60">Start with your Google presence, then build a repeatable system around it.</p><Link to="/subscribe" className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#171512] px-7 py-4 text-sm font-semibold text-white">Get started <ArrowRight size={17}/></Link></div></section>
  </main><SiteFooter/></div>;
}
function MessageSquareIcon(props: {size?: number}) { return <svg width={props.size||22} height={props.size||22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#b64b25]"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg>; }
