import {
  createFileRoute,
  useSearch,
  useNavigate,
} from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Store,
  CheckCircle2,
  Loader2,
  MapPin,
  ShieldCheck,
} from "lucide-react";
import { identifyUser, track } from "@/lib/analytics";
import { useState, useEffect } from "react";
import { z } from "zod";
import { apiFetch } from "@/lib/api";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

import { GrowthUpgradeModal } from "@/components/growth-upgrade-modal";

const locationPickerSearchSchema = z.object({
  customer_id: z.string().optional(),
  locations: z.string().optional(),
  active_location_id: z.string().optional(),
  email: z.string().optional(),
});

export const Route = createFileRoute("/location-picker")({
  validateSearch: locationPickerSearchSchema,
  head: () => ({
    meta: [
      { title: "Select Location — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: LocationPicker,
});

interface LocationItem {
  location_id: string;
  business_name: string;
  address?: string | null;
  account_id?: string | null;
}

function LocationPicker() {
  const {
    customer_id,
    locations: encodedLocations,
    active_location_id,
    email,
  } = useSearch({ from: "/location-picker" });

  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [locations, setLocations] = useState<LocationItem[]>([]);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);

  useEffect(() => {
    track("location_picker_view");

    if (typeof window !== "undefined") {
      const storedCustomerId =
        customer_id || localStorage.getItem("trendit_customer_id");
      if (!storedCustomerId) {
        navigate({ to: "/" });
        return;
      }
    }

    if (!encodedLocations) {
      setLocations([]);
      return;
    }

    try {
      let decodedStr = "";
      if (typeof window !== "undefined") {
        try {
          decodedStr = decodeURIComponent(
            escape(window.atob(encodedLocations)),
          );
        } catch {
          decodedStr = window.atob(encodedLocations);
        }
      } else {
        decodedStr = Buffer.from(encodedLocations, "base64").toString("utf-8");
      }
      const parsed = JSON.parse(decodedStr);
      setLocations(Array.isArray(parsed) ? parsed : []);
    } catch (e) {
      console.error("Failed to decode locations", e);
      toast.error("Error loading Google Business Profiles list");
    }
  }, [encodedLocations, customer_id, navigate]);

  const handleSelect = async (loc: LocationItem) => {
    const activeCustomerId =
      customer_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_customer_id") || ""
        : "");

    // If selecting a different business when an active one exists, check growth entitlement
    const isSwitching =
      active_location_id && loc.location_id !== active_location_id;
    if (isSwitching) {
      try {
        const entRes = await apiFetch(
          `/api/user/entitlement/${encodeURIComponent(activeCustomerId)}`,
        );
        if (entRes.ok) {
          const ent = await entRes.json();
          if (!ent?.has_access) {
            setUpgradeModalOpen(true);
            return;
          }
        }
      } catch (e) {
        console.warn("Location switch entitlement check error:", e);
      }

      if (
        !window.confirm(
          `Switch active business to "${loc.business_name}"?\n\n` +
            `Trendit will now manage this location. Your past post history and audit reports will be preserved.`,
        )
      ) {
        return;
      }
    }

    setSelectedId(loc.location_id);
    setLoading(true);
    track("business_selected", {
      user_id: activeCustomerId,
      business_id: loc.location_id,
      location_id: loc.location_id,
      business_name: loc.business_name,
      selection_type: isSwitching ? "switch" : "initial",
      source: "location_picker",
    });

    try {
      const response = await apiFetch("/oauth/select-location", {
        method: "POST",
        body: JSON.stringify({
          customer_id: activeCustomerId,
          location_id: loc.location_id,
          business_name: loc.business_name,
          account_id: loc.account_id || null,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast.success(`Connected to ${loc.business_name}`);

        // Identify the authenticated customer only after GBP selection succeeds,
        // when the connected profile name is actually known.
        identifyUser(activeCustomerId, {
          ...(email ? { email } : {}),
          business_name: loc.business_name,
          gbp_profile_name: loc.business_name,
        });

        if (typeof window !== "undefined") {
          if (activeCustomerId) localStorage.setItem("trendit_customer_id", activeCustomerId);
          if (data.session_token)
            localStorage.setItem("trendit_token", data.session_token);
          localStorage.setItem("trendit_location_id", loc.location_id);
          localStorage.setItem("trendit_business_name", loc.business_name);
          if (email) localStorage.setItem("trendit_email", email);
        }

        // Check active entitlement to determine if billing gate is required
        let hasSubscription = true; // default safe fallback
        try {
          const entRes = await apiFetch(`/api/user/entitlement/${encodeURIComponent(activeCustomerId)}`);
          if (entRes.ok) {
            const entData = await entRes.json();
            hasSubscription = entData.has_subscription === true;
          }
        } catch (e) {
          console.warn("Could not check entitlement status:", e);
        }

        if (hasSubscription) {
          // Redirect directly to dashboard with location context
          navigate({
            to: "/dashboard",
            search: {
              customer_id,
              location_id: loc.location_id,
              email: email || undefined,
            },
          });
        } else {
          // Direct to billing gate if no active entitlement exists
          navigate({
            to: "/billing",
            search: {
              customer_id,
              location_id: loc.location_id,
              email: email || undefined,
            },
          });
        }
      } else {
        const error = await response.json();
        track("business_connection_failed", {
          user_id: customer_id,
          business_id: loc.location_id,
          location_id: loc.location_id,
          failure_category: "server_error",
          error_category: "server_error",
          failure_stage: "location_selection",
          retryable: true,
          source: "location_picker",
        });
        toast.error(error.detail || "Failed to select location");
      }
    } catch (err) {
      console.error("Selection error:", err);
      track("business_connection_failed", {
        user_id: customer_id,
        business_id: loc.location_id,
        location_id: loc.location_id,
        failure_category: "network_error",
        error_category: "network_error",
        failure_stage: "location_selection",
        retryable: true,
        source: "location_picker",
      });
      toast.error(
        "An unexpected error occurred selecting your business profile",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-editorial location-editorial min-h-screen bg-background flex flex-col overflow-x-hidden">
      <SiteNav />
      <main className="flex-1 container-page py-8 sm:py-12 flex flex-col items-center justify-center">
        <div className="w-full max-w-3xl 2xl:max-w-4xl">
          <div className="text-center mb-6 sm:mb-8">
            <h1 className="font-serif text-2xl sm:text-4xl tracking-tight text-balance">
              {locations.length <= 1
                ? "Select your Google Business Profile"
                : "Which business should Trendit manage?"}
            </h1>
            <p className="text-muted-foreground mt-2 text-sm sm:text-base leading-relaxed text-balance">
              {locations.length <= 1
                ? "We found this Business Profile in your Google account. Confirm it to continue."
                : `We found ${locations.length} Business Profiles in your Google account. Choose the one you want Trendit to manage.`}
            </p>
          </div>

          <div className="grid gap-3 sm:gap-4">
            {locations.map((loc) => {
              const isCurrentlyActive =
                active_location_id &&
                (loc.location_id === active_location_id ||
                  loc.location_id.endsWith(`/${active_location_id}`));

              return (
                <Card
                  key={loc.location_id}
                  className={`transition-all cursor-pointer hover:border-[#b64b25] shadow-none ${
                    selectedId === loc.location_id
                      ? "border-2 border-[#b64b25] bg-[#b64b25]/5"
                      : isCurrentlyActive
                        ? "border-2 border-[#b64b25]/60 bg-[#b64b25]/5"
                        : "border border-black/10 dark:border-white/15"
                  }`}
                  onClick={() => !loading && handleSelect(loc)}
                >
                  <CardContent className="p-5 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-3 sm:gap-4 min-w-0">
                      <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-accent/10 flex items-center justify-center text-accent shrink-0 mt-0.5">
                        <Store size={20} className="sm:hidden" />
                        <Store size={24} className="hidden sm:block" />
                      </div>
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-base sm:text-xl font-semibold text-foreground truncate">
                            {loc.business_name}
                          </h3>
                          {isCurrentlyActive && (
                            <Badge
                              variant="outline"
                              className="text-[10px] bg-[#b64b25]/15 border-[#b64b25] text-[#b64b25]"
                            >
                              Currently Active
                            </Badge>
                          )}
                        </div>
                        {loc.address ? (
                          <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1.5 leading-snug">
                            <MapPin
                              size={13}
                              className="text-accent shrink-0"
                            />
                            <span className="break-words">{loc.address}</span>
                          </p>
                        ) : null}
                        <p className="text-[11px] text-muted-foreground/70">
                          Trendit will use this profile for your audits, content
                          and approvals.
                        </p>
                      </div>
                    </div>
                    <div className="sm:ml-4 shrink-0 w-full sm:w-auto">
                      {selectedId === loc.location_id ? (
                        <div className="text-accent flex justify-center sm:justify-end">
                          {loading ? (
                            <Loader2 className="animate-spin" size={24} />
                          ) : (
                            <CheckCircle2 size={24} />
                          )}
                        </div>
                      ) : (
                        <Button
                          variant={isCurrentlyActive ? "secondary" : "default"}
                          size="sm"
                          disabled={loading}
                          className="w-full sm:w-auto text-xs min-h-[38px] rounded-full px-5"
                        >
                          {isCurrentlyActive
                            ? "Keep Active"
                            : "Select Business"}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="mt-8 sm:mt-12 space-y-4">
            <div className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] p-5 sm:p-7 flex items-start gap-3.5 text-left shadow-none">
              <ShieldCheck size={18} className="mt-0.5 shrink-0 text-accent" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  You're choosing the profile, not handing over your account.
                </p>
                <p className="mt-1 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  Trendit works with the Business Profile you select. Your
                  Google password is never shared with Trendit, and you can
                  revoke access from your Google Account.
                </p>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed text-center">
              Don't see your business? Make sure this Google account has Owner
              or Manager access to the profile.
            </p>
          </div>
        </div>
      </main>

      <GrowthUpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
        title="Unlock Multi-Location Switching"
        description="Connecting and actively switching between multiple Google Business Profiles requires an active Trendit subscription."
        highlightFeature="Manage multiple Google Business Profile locations"
        onSuccess={() => {
          window.location.reload();
        }}
      />

      <SiteFooter />
    </div>
  );
}
