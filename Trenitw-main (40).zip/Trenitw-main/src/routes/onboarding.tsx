import {
  createFileRoute,
  useSearch,
  useNavigate,
} from "@tanstack/react-router";
import { useEffect } from "react";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";

const onboardingSearchSchema = z.object({
  connected: z.string().optional(),
  customer_id: z.string().optional(),
  location_id: z.string().optional(),
  email: z.string().optional(),
});

export const Route = createFileRoute("/onboarding")({
  validateSearch: onboardingSearchSchema,
  head: () => ({
    meta: [
      { title: "Onboarding — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: OnboardingPage,
});

function OnboardingPage() {
  const { customer_id, location_id, email } = useSearch({
    from: "/onboarding",
  });
  const navigate = useNavigate();

  useEffect(() => {
    const storedCustomerId =
      customer_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_customer_id")
        : null);
    const storedLocationId =
      location_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_location_id")
        : null);
    const storedEmail =
      email ||
      (typeof window !== "undefined"
        ? localStorage.getItem("trendit_email")
        : null);

    if (customer_id && typeof window !== "undefined") {
      localStorage.setItem("trendit_customer_id", customer_id);
    }
    if (location_id && typeof window !== "undefined") {
      localStorage.setItem("trendit_location_id", location_id);
    }
    if (email && typeof window !== "undefined") {
      localStorage.setItem("trendit_email", email);
    }

    navigate({
      to: "/dashboard",
      search: {
        customer_id: storedCustomerId || undefined,
        location_id: storedLocationId || undefined,
        email: storedEmail || undefined,
      },
    });
  }, [customer_id, location_id, email, navigate]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center space-y-4 max-w-xs mx-auto">
        <BrandLogo iconClassName="h-9 w-9" textClassName="text-[26px]" className="justify-center" />
        <div className="flex items-center justify-center gap-2 pt-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin text-accent" />
          <span>Redirecting to your Dashboard...</span>
        </div>
      </div>
    </div>
  );
}
