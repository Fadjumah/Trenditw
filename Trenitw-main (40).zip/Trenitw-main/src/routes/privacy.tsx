import { createFileRoute } from "@tanstack/react-router";
import {
  Callout,
  LegalList,
  LegalSection,
  LegalShell,
} from "@/components/legal-shell";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildJsonLdScript,
  SITE_URL,
} from "@/lib/seo";

const privacySchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildWebPageSchema({
    title: "Privacy Policy — Trendit by Trendexhub",
    description:
      "How Trendit collects, uses, and protects information from your Google Business Profile, Ads, and related Google services.",
    url: `${SITE_URL}/privacy`,
    pageType: "WebPage",
  }),
];

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: createPageMeta({
      title: "Privacy Policy — Trendit by Trendexhub",
      description:
        "How Trendit collects, uses, and protects information from your Google Business Profile, Ads, and related Google services.",
      canonicalPath: "/privacy",
      keywords: [
        "Trendit privacy policy",
        "Google API user data policy",
        "Google Business Profile data privacy",
      ],
    }),
    links: [createCanonicalLink("/privacy")],
    scripts: [buildJsonLdScript(privacySchemaEntities)],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <LegalShell
      title="Privacy Policy"
      effective="26 April 2026"
      updated="26 April 2026"
    >
      <LegalSection number={1} title="Introduction">
        <p>
          Trendit is an autonomous business profile management platform
          developed and operated by Trendexhub, a software company registered in
          Uganda. This Privacy Policy explains how Trendit collects, discloses,
          and protects information when you use the platform to manage your
          Google Business Profile, Google Ads campaigns, and related Google
          services.
        </p>
        <p>
          By using Trendit, you agree to the practices described in this policy.
          If you do not agree, please discontinue use of the platform. For
          questions, contact us at{" "}
          <a
            className="text-accent underline"
            href="mailto:info@trendexhub.com"
          >
            info@trendexhub.com
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection
        number={2}
        title="Google API Services — Limited Use Disclosure"
      >
        <Callout>
          Trendit's use and transfer to any other app of information received
          from Google APIs will adhere to the{" "}
          <a
            className="text-accent underline"
            href="https://developers.google.com/terms/api-services-user-data-policy"
            target="_blank"
            rel="noreferrer"
          >
            Google API Services User Data Policy
          </a>
          , including the Limited Use requirements.
        </Callout>
        <p>
          Trendit accesses the following Google APIs on your behalf, solely to
          provide the features described in this policy:
        </p>
        <LegalList
          items={[
            <>
              <strong>Google Business Profile API</strong> — to manage your
              business listing, publish posts, respond to customer reviews,
              answer questions, update business information, manage photos and
              media, and retrieve performance insights.
            </>,
            <>
              <strong>Google Ads API</strong> — to read campaign performance
              data, monitor ad spend, retrieve impression and click metrics, and
              surface advertising insights within the Trendit dashboard. Trendit
              does not create, modify, or delete Google Ads campaigns without
              your explicit instruction.
            </>,
            <>
              <strong>Google OAuth 2.0</strong> — to authenticate your identity
              and authorise Trendit to access only the Google services you
              explicitly grant permission for.
            </>,
          ]}
        />
        <p>
          Data obtained through these Google APIs is used{" "}
          <strong>exclusively</strong> to provide and improve the Trendit
          service to you. Trendexhub does not use this data to serve
          advertisements, sell it to third parties, or use it for any purpose
          unrelated to the functionality described in this policy. Google user
          data is never used for training machine learning models outside of the
          direct service.
        </p>
      </LegalSection>

      <LegalSection number={3} title="Information We Collect">
        <p>
          Trendexhub collects only the information necessary to operate the
          Trendit platform:
        </p>
        <LegalList
          items={[
            <>
              <strong>Google OAuth credentials</strong> — access tokens and
              refresh tokens that authorise Trendit to act on your behalf.
              Tokens are stored in encrypted environment variables and are never
              shared with third parties.
            </>,
            <>
              <strong>Google Business Profile data</strong> — your business
              name, address, phone number, category, hours of operation, service
              list, posts, photos, and customer reviews retrieved via the Google
              Business Profile API.
            </>,
            <>
              <strong>Google Ads data</strong> — campaign names, impression
              counts, click data, cost metrics, and performance summaries
              retrieved via the Google Ads API. This data is used solely to
              display advertising performance within your Trendit dashboard.
            </>,
            <>
              <strong>Review and Q&amp;A content</strong> — customer review
              text, star ratings, and questions retrieved from your Google
              Business Profile listing in order to generate automated responses
              on your behalf.
            </>,
            <>
              <strong>Performance insights</strong> — search impression counts,
              direction requests, phone call counts, and engagement metrics from
              Google Business Profile Insights.
            </>,
            <>
              <strong>Audit log data</strong> — a record of autonomous actions
              taken by the Trendit agent (posts published, replies sent, actions
              skipped, policy rejections), retained in a server-side ring buffer
              of approximately 500 entries for your review and cleared on each
              deployment.
            </>,
          ]}
        />
      </LegalSection>

      <LegalSection number={4} title="How We Use Your Information">
        <p>
          Information collected via Google APIs is used solely to provide the
          Trendit service as described below. No Google user data is used for
          any secondary purpose.
        </p>
        <LegalList
          items={[
            "Authenticating your account and maintaining a valid Google API session.",
            "Autonomously publishing daily business posts to your Google Business Profile.",
            "Drafting and submitting replies to 4-star and 5-star customer reviews on your behalf.",
            "Retrieving and displaying Google Business Profile performance data in your Trendit dashboard.",
            "Retrieving and displaying Google Ads campaign performance data in your Trendit dashboard.",
            "Logging all autonomous actions to an audit trail accessible only to you.",
            "Improving the accuracy of automatically generated content through direct service feedback (no data is shared externally for this purpose).",
          ]}
        />
      </LegalSection>

      <LegalSection number={5} title="Data Sharing and Third Parties">
        <p>
          Trendexhub does not sell, rent, or share your Google API data with any
          third party, except as required to operate the platform:
        </p>
        <LegalList
          items={[
            <>
              <strong>Google LLC</strong> — API calls are made directly to
              Google's servers. Your data is subject to{" "}
              <a
                className="text-accent underline"
                href="https://policies.google.com/privacy"
                target="_blank"
                rel="noreferrer"
              >
                Google's Privacy Policy
              </a>
              .
            </>,
            <>
              <strong>Google Gemini API</strong> — used solely to generate
              automated post drafts and review reply drafts. Prompts include
              anonymised business context (business name, category, tone). No
              customer personal data, no review author names, and no Google Ads
              financial data are included in prompts sent to Gemini.
            </>,
            <>
              <strong>Cloud infrastructure providers</strong> — used to host and
              operate the Trendit service. Data handling is limited to what is
              required to provide the service.
            </>,
          ]}
        />
        <p>
          We do not share Google user data with any advertising networks, data
          brokers, analytics platforms, or other third parties beyond those
          listed above.
        </p>
      </LegalSection>

      <LegalSection number={6} title="Data Storage and Security">
        <p>
          Trendit is deployed on cloud infrastructure with the following
          security measures in place:
        </p>
        <LegalList
          items={[
            "All API credentials and OAuth tokens are stored as encrypted environment variables — never in source code or logs.",
            "All communications between Trendit and Google APIs use HTTPS/TLS encryption.",
            "All Trendit API endpoints are protected by API key authentication: no endpoint is publicly accessible without a valid key.",
            "Business profile data retrieved from Google APIs is processed in-memory during each request and is not written to any persistent third-party database.",
            "Google Ads performance data is fetched on-demand and displayed in-session; it is not stored beyond the duration of the API response.",
            "The autonomous audit log is maintained as an in-memory ring buffer and is cleared on each redeployment.",
          ]}
        />
      </LegalSection>

      <LegalSection number={7} title="Data Retention and Deletion">
        <p>
          Trendexhub retains your API credentials and configuration for as long
          as your account is active. To request deletion of your data:
        </p>
        <LegalList
          items={[
            <>
              <strong>Revoke Google access</strong> — remove Trendit from your
              Google Account's authorised applications at{" "}
              <a
                className="text-accent underline"
                href="https://myaccount.google.com/permissions"
                target="_blank"
                rel="noreferrer"
              >
                myaccount.google.com/permissions
              </a>
              . This immediately invalidates all OAuth tokens and prevents any
              further API access.
            </>,
            <>
              <strong>Contact us</strong> — email{" "}
              <a
                className="text-accent underline"
                href="mailto:info@trendexhub.com"
              >
                info@trendexhub.com
              </a>{" "}
              to request removal of any stored configuration or credentials. We
              will process deletion requests within 30 days.
            </>,
          ]}
        />
      </LegalSection>

      <LegalSection number={8} title="Your Rights">
        <p>You have the right to:</p>
        <LegalList
          items={[
            "Access the configuration data Trendexhub holds about your business.",
            "Correct any inaccurate configuration information.",
            "Request deletion of your data at any time (see Section 7).",
            "Withdraw consent by revoking Google API access at any time — this will immediately stop all autonomous actions.",
            "Receive a copy of your audit log data.",
          ]}
        />
      </LegalSection>

      <LegalSection number={9} title="Children's Privacy">
        <p>
          Trendit is a business management tool for use by business owners and
          their authorised staff. It is not intended for use by individuals
          under the age of 18. Trendexhub does not knowingly collect personal
          data from minors.
        </p>
      </LegalSection>

      <LegalSection number={10} title="Changes to This Policy">
        <p>
          Trendexhub may update this Privacy Policy to reflect changes in our
          practices or applicable law. Material changes will be communicated by
          updating the "last updated" date at the top of this page. Continued
          use of Trendit following any change constitutes acceptance of the
          revised policy.
        </p>
      </LegalSection>

      <LegalSection number={11} title="Contact">
        <p>
          For any questions or concerns regarding this Privacy Policy or our
          data practices, please contact:
        </p>
        <div className="pt-2 text-sm">
          <div className="font-medium text-foreground">Trendexhub</div>
          <div className="text-muted-foreground">Uganda</div>
          <div>
            Email:{" "}
            <a
              className="text-accent underline"
              href="mailto:info@trendexhub.com"
            >
              info@trendexhub.com
            </a>
          </div>
          <div>
            Website:{" "}
            <a
              className="text-accent underline"
              href="https://www.trendexhub.com"
              target="_blank"
              rel="noreferrer"
            >
              www.trendexhub.com
            </a>
          </div>
        </div>
      </LegalSection>
    </LegalShell>
  );
}
