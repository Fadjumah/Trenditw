import { createFileRoute, useSearch } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ExternalLink,
  PlusCircle,
  Store,
  ShieldCheck,
  HelpCircle,
} from "lucide-react";
import { track } from "@/lib/analytics";
import { useEffect } from "react";
import { z } from "zod";
import { GoogleConnectButton } from "@/components/google-connect-button";
import { GbpSetupOfferCard } from "@/components/gbp-setup-offer-card";

const setupGbpSearchSchema = z.object({
  customer_id: z.string().optional(),
  location_id: z.string().optional(),
  email: z.string().optional(),
});

export const Route = createFileRoute("/setup-gbp")({
  validateSearch: setupGbpSearchSchema,
  head: () => ({
    meta: [
      { title: "Connect Google Business Profile — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: SetupGBP,
});

function SetupGBP() {
  const { customer_id, location_id, email } = useSearch({ from: "/setup-gbp" });

  useEffect(() => {
    track("setup_gbp_view", { user_id: customer_id || undefined });

    if (typeof window !== "undefined") {
      if (customer_id) localStorage.setItem("trendit_customer_id", customer_id);
      if (location_id) localStorage.setItem("trendit_location_id", location_id);
      if (email) localStorage.setItem("trendit_email", email);
    }
  }, [customer_id, location_id, email]);

  return (
    <div className="min-h-screen bg-background flex flex-col overflow-x-hidden">
      <SiteNav />
      <main className="flex-1 container-page py-8 sm:py-12 flex flex-col items-center justify-center">
        <div className="w-full max-w-4xl 2xl:max-w-5xl">
          <Card className="rounded-3xl border border-black/10 dark:border-white/15 bg-white dark:bg-[#201d19] shadow-none">
            <CardHeader className="p-5 sm:p-8 text-center">
              <div className="mx-auto mb-3 sm:mb-4 flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-full bg-accent/15 text-accent">
                <Store size={28} className="sm:hidden" />
                <Store size={32} className="hidden sm:block" />
              </div>
              <CardTitle className="font-serif text-2xl sm:text-3xl text-balance">
                We couldn't find a Google Business Profile
              </CardTitle>
              <CardDescription className="text-sm sm:text-lg mt-2 text-balance leading-relaxed">
                Your Google account connected successfully, but no eligible
                Business Profile was found. This usually means the profile is
                managed by a different Google account or has not been created
                yet.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center gap-6 sm:gap-8 p-5 sm:p-8 pt-0 pb-8 sm:pb-12">
              <div className="grid gap-4 sm:gap-6 md:grid-cols-2 w-full mt-2 sm:mt-4">
                <GbpSetupOfferCard source="setup_gbp_no_profile" />

                <div className="flex flex-col p-5 sm:p-6 rounded-2xl border border-black/10 dark:border-white/15 bg-card text-card-foreground shadow-none">
                  <div className="mb-3 sm:mb-4 h-9 w-9 sm:h-10 sm:w-10 rounded-full bg-accent/20 flex items-center justify-center text-accent">
                    <Store size={20} className="sm:hidden" />
                    <Store size={24} className="hidden sm:block" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-semibold mb-1.5 sm:mb-2">
                    I already have one
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground mb-4 sm:mb-6 flex-1 leading-relaxed">
                    Connect again with the Google account that owns or manages
                    your Business Profile. This will open Google's authorization
                    screen again.
                  </p>
                  <GoogleConnectButton
                    variant="outline"
                    source="setup_gbp_retry"
                    className="w-full text-xs sm:text-sm min-h-[40px] justify-center rounded-full"
                    forceReauth
                  >
                    Connect another Google account
                  </GoogleConnectButton>
                </div>
              </div>

              <div className="w-full max-w-xl rounded-2xl border border-black/10 dark:border-white/15 bg-card/60 p-5 sm:p-6 shadow-none">
                <div className="flex items-start gap-3 text-left">
                  <ShieldCheck
                    size={18}
                    className="mt-0.5 shrink-0 text-accent"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      Your Google account stays yours.
                    </p>
                    <p className="mt-1 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                      Trendit uses Google's authorization flow. We never ask for
                      your Google password, and you can revoke Trendit's access
                      from your Google Account at any time.
                    </p>
                  </div>
                </div>
                <div className="mt-4 flex items-start gap-3 text-left">
                  <HelpCircle
                    size={18}
                    className="mt-0.5 shrink-0 text-muted-foreground"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      Still can't find the profile?
                    </p>
                    <p className="mt-1 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                      Make sure the Google account you connect has Owner or
                      Manager access to the profile.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
