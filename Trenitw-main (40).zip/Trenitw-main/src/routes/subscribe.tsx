import { useState, useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { FreemiusCheckoutButton } from "@/components/checkout-button";
import { GoogleConnectButton } from "@/components/google-connect-button";
import { Button } from "@/components/ui/button";
import { useAuthState } from "@/hooks/use-auth-state";
import { apiFetch } from "@/lib/api";
import { PRICING_PLANS, getFreemiusPlanIdForTier } from "@/lib/pricing-plans";
import { Check, CheckCircle2, ShieldCheck, ArrowRight, LayoutDashboard } from "lucide-react";
import { z } from "zod";

const subscribeSearchSchema = z.object({
  customer_id: z.string().optional(),
  location_id: z.string().optional(),
  email: z.string().optional(),
});

export const Route = createFileRoute("/subscribe")({
  validateSearch: subscribeSearchSchema,
  head: () => ({
    meta: [
      { title: "Subscribe — Trendit" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: SubscribePage,
});

function SubscribePage() {
  const { customer_id, location_id, email } = Route.useSearch();
  const { isAuthenticated, customerId: authCustomerId } = useAuthState();
  const navigate = useNavigate();
  const [entitlement, setEntitlement] = useState<any>(null);

  const activeCustomerId = customer_id || authCustomerId || (typeof window !== "undefined" ? localStorage.getItem("trendit_customer_id") : null);
  const activeLocationId = location_id || (typeof window !== "undefined" ? localStorage.getItem("trendit_location_id") : null);
  const activeEmail = email || (typeof window !== "undefined" ? localStorage.getItem("trendit_email") : null);

  useEffect(() => {
    if (activeCustomerId) {
      apiFetch(`/api/user/entitlement/${activeCustomerId}`)
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => { if (data) setEntitlement(data); })
        .catch(() => null);
    }
  }, [activeCustomerId]);

  const handleSuccess = () => {
    navigate({ to: "/dashboard", search: { customer_id: activeCustomerId || undefined, location_id: activeLocationId || undefined, email: activeEmail || undefined } });
  };

  const hasActiveAccess = entitlement && entitlement.has_access && entitlement.plan !== "free";
  const hasFreeAccess = entitlement?.plan === "free";

  return (
    <div className="app-editorial subscribe-editorial min-h-screen bg-background text-foreground flex flex-col justify-between">
      <SiteNav />
      <main className="flex-1 max-w-7xl 2xl:max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-12 sm:py-16 w-full">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#b64b25]/20 bg-[#b64b25]/10 px-4 py-1.5 text-xs font-semibold text-[#b64b25] uppercase tracking-[0.16em]"><span>Launch Special · Limited-Time Pricing</span></div>
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl tracking-tight text-foreground">{hasActiveAccess ? "Your Trendit Subscription" : "Trendit Pro Subscription"}</h1>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">{hasActiveAccess ? "You have an active subscription with full access to all features." : "Start your 30-day free trial. Unlock autonomous Google Business Profile updates, scheduled publishing, and AI review replies."}</p>
        </div>

        {hasActiveAccess ? (
          <div className="max-w-xl mx-auto rounded-3xl border border-emerald-500/30 bg-emerald-500/10 p-7 sm:p-10 text-center space-y-4 shadow-none">
            <div className="flex items-center justify-center gap-2 text-emerald-700 dark:text-emerald-400 font-semibold text-base"><CheckCircle2 size={22} /><span>Your Plan is Active on your Account</span></div>
            <p className="text-sm text-muted-foreground leading-relaxed">Your subscription is active and in good standing. You do not need to subscribe again.</p>
            <Button onClick={() => navigate({ to: "/dashboard", search: { customer_id: activeCustomerId || undefined, location_id: activeLocationId || undefined, email: activeEmail || undefined } })} className="w-full justify-center rounded-full bg-foreground text-background hover:bg-foreground/90 py-3.5 text-sm font-semibold shadow-none"><LayoutDashboard className="mr-2 h-4 w-4" />Go to Dashboard</Button>
          </div>
        ) : (
          <div className="max-w-xl mx-auto">
            {PRICING_PLANS.map((plan) => {
              const isPopular = plan.popular;
              const isTrialPlan = plan.id === "pro" && plan.hasTrial;
              return (
                <div key={plan.id} className={`rounded-3xl p-7 sm:p-8 flex flex-col justify-between relative transition-all duration-200 border border-border/80 shadow-none bg-card ${isPopular ? "lg:-translate-y-2 shadow-md" : ""}`}>
                  {plan.badge && <div className="absolute -top-3.5 left-6"><span className="rounded-full bg-[#b64b25] px-3.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">{plan.badge}</span></div>}
                  <div>
                    <div className="pb-6 border-b border-border/60">
                      <h3 className="font-serif text-2xl font-bold text-foreground">{plan.name}</h3>
                      <p className="mt-1 text-xs text-muted-foreground leading-relaxed min-h-[34px]">{plan.description}</p>
                      <div className="mt-5 flex items-baseline gap-2.5">
                        <div className="flex items-baseline gap-1"><span className="text-xs font-sans font-bold uppercase tracking-wider text-muted-foreground">Was</span><del className="font-serif text-2xl sm:text-3xl font-extrabold text-red-600 dark:text-red-400 line-through decoration-red-500 decoration-[2.5px]">${plan.originalPrice}</del></div>
                        <span className="font-serif text-4xl sm:text-5xl font-bold text-foreground">${plan.price}</span>
                        <span className="text-xs font-semibold text-muted-foreground">{plan.period}</span>
                      </div>
                      {isTrialPlan && <p className="mt-3 text-sm font-semibold text-[#b64b25]">30 days free · then $29/month</p>}
                    </div>
                    <div className="py-6 space-y-3 text-xs sm:text-sm text-foreground/90">
                      <p className="font-bold text-xs uppercase tracking-wider text-muted-foreground">Included in {plan.name}:</p>
                      {plan.features.map((item) => <div key={item} className="flex items-start gap-3"><Check size={16} className="text-[#b64b25] shrink-0 mt-0.5" /><span className="leading-snug">{item}</span></div>)}
                    </div>
                  </div>
                  <div className="pt-4 border-t border-border/60 space-y-2">
                    {plan.id === "free" ? (
                      activeCustomerId || isAuthenticated ? (
                        <Button
                          onClick={() => navigate({ to: "/dashboard", search: { customer_id: activeCustomerId || undefined, location_id: activeLocationId || undefined, email: activeEmail || undefined } })}
                          className="w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none bg-foreground text-background hover:bg-foreground/90"
                        >
                          <span>{hasFreeAccess ? "Go to Free Dashboard" : "Start Free"}</span>
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      ) : (
                        <GoogleConnectButton source="subscribe_free" variant="default" className="w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none bg-foreground text-background hover:bg-foreground/90">
                          <span>Connect & Start Free</span>
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </GoogleConnectButton>
                      )
                    ) : activeCustomerId || isAuthenticated ? (
                      <FreemiusCheckoutButton
                        service="core"
                        planId={getFreemiusPlanIdForTier(plan)}
                        billingCycle="monthly"
                        trial={!!isTrialPlan}
                        successPath="/dashboard"
                        onSuccess={handleSuccess}
                        className={`w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none ${isPopular ? "bg-[#b64b25] text-white hover:bg-[#a03f1d]" : "bg-foreground text-background hover:bg-foreground/90"}`}
                      >
                        {isTrialPlan ? "Start 30-Day Free Trial" : plan.ctaText}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </FreemiusCheckoutButton>
                    ) : (
                      <GoogleConnectButton source={`subscribe_${plan.id}`} variant="default" className={`w-full justify-center rounded-full py-3.5 text-sm font-semibold min-h-[48px] shadow-none ${isPopular ? "bg-[#b64b25] text-white hover:bg-[#a03f1d]" : "bg-foreground text-background hover:bg-foreground/90"}`}>
                        <span>{isTrialPlan ? "Connect & Start 30-Day Trial" : `Connect & Start ${plan.name}`}</span>
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </GoogleConnectButton>
                    )}                  </div>
                </div>
              );
            })}
          </div>
        )}
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mt-12"><ShieldCheck className="h-4 w-4 text-primary" /><span>Secure 256-bit encrypted checkout powered by Freemius.</span></div>
      </main>
      <SiteFooter />
    </div>
  );
}
