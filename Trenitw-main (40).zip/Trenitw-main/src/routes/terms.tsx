import { createFileRoute } from "@tanstack/react-router";
import {
  Callout,
  LegalList,
  LegalSection,
  LegalShell,
} from "@/components/legal-shell";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildJsonLdScript,
  SITE_URL,
} from "@/lib/seo";

const termsSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildWebPageSchema({
    title: "Terms of Service — Trendit by Trendexhub",
    description:
      "The terms governing access to and use of the Trendit platform, operated by Trendexhub.",
    url: `${SITE_URL}/terms`,
    pageType: "WebPage",
  }),
];

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: createPageMeta({
      title: "Terms of Service — Trendit by Trendexhub",
      description:
        "The terms governing access to and use of the Trendit platform, operated by Trendexhub.",
      canonicalPath: "/terms",
      keywords: [
        "Trendit terms of service",
        "Trendexhub terms",
        "Google API user data policy terms",
      ],
    }),
    links: [createCanonicalLink("/terms")],
    scripts: [buildJsonLdScript(termsSchemaEntities)],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <LegalShell
      title="Terms of Service"
      effective="26 April 2026"
      updated="26 April 2026"
    >
      <LegalSection number={1} title="Acceptance of Terms">
        <p>
          These Terms of Service govern your access to and use of the Trendit
          platform, operated by Trendexhub, a software company based in Uganda.
          By accessing or using Trendit, you agree to be bound by these Terms.
          If you do not agree, you may not use the platform. For questions,
          contact us at{" "}
          <a
            className="text-accent underline"
            href="mailto:info@trendexhub.com"
          >
            info@trendexhub.com
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection number={2} title="Description of Service">
        <p>
          Trendit is an autonomous business management platform that connects to
          Google APIs on behalf of business owners to help them maintain an
          active, policy-compliant online presence. The platform currently
          provides:
        </p>
        <LegalList
          items={[
            <>
              <strong>Google Business Profile management</strong> — publishing
              daily content posts, drafting and submitting replies to customer
              reviews, answering customer questions, managing photos and media,
              and updating business information including hours and services.
            </>,
            <>
              <strong>Google Ads performance monitoring</strong> — reading
              campaign performance data, impression counts, click metrics, and
              ad spend summaries to surface advertising insights within the
              Trendit dashboard. Trendit reads advertising data but does not
              autonomously create, pause, or delete campaigns.
            </>,
            <>
              <strong>automated content generation</strong> — using the Google
              Gemini API to draft business posts and review replies, subject to
              a built-in policy validation layer before any content is
              published.
            </>,
            <>
              <strong>Audit and oversight tools</strong> — a complete log of all
              autonomous actions taken by the platform, accessible to the
              account holder at any time.
            </>,
          ]}
        />
      </LegalSection>

      <LegalSection number={3} title="Google API Authorisation">
        <p>
          To use Trendit, you must authorise the platform to access your Google
          Account via OAuth 2.0. By granting this authorisation, you confirm
          that:
        </p>
        <LegalList
          items={[
            "You are the authorised owner or manager of the Google Business Profile and/or Google Ads account being connected.",
            "You grant Trendit permission to access, read, and act on the Google services you explicitly authorise.",
            <>
              Trendit's use of your Google data complies with the{" "}
              <a
                className="text-accent underline"
                href="https://developers.google.com/terms/api-services-user-data-policy"
                target="_blank"
                rel="noreferrer"
              >
                Google API Services User Data Policy
              </a>
              , including Limited Use requirements.
            </>,
            <>
              You may revoke this authorisation at any time via your Google
              Account settings at{" "}
              <a
                className="text-accent underline"
                href="https://myaccount.google.com/permissions"
                target="_blank"
                rel="noreferrer"
              >
                myaccount.google.com/permissions
              </a>
              .
            </>,
          ]}
        />
      </LegalSection>

      <LegalSection number={4} title="Acceptable Use">
        <p>
          You agree to use Trendit only for lawful business management purposes.
          You may not use the platform to:
        </p>
        <LegalList
          items={[
            "Publish content that violates Google Business Profile policies or Google Ads policies.",
            "Publish false, misleading, or deceptive information about your business.",
            "Circumvent Google's rate limits, terms of service, or content policies.",
            "Access or attempt to access any Google account or resource you are not authorised to manage.",
            "Reverse-engineer, resell, or redistribute the Trendit platform or its API integrations.",
          ]}
        />
      </LegalSection>

      <LegalSection number={5} title="User Responsibilities">
        <p>You remain solely responsible for:</p>
        <LegalList
          items={[
            "Maintaining the security of your API credentials and access keys used to authenticate with Trendit.",
            "Reviewing the autonomous actions taken by Trendit via the audit log, and promptly correcting any content that does not meet your standards.",
            "Ensuring your Google Business Profile information (address, hours, services) is accurate before enabling autonomous posting.",
            "Compliance with all applicable laws and regulations relating to your business's advertising and public communications.",
            <>
              Notifying Trendexhub promptly at{" "}
              <a
                className="text-accent underline"
                href="mailto:info@trendexhub.com"
              >
                info@trendexhub.com
              </a>{" "}
              of any unauthorised access to your Trendit account.
            </>,
          ]}
        />
      </LegalSection>

      <LegalSection number={6} title="Autonomous Agent Safeguards">
        <p>
          Trendit's autonomous features operate under strict built-in policy
          controls designed to protect your business reputation and comply with
          Google's content policies:
        </p>
        <LegalList
          items={[
            "Every automatically generated post and review reply passes through a policy validation layer before publication — blocking medical claims, guarantees, foreign URLs, phone numbers, email addresses, hashtags, emojis, and banned terminology.",
            "Auto-replies are sent only to 4-star and 5-star reviews; all reviews rated 3 stars or below are flagged for human review and never auto-answered.",
            "A maximum of one post is published per day to prevent content spam.",
            "If all generation attempts for a post or reply fail policy validation, nothing is published and the failure is recorded in the audit log.",
            "All autonomous actions can be disabled immediately via environment variable kill switches, without requiring a code change.",
          ]}
        />
        <p>
          While these safeguards are designed to protect you, you remain
          responsible for reviewing the audit log and taking corrective action
          if needed. Trendexhub is not liable for content published as a result
          of incorrect business information provided by you.
        </p>
      </LegalSection>

      <LegalSection
        number={7}
        title="Google Ads — Scope of Access and Financial Responsibility"
      >
        <Callout>
          <strong>Important:</strong> Trendit accesses your Google Ads account
          in read-only mode to retrieve campaign performance data for display in
          your dashboard. Trendexhub does not control your advertising budget,
          bidding, or campaign settings. All advertising costs — including
          cost-per-click, impressions, and total ad spend — are your sole
          financial responsibility and are managed directly in your Google Ads
          account. Trendexhub is not responsible for any ad spend, budget
          overruns, or billing charges on your Google Ads account.
        </Callout>
      </LegalSection>

      <LegalSection number={8} title="Intellectual Property">
        <p>
          The Trendit platform, including its source code, design, autonomous
          agent logic, and policy engine, is proprietary to Trendexhub. You are
          granted a limited, non-exclusive, non-transferable licence to use the
          service for your own business management purposes.
        </p>
        <p>
          automatically generated content (posts, review replies) produced by
          Trendit and published to your Google Business Profile is published
          under your account and is your property. You are responsible for that
          content once it is published.
        </p>
      </LegalSection>

      <LegalSection number={9} title="Disclaimer of Warranties">
        <p>
          The Trendit platform is provided "as is" and "as available" without
          warranties of any kind. Trendexhub does not warrant that:
        </p>
        <LegalList
          items={[
            "The service will be uninterrupted, error-, or free from data loss.",
            "automatically generated content will always be accurate, complete, or appropriate for your specific business context.",
            "Changes to Google APIs will not affect service functionality.",
            "Autonomous actions will always produce the desired business outcome.",
            "Google Ads data retrieved will be real-time accurate at all moments.",
          ]}
        />
      </LegalSection>

      <LegalSection number={10} title="Limitation of Liability">
        <p>
          To the maximum extent permitted by applicable law, Trendexhub shall
          not be liable for any indirect, incidental, special, or consequential
          damages arising from your use of Trendit, including but not limited
          to: lost revenue, reputational harm caused by published content, or ad
          spend on your Google Ads account. Trendexhub's total liability for any
          claim arising from use of the service shall not exceed the fees paid
          by you to Trendexhub in the three months preceding the claim.
        </p>
      </LegalSection>

      <LegalSection number={11} title="Termination">
        <p>
          You may stop using Trendit at any time by revoking Google API access
          at{" "}
          <a
            className="text-accent underline"
            href="https://myaccount.google.com/permissions"
            target="_blank"
            rel="noreferrer"
          >
            myaccount.google.com/permissions
          </a>{" "}
          and discontinuing use of the platform. Trendexhub reserves the right
          to suspend or terminate access to the service if you have violated
          these Terms, violated Google's API policies, or engaged in conduct
          that may harm Trendexhub or its users.
        </p>
        <p>Upon termination, Sections 7, 8, 9, 10, and 12 survive.</p>
      </LegalSection>

      <LegalSection number={12} title="Governing Law">
        <p>
          These Terms are governed by the laws of the Republic of Uganda. Any
          disputes arising from these Terms or your use of Trendit shall be
          subject to the exclusive jurisdiction of the courts of Uganda.
        </p>
      </LegalSection>

      <LegalSection number={13} title="Changes to These Terms">
        <p>
          Trendexhub may modify these Terms at any time by posting the revised
          version on this page with an updated effective date. Your continued
          use of the service after any changes constitutes acceptance of the
          revised Terms.
        </p>
      </LegalSection>

      <LegalSection number={14} title="Contact">
        <p>
          For questions about these Terms or the Trendit platform, please
          contact:
        </p>
        <div className="pt-2 text-sm">
          <div className="font-medium text-foreground">Trendexhub</div>
          <div className="text-muted-foreground">Uganda</div>
          <div>
            Email:{" "}
            <a
              className="text-accent underline"
              href="mailto:info@trendexhub.com"
            >
              info@trendexhub.com
            </a>
          </div>
          <div>
            Website:{" "}
            <a
              className="text-accent underline"
              href="https://www.trendexhub.com"
              target="_blank"
              rel="noreferrer"
            >
              www.trendexhub.com
            </a>
          </div>
        </div>
      </LegalSection>
    </LegalShell>
  );
}
