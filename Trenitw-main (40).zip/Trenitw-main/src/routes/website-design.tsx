import { createFileRoute, useSearch } from "@tanstack/react-router";
import React from "react";
import { z } from "zod";
import { SiteNav } from "@/components/site-nav";
import { SiteFooter } from "@/components/site-footer";
import { PublicVisualStrip } from "@/components/public-visual-strip";
import { ContactCtaBanner } from "@/components/contact-cta-banner";
import { FreemiusCheckoutButton } from "@/components/checkout-button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  CheckCircle2,
  Smartphone,
  Search,
  PhoneCall,
  Sparkles,
  Phone,
  ArrowRight,
} from "lucide-react";
import { WhatsAppIcon } from "@/components/social-icons";
import {
  WEBSITE_DESIGN_TIERS,
  WEBSITE_DESIGN_TURNAROUND,
  getWebsiteDesignPlanId,
  getWebsiteDesignPricingId,
} from "@/lib/website-design-offer";
import {
  createPageMeta,
  createCanonicalLink,
  buildOrganizationSchema,
  buildWebSiteSchema,
  buildWebPageSchema,
  buildFAQSchema,
  buildJsonLdScript,
  SITE_URL,
  CONTACT_PHONE_1,
  CONTACT_PHONE_1_RAW,
  WHATSAPP_LINK,
  WHATSAPP_NUMBER,
} from "@/lib/seo";
import { track } from "@/lib/analytics";

const WEBSITE_DESIGN_FAQS = [
  {
    q: "Do you design websites for businesses outside Entebbe?",
    a: "Yes — we're based in Entebbe, Uganda and work with local businesses in person or entirely remotely, plus businesses anywhere else online. Everything can be handled over phone, WhatsApp, and email.",
  },
  {
    q: "How long does a website take?",
    a: "A Starter Site is typically ready in 3–5 business days. A Business Site takes 5–8 business days, depending on how quickly we get your content and photos.",
  },
  {
    q: "What do I need to provide?",
    a: "Just your business details, logo (if you have one), a few photos, and your contact information. If you don't have professional photos yet, we can guide you on what to send from your phone.",
  },
  {
    q: "Will my website show up on Google?",
    a: "We build every site with basic on-page SEO — proper titles, descriptions and mobile-friendliness. The Business Site package includes additional local SEO setup, and pairs perfectly with our Google Business Profile service.",
  },
  {
    q: "Do you offer ongoing support after the site is live?",
    a: "Yes. Reach out any time by phone, WhatsApp or email for updates and support — we're a local team, not a faceless agency.",
  },
];

const websiteDesignSchemaEntities = [
  buildOrganizationSchema(),
  buildWebSiteSchema(),
  buildWebPageSchema({
    title:
      "Website Design in Entebbe, Uganda — Affordable Business Websites | Trendit",
    description:
      "Professional, mobile-friendly website design for small businesses in Entebbe and across Uganda. Get a website that brings in calls — starting at $149.",
    url: `${SITE_URL}/website-design`,
  }),
  buildFAQSchema(WEBSITE_DESIGN_FAQS),
  {
    "@type": "Service",
    serviceType: "Website Design",
    name: "Trendit Website Design",
    provider: { "@id": `${SITE_URL}/#organization` },
    areaServed: [
      { "@type": "City", name: "Entebbe" },
      { "@type": "Country", name: "Uganda" },
    ],
    description:
      "Done-for-you website design for small and growing businesses — mobile-friendly, fast, and built to get you found on Google.",
    offers: WEBSITE_DESIGN_TIERS.map((tier) => ({
      "@type": "Offer",
      name: tier.name,
      price: String(tier.price),
      priceCurrency: "USD",
    })),
  },
];

const websiteDesignSearchSchema = z.object({
  ordered: z.string().optional(),
  tier: z.string().optional(),
});

export const Route = createFileRoute("/website-design")({
  validateSearch: websiteDesignSearchSchema,
  head: () => ({
    meta: createPageMeta({
      title:
        "Website Design in Entebbe, Uganda — Affordable Business Websites | Trendit",
      description:
        "Professional, mobile-friendly website design for small businesses in Entebbe and across Uganda. Get a website that brings in calls — starting at $149. Call or WhatsApp us today.",
      canonicalPath: "/website-design",
      keywords: [
        "website design Entebbe",
        "web designer Uganda",
        "affordable website design Uganda",
        "small business website Entebbe",
        "website design company Entebbe",
        "professional website Uganda",
        "web design near me",
      ],
    }),
    links: [createCanonicalLink("/website-design")],
    scripts: [buildJsonLdScript(websiteDesignSchemaEntities)],
  }),
  component: WebsiteDesignPage,
});

function WebsiteDesignPage() {
  const { ordered, tier } = useSearch({ from: "/website-design" });

  return (
    <div className="min-h-screen bg-[#f7f3eb] text-[#171512] flex flex-col overflow-x-hidden">
      <SiteNav />
      <main className="flex-1">
        {ordered === "1" && (
          <div className="bg-emerald-600 text-white px-5 py-4 text-center text-sm font-semibold flex items-center justify-center gap-2">
            <CheckCircle2 size={18} className="shrink-0" />
            <span>
              Payment received! We're preparing your {tier === "business" ? "Business Site" : "Starter Site"} project. We'll reach out to your email shortly to collect your details.
            </span>
          </div>
        )}
        <HeroSection />
        <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
          { src: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=82", alt: "A polished website on a laptop", eyebrow: "Web design", title: "A clearer digital front door" },
          { src: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=82", alt: "A business website and analytics view", eyebrow: "Performance", title: "Designed to support discovery" },
          { src: "https://images.unsplash.com/photo-1559028012-481c04fa702d?auto=format&fit=crop&w=1200&q=82", alt: "A local business welcoming customers", eyebrow: "Business", title: "A website that reflects the real business" },
        ]} />
        <WhyItMattersSection />
        <PricingSection />
        <ConsultationSection />
        <FAQSection />
      </main>
      <SiteFooter />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="dark-surface bg-[#171512] px-5 py-16 sm:px-8 lg:px-12 xl:px-16 lg:py-24 text-white">
      <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/10 text-[#f3a37f] px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em]">
              <Sparkles size={14} /> Website design, done for you
            </div>
            <h1 className="font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl xl:text-[76px] text-white">
              A website that actually brings you customers
            </h1>
            <p className="text-lg sm:text-xl leading-8 text-white/70 max-w-2xl">
              We design fast, mobile-friendly websites for small businesses in
              Entebbe and across Uganda — built to make people call you, not
              just look nice.
            </p>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <a
                href={`tel:${CONTACT_PHONE_1_RAW}`}
                onClick={() => track("website_design_call_click", { source: "hero" })}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#b64b25] px-8 text-sm font-semibold text-white shadow-none hover:bg-[#a03f1d] transition-colors"
              >
                <Phone size={17} />
                Call {CONTACT_PHONE_1}
              </a>
              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => track("website_design_whatsapp_click", { source: "hero" })}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#25D366] px-8 text-sm font-semibold text-white shadow-none hover:bg-[#20bd5a] transition-colors"
              >
                <WhatsAppIcon className="h-[17px] w-[17px]" />
                WhatsApp Us
              </a>
            </div>
            <p className="text-xs text-white/50">
              Starting at ${WEBSITE_DESIGN_TIERS[0].price} one-time ·{" "}
              {WEBSITE_DESIGN_TURNAROUND}
            </p>
          </div>

          {/* Right Column: Live Website Mockup Preview Card */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl border border-white/15 bg-[#201d19] p-6 sm:p-8 space-y-5 text-left shadow-2xl">
              <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div className="flex items-center gap-2">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Conversion-Ready</span>
                </div>
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/10 text-white/70 font-mono">Mobile + Google</span>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold uppercase tracking-wider text-[#f3a37f]">Local Business Website</div>
                <div className="font-serif text-2xl font-bold text-white">Your Business Online</div>
                <p className="text-xs text-white/60 leading-relaxed">
                  Fast loading speed, mobile responsive design, instant WhatsApp &amp; click-to-call buttons, and Google Map directions.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-white/80 pt-2">
                <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                  <Smartphone size={14} className="text-[#f3a37f] shrink-0" />
                  <span className="truncate">100% Mobile Ready</span>
                </div>
                <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                  <Search size={14} className="text-blue-400 shrink-0" />
                  <span className="truncate">Local SEO Tagging</span>
                </div>
                <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                  <PhoneCall size={14} className="text-emerald-400 shrink-0" />
                  <span className="truncate">Instant Calling</span>
                </div>
                <div className="rounded-xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-2">
                  <Sparkles size={14} className="text-amber-400 shrink-0" />
                  <span className="truncate">3–5 Day Delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhyItMattersSection() {
  const items = [
    {
      icon: Smartphone,
      title: "Looks great on any phone",
      body: "Most of your customers are searching on their phone — your site needs to work perfectly there, not just on a desktop.",
    },
    {
      icon: Search,
      title: "Built to be found on Google",
      body: "Every site we build starts with the SEO basics done right, so search engines can actually find and rank your business.",
    },
    {
      icon: PhoneCall,
      title: "Designed to get the call",
      body: "Click-to-call and WhatsApp buttons are built into every page — we design for the action you actually want: the phone ringing.",
    },
  ];
  return (
    <section className="border-y border-black/10 bg-white/45 px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
      <div className="mx-auto grid gap-6 sm:grid-cols-3 max-w-7xl 2xl:max-w-[1440px]">
        {items.map(({ icon: Icon, title, body }) => (
          <div
            key={title}
            className="rounded-3xl border border-black/10 bg-white p-8 text-center shadow-none space-y-2"
          >
            <Icon className="mx-auto mb-4 text-[#b64b25]" size={30} />
            <h3 className="font-serif text-2xl text-[#171512] mb-2">
              {title}
            </h3>
            <p className="text-sm leading-7 text-black/60">{body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function PricingSection() {
  return (
    <section
      id="pricing"
      className="bg-[#f7f3eb] px-5 py-20 sm:px-8 lg:px-12 xl:px-16 border-b border-black/10"
    >
      <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
        <div className="text-center mb-12 sm:mb-16 max-w-3xl mx-auto">
          <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
            Pricing
          </p>
          <h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl lg:text-6xl text-[#171512]">
            Simple, honest pricing
          </h2>
          <p className="mt-4 text-base sm:text-lg text-black/65 max-w-md mx-auto">
            One-time payment. No hidden fees, no monthly surprises.
          </p>
        </div>
        <div className="grid gap-8 sm:grid-cols-2 max-w-5xl 2xl:max-w-6xl mx-auto items-stretch">
          {WEBSITE_DESIGN_TIERS.map((tier) => (
            <div
              key={tier.id}
              className={`rounded-3xl p-7 sm:p-9 shadow-none ${
                tier.highlighted
                  ? "border-2 border-[#b64b25] bg-white relative"
                  : "border border-black/10 bg-white"
              }`}
            >
              {tier.highlighted && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-[#b64b25] px-3.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
                  Most popular
                </span>
              )}
              <h3 className="font-serif text-2xl text-[#171512] mb-1">
                {tier.name}
              </h3>
              <p className="text-sm text-black/60 mb-5">{tier.tagline}</p>
              <div className="flex items-baseline gap-2 mb-1">
                <span className="font-serif text-4xl sm:text-5xl font-bold text-[#171512]">
                  ${tier.price}
                </span>
                <span className="text-sm text-black/40 line-through">
                  ${tier.originalPrice}
                </span>
              </div>
              <p className="text-xs text-black/50 mb-6">
                one-time · {tier.bestFor}
              </p>
              <ul className="space-y-3 mb-8">
                {tier.features.map((f) => (
                  <li
                    key={f}
                    className="flex items-start gap-3 text-sm text-black/75"
                  >
                    <CheckCircle2
                      size={16}
                      className="mt-0.5 shrink-0 text-[#b64b25]"
                    />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <FreemiusCheckoutButton
                service="website_design"
                planId={getWebsiteDesignPlanId(tier.id)}
                pricingId={getWebsiteDesignPricingId(tier.id)}
                allowGuest
                successPath={`/website-design?ordered=1&tier=${tier.id}`}
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-[#b64b25] px-6 text-sm font-semibold text-white shadow-none hover:bg-[#a03f1d] cursor-pointer transition-colors"
              >
                <span>{tier.ctaText}</span>
                <ArrowRight size={15} />
              </FreemiusCheckoutButton>

              <div className="flex items-center justify-center gap-3 pt-3 text-xs text-black/50">
                <a
                  href={`tel:${CONTACT_PHONE_1_RAW}`}
                  onClick={() => track("website_design_call_click", { source: `pricing_sub_${tier.id}` })}
                  className="hover:text-black hover:underline flex items-center gap-1"
                >
                  <Phone size={12} /> Call us
                </a>
                <span>·</span>
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => track("website_design_whatsapp_click", { source: `pricing_sub_${tier.id}` })}
                  className="hover:text-emerald-600 hover:underline flex items-center gap-1 text-emerald-600"
                >
                  <WhatsAppIcon className="h-3 w-3" /> WhatsApp us
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ConsultationSection() {
  return (
    <section id="consultation" className="px-5 py-16 sm:px-8 lg:px-12 xl:px-16 border-t border-black/10 bg-white/30">
      <div className="mx-auto max-w-4xl 2xl:max-w-5xl text-center space-y-6">
        <div className="inline-flex items-center gap-2 rounded-full bg-[#b64b25]/10 px-3.5 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
          Direct Local Consultation
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#171512] leading-tight max-w-2xl mx-auto">
          Have questions before ordering? Talk to us today.
        </h2>
        <p className="text-base sm:text-lg leading-8 text-black/65 max-w-2xl mx-auto">
          Call or WhatsApp us now and tell us about your business — most calls take less than 5 minutes. We will give you a clear roadmap, content checklist, and timeline. Or choose your package above to get started immediately.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 max-w-lg mx-auto">
          <a
            href={`tel:${CONTACT_PHONE_1_RAW}`}
            onClick={() => track("website_design_call_click", { source: "contact_section" })}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-7 py-3.5 rounded-full bg-white border border-black/15 hover:border-black/30 transition-all text-sm font-semibold text-[#171512] shadow-sm"
          >
            <Phone size={18} className="text-[#b64b25]" />
            <span>Call {CONTACT_PHONE_1}</span>
          </a>

          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => track("website_design_whatsapp_click", { source: "contact_section" })}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-7 py-3.5 rounded-full bg-emerald-600 hover:bg-emerald-700 transition-all text-sm font-semibold text-white shadow-sm"
          >
            <WhatsAppIcon className="h-4 w-4" />
            <span>WhatsApp {WHATSAPP_NUMBER}</span>
          </a>
        </div>
      </div>
    </section>
  );
}

function FAQSection() {
  return (
    <>
      <section className="border-t border-black/10 bg-white/45 px-5 py-20 sm:px-8 lg:px-12 xl:px-16">
        <div className="mx-auto max-w-7xl 2xl:max-w-[1440px]">
          <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
            <div className="lg:col-span-5 space-y-4 lg:sticky lg:top-28 text-left">
              <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[#b64b25]">
                FAQ
              </p>
              <h2 className="font-serif text-4xl sm:text-5xl text-[#171512] leading-tight">
                Frequently asked questions
              </h2>
              <p className="text-base text-black/65 leading-relaxed">
                Find answers to questions about turnarounds, hosting, content requirements, and ongoing support.
              </p>
            </div>

            <div className="lg:col-span-7">
              <Accordion type="single" collapsible className="w-full space-y-4">
                {WEBSITE_DESIGN_FAQS.map((faq, i) => (
                  <AccordionItem
                    key={faq.q}
                    value={`faq-${i}`}
                    className="rounded-3xl border border-black/10 bg-white px-6 py-2 shadow-none"
                  >
                    <AccordionTrigger className="font-serif text-lg font-semibold text-[#171512] hover:no-underline text-left py-4">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm leading-7 text-black/65 pb-4">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </div>
      </section>

      <PublicVisualStrip className="py-8 sm:py-10 lg:py-12" items={[
        { src: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=82", alt: "A laptop showing a modern website", eyebrow: "Digital presence", title: "Make a strong first impression" },
        { src: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=82", alt: "A bright modern office", eyebrow: "Experience", title: "A website should feel easy to use" },
        { src: "https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=1200&q=82", alt: "A designer working on a website", eyebrow: "Craft", title: "Designed around your real business" },
      ]} />
    </>
  );
}
