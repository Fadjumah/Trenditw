import crypto from "crypto";
import { freemius, IS_SANDBOX } from "./client";
import type { CheckoutRedirectInfo } from "@freemius/sdk";
import { syncEntitlementByLicenseId } from "./entitlement";

export type CheckoutUser = {
  email: string;
  firstName?: string;
  lastName?: string;
};

export interface FreemiusCheckoutConfig {
  product_id: string;
  plan_id: string;
  pricing_id?: string;
  public_key: string;
  image?: string;
  is_sandbox: boolean;
  trial?: boolean;
  sandbox?: {
    token: string;
    ctx: string;
  } | null;
}

export function generateSandboxToken(
  productId: string,
  secretKey: string,
  publicKey: string,
): { token: string; ctx: string } {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const raw = timestamp + productId + secretKey + publicKey + "checkout";
  const token = crypto.createHash("md5").update(raw).digest("hex");
  return {
    token,
    ctx: timestamp,
  };
}

export function getCheckoutConfig(
  planIdOverride?: string | number,
  productOverride?: string,
): FreemiusCheckoutConfig {
  const reqPlan = (planIdOverride ? String(planIdOverride) : "").trim();
  const reqProd = (productOverride || "").trim().toLowerCase();

  const isGrowthProgram =
    reqProd === "growth_program" ||
    reqProd === "growth-program" ||
    reqProd === (process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRODUCT_ID || "39637") ||
    reqPlan === (process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PLAN_ID || "68083");

  const isGbpSetup =
    reqProd === "gbp_setup" ||
    reqProd === "gbp-setup" ||
    reqPlan === (process.env.VITE_FREEMIUS_GBP_SETUP_PLAN_ID || "65081");

  if (isGrowthProgram) {
    const productId =
      process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRODUCT_ID ||
      process.env.FREEMIUS_GROWTH_PROGRAM_PRODUCT_ID ||
      "39637";
    const publicKey =
      process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PUBLIC_KEY ||
      process.env.FREEMIUS_GROWTH_PROGRAM_PUBLIC_KEY ||
      "pk_2e959d49f4d948eba6254d5cb101a";
    const secretKey =
      process.env.FREEMIUS_GROWTH_PROGRAM_SECRET_KEY || "";
    const planId =
      reqPlan ||
      process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PLAN_ID ||
      process.env.FREEMIUS_GROWTH_PROGRAM_PLAN_ID ||
      "68083";
    const pricingId =
      process.env.VITE_FREEMIUS_GROWTH_PROGRAM_PRICING_ID ||
      process.env.FREEMIUS_GROWTH_PROGRAM_PRICING_ID ||
      "89986";
    const isSandbox =
      process.env.FREEMIUS_SANDBOX === "true" ||
      process.env.VITE_FREEMIUS_SANDBOX === "true" ||
      IS_SANDBOX;

    let sandbox: { token: string; ctx: string } | null = null;
    if (isSandbox && secretKey) {
      sandbox = generateSandboxToken(productId, secretKey, publicKey);
    }

    return {
      product_id: productId,
      plan_id: planId,
      pricing_id: pricingId,
      public_key: publicKey,
      image: "https://trendexhub.com/favicon.png?v=2",
      is_sandbox: isSandbox,
      sandbox,
      trial: true,
    };
  }

  if (isGbpSetup) {
    const productId =
      process.env.VITE_FREEMIUS_GBP_SETUP_PRODUCT_ID ||
      process.env.FREEMIUS_GBP_SETUP_PRODUCT_ID ||
      process.env.FREEMIUS_PRODUCT_ID ||
      process.env.VITE_FREEMIUS_PRODUCT_ID ||
      "37245";
    const publicKey =
      process.env.VITE_FREEMIUS_GBP_SETUP_PUBLIC_KEY ||
      process.env.FREEMIUS_GBP_SETUP_PUBLIC_KEY ||
      process.env.FREEMIUS_PUBLIC_KEY ||
      process.env.VITE_FREEMIUS_PUBLIC_KEY ||
      "pk_40c56495e18eb307b90c34e86e552";
    const secretKey = process.env.FREEMIUS_SECRET_KEY || "";
    const planId =
      reqPlan ||
      process.env.VITE_FREEMIUS_GBP_SETUP_PLAN_ID ||
      process.env.FREEMIUS_GBP_SETUP_PLAN_ID ||
      "65081";
    const pricingId =
      process.env.VITE_FREEMIUS_GBP_SETUP_PRICING_ID ||
      process.env.FREEMIUS_GBP_SETUP_PRICING_ID ||
      "86491";
    const isSandbox =
      process.env.FREEMIUS_SANDBOX === "true" ||
      process.env.VITE_FREEMIUS_SANDBOX === "true" ||
      IS_SANDBOX;

    let sandbox: { token: string; ctx: string } | null = null;
    if (isSandbox && secretKey) {
      sandbox = generateSandboxToken(productId, secretKey, publicKey);
    }

    return {
      product_id: productId,
      plan_id: planId,
      pricing_id: pricingId,
      public_key: publicKey,
      image: "https://trendexhub.com/favicon.png?v=2",
      is_sandbox: isSandbox,
      sandbox,
      trial: false,
    };
  }

  // Core Subscription
  const productId =
    process.env.FREEMIUS_PRODUCT_ID ||
    process.env.VITE_FREEMIUS_PRODUCT_ID ||
    "37245";
  const publicKey =
    process.env.FREEMIUS_PUBLIC_KEY ||
    process.env.VITE_FREEMIUS_PUBLIC_KEY ||
    "pk_40c56495e18eb307b90c34e86e552";
  const secretKey = process.env.FREEMIUS_SECRET_KEY || "";
  const planId =
    reqPlan ||
    process.env.FREEMIUS_GROWTH_PLAN_ID ||
    process.env.VITE_FREEMIUS_GROWTH_PLAN_ID ||
    "62230";
  const pricingId =
    process.env.FREEMIUS_GROWTH_PRICING_ID ||
    process.env.VITE_FREEMIUS_GROWTH_PRICING_ID ||
    "83073";
  const isSandbox =
    process.env.FREEMIUS_SANDBOX === "true" ||
    process.env.VITE_FREEMIUS_SANDBOX === "true" ||
    IS_SANDBOX;

  let sandbox: { token: string; ctx: string } | null = null;
  if (isSandbox && secretKey) {
    sandbox = generateSandboxToken(productId, secretKey, publicKey);
  }

  return {
    product_id: productId,
    plan_id: planId,
    pricing_id: pricingId,
    public_key: publicKey,
    image: "https://trendexhub.com/favicon.png?v=2",
    is_sandbox: isSandbox,
    sandbox,
    trial: false,
  };
}

export async function createCheckout(user: CheckoutUser, planId?: string) {
  const checkout = await freemius.checkout.create({
    user,
    planId,
    isSandbox: IS_SANDBOX,
  });

  return checkout.serialize();
}

export async function processCheckoutRedirect(requestUrl: string) {
  const publicUrl = process.env.PUBLIC_APP_URL || "https://trendexhub.com";
  const info: CheckoutRedirectInfo | null =
    await freemius.checkout.processRedirect(requestUrl, publicUrl);
  if (info?.license_id) {
    await syncEntitlementByLicenseId(info.license_id);
  }
  return info;
}

export async function getPricingData() {
  try {
    return await freemius.api.product.retrievePricingData();
  } catch (err) {
    console.error("Error fetching Freemius pricing data:", err);
    return null;
  }
}
