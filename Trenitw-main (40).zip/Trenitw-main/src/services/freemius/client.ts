import { Freemius } from "@freemius/sdk";

let instance: Freemius | null = null;

export function getFreemiusClient(): Freemius {
  if (!instance) {
    const productId = process.env.FREEMIUS_PRODUCT_ID;
    const apiKey = process.env.FREEMIUS_API_KEY;
    const secretKey = process.env.FREEMIUS_SECRET_KEY;
    const publicKey = process.env.FREEMIUS_PUBLIC_KEY;

    if (!productId || !apiKey || !secretKey || !publicKey) {
      console.warn(
        "[Freemius] Missing required server environment variables: FREEMIUS_PRODUCT_ID, FREEMIUS_API_KEY, FREEMIUS_SECRET_KEY, FREEMIUS_PUBLIC_KEY",
      );
    }

    instance = new Freemius({
      productId: Number(productId) || 0,
      apiKey: apiKey || "",
      secretKey: secretKey || "",
      publicKey: publicKey || "",
    });
  }
  return instance;
}

export const freemius = new Proxy({} as Freemius, {
  get(_target, prop) {
    const client = getFreemiusClient();
    const value = (client as any)[prop];
    if (typeof value === "function") {
      return value.bind(client);
    }
    return value;
  },
});

export const IS_SANDBOX = process.env.FREEMIUS_SANDBOX !== "false";
