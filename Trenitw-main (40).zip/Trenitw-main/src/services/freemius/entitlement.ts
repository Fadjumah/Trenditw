import { freemius } from "./client";
import type { PurchaseInfo } from "@freemius/sdk";
import { Pool } from "pg";

let pool: Pool | null = null;
function getDbPool() {
  if (!pool) {
    const connectionString =
      process.env.DATABASE_URL || process.env.EXTERNAL_DATABASE_URL;

    if (!connectionString) {
      throw new Error(
        "[Freemius] DATABASE_URL or EXTERNAL_DATABASE_URL environment variable is required",
      );
    }

    pool = new Pool({
      connectionString,
      ssl:
        connectionString.includes("render.com") ||
        connectionString.includes("dpg-") ||
        connectionString.includes("supabase.com") ||
        connectionString.includes("sslmode=require")
          ? { rejectUnauthorized: false }
          : false,
    });
  }
  return pool;
}

export async function processPurchaseInfo(
  purchase: PurchaseInfo,
  customerId?: string,
) {
  const db = getDbPool();

  // 1. Resolve the Trendit customer. Webhooks do not carry our customer_id,
  // so lifecycle synchronization must fall back to the verified Freemius email.
  const purchaseEmail = (purchase.email || "").trim().toLowerCase();
  let resolvedCustomerId = customerId ? String(customerId) : "";

  if (resolvedCustomerId) {
    const userRes = await db.query(
      "SELECT customer_id, email FROM customers WHERE customer_id::text = $1 LIMIT 1",
      [resolvedCustomerId],
    );
    if (userRes.rows.length === 0) {
      throw new Error("Customer not found");
    }

    const customerEmail = String(userRes.rows[0].email || "").trim().toLowerCase();
    if (!purchaseEmail || customerEmail !== purchaseEmail) {
      throw new Error(
        "Email mismatch. The Freemius account email does not match the Trendit account email.",
      );
    }
  } else {
    if (!purchaseEmail) {
      console.warn(
        "[Freemius Sync] Cannot associate Freemius entitlement: purchase email is missing in payload. Skipping.",
      );
      return;
    }
    const userRes = await db.query(
      "SELECT customer_id FROM customers WHERE lower(trim(email)) = $1 LIMIT 1",
      [purchaseEmail],
    );
    if (userRes.rows.length === 0) {
      console.warn(
        `[Freemius Sync] No Trendit customer matches the Freemius account email: '${purchaseEmail}'. Skipping entitlement sync.`,
      );
      return;
    }
    resolvedCustomerId = String(userRes.rows[0].customer_id);
  }

  const record = purchase.toEntitlementRecord();
  const userId = resolvedCustomerId;

  // B. Verify the exact commercial product
  const expectedProductId = process.env.FREEMIUS_PRODUCT_ID;
  const expectedPlanId = process.env.FREEMIUS_GROWTH_PLAN_ID;
  const expectedPricingId = process.env.FREEMIUS_GROWTH_PRICING_ID;

  if (!expectedProductId || !expectedPlanId) {
    if (customerId) {
      throw new Error("Billing configuration missing server-side");
    }
    console.error(
      "[Freemius Sync] Billing configuration missing server-side (FREEMIUS_PRODUCT_ID or FREEMIUS_GROWTH_PLAN_ID).",
    );
    return;
  }

  const actualProductId = String(
    (record as any).fsProductId ||
      (purchase as any).plugin_id ||
      (purchase as any).product_id ||
      "",
  );
  const actualPlanId = String(record.fsPlanId || "");
  const actualPricingId = String(record.fsPricingId || "");

  if (actualProductId && actualProductId !== expectedProductId) {
    if (customerId) {
      throw new Error("Product ID mismatch");
    }
    console.warn(
      `[Freemius Sync] Product ID mismatch (got ${actualProductId}, expected ${expectedProductId}). Skipping.`,
    );
    return;
  }
  const allowedPlanIds = [
    expectedPlanId,
    process.env.FREEMIUS_PRO_PLAN_ID,
    process.env.FREEMIUS_GROWTH_PLAN_ID,
    "62230",
  ].filter(Boolean) as string[];

  if (actualPlanId && allowedPlanIds.length > 0 && !allowedPlanIds.includes(actualPlanId)) {
    console.info(
      `[Freemius Sync] Multi-tier plan ID ${actualPlanId} accepted for product ${actualProductId}`,
    );
  }
  if (
    actualPlanId === expectedPlanId &&
    expectedPricingId &&
    actualPricingId &&
    actualPricingId !== expectedPricingId
  ) {
    if (customerId) {
      throw new Error("Pricing ID mismatch");
    }
    console.warn(
      `[Freemius Sync] Pricing ID mismatch (got ${actualPricingId}, expected ${expectedPricingId}). Skipping.`,
    );
    return;
  }

  const isCanceled = Boolean(record.isCanceled);
  const trialData = (purchase as any).trial || (record as any).trial;
  const isTrial = Boolean(trialData);
  const trialEndsAt =
    trialData?.trial_ends_at || trialData?.trialEndsAt || null;
  const expiration = record.expiration || trialEndsAt;
  const now = new Date();

  let status = "unknown";
  if (isCanceled) {
    status = "canceled";
  } else if (expiration) {
    if (new Date(expiration) > now) {
      status = "active";
    } else {
      status = "expired";
    }
  }

  // Fetch previous status to emit analytics event if it changed
  let prevStatus: string | null = null;
  const existingRes = await db.query(
    "SELECT status FROM user_fs_entitlement WHERE fs_license_id = $1",
    [String(record.fsLicenseId)],
  );
  if (existingRes.rows.length > 0) {
    prevStatus = existingRes.rows[0].status;
  }

  const query = `
    INSERT INTO user_fs_entitlement (
      user_id,
      fs_license_id,
      fs_product_id,
      fs_plan_id,
      fs_pricing_id,
      fs_user_id,
      type,
      expiration,
      is_canceled,
      status,
      last_synced_at,
      is_trial,
      trial_ends_at,
      created_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7::fs_entitlement_type, $8, $9, $10, NOW(), $11, $12, $13)
    ON CONFLICT (fs_license_id) DO UPDATE SET
      user_id = EXCLUDED.user_id,
      fs_product_id = EXCLUDED.fs_product_id,
      fs_plan_id = EXCLUDED.fs_plan_id,
      fs_pricing_id = EXCLUDED.fs_pricing_id,
      fs_user_id = EXCLUDED.fs_user_id,
      type = EXCLUDED.type,
      expiration = EXCLUDED.expiration,
      is_canceled = EXCLUDED.is_canceled,
      status = CASE
        WHEN user_fs_entitlement.status = 'deleted' THEN 'deleted'
        ELSE EXCLUDED.status
      END,
      is_trial = EXCLUDED.is_trial,
      trial_ends_at = EXCLUDED.trial_ends_at,
      last_synced_at = NOW();
  `;

  await db.query(query, [
    String(userId),
    String(record.fsLicenseId),
    String(actualProductId),
    String(actualPlanId),
    String(actualPricingId),
    String(record.fsUserId),
    record.type,
    record.expiration,
    isCanceled,
    status,
    isTrial,
    trialEndsAt,
    record.createdAt || new Date(),
  ]);
}

export async function syncEntitlementByLicenseId(
  licenseId: string,
  customerId?: string,
) {
  try {
    const purchase = await freemius.purchase.retrievePurchase(licenseId);
    if (purchase) {
      await processPurchaseInfo(purchase, customerId);
    } else {
      console.warn(
        `[Freemius Sync] No purchase found for license ID: ${licenseId}`,
      );
    }
  } catch (err) {
    console.error(`[Freemius Sync] Failed to sync entitlement for license ${licenseId}:`, err);
    if (customerId) {
      throw err;
    }
  }
}

export async function syncEntitlementByEmail(
  email: string,
  customerId?: string,
) {
  try {
    const fsUser = await freemius.api.user.retrieveByEmail(
      email.trim().toLowerCase(),
    );
    if (!fsUser?.id) return null;

    const licenses = await (freemius.api.license as any).retrieveMany({
      userId: String(fsUser.id),
    });
    if (!Array.isArray(licenses) || licenses.length === 0) return null;

    const expectedProductId = process.env.FREEMIUS_PRODUCT_ID || "37245";
    const expectedPlanId = process.env.FREEMIUS_GROWTH_PLAN_ID || "62230";

    const validLicenses = licenses.filter(
      (l: any) =>
        String(l.plugin_id) === expectedProductId &&
        String(l.plan_id) === expectedPlanId &&
        !l.is_cancelled,
    );
    if (validLicenses.length === 0) return null;

    const primaryLicense = validLicenses[0];
    const purchase = await freemius.purchase.retrievePurchase(
      String(primaryLicense.id),
    );
    if (purchase && customerId) {
      await processPurchaseInfo(purchase, customerId);
    }
    return purchase;
  } catch (err) {
    console.error(
      `[Freemius Sync] Error syncing entitlement for ${email}:`,
      err,
    );
    return null;
  }
}

export async function deleteEntitlement(fsLicenseId: string) {
  const db = getDbPool();
  try {
    await db.query(
      `UPDATE user_fs_entitlement 
       SET status = 'deleted', is_canceled = true, deleted_at = NOW(), last_synced_at = NOW() 
       WHERE fs_license_id = $1`,
      [fsLicenseId],
    );
  } catch (err) {
    console.error(`Failed to delete entitlement ${fsLicenseId}:`, err);
  }
}

export async function getUserEntitlement(userIdOrEmail: string) {
  const db = getDbPool();
  // Find entitlements where user_id matches customer ID.
  const res = await db.query(
    `SELECT * FROM user_fs_entitlement 
     WHERE user_id = $1
     ORDER BY created_at DESC`,
    [userIdOrEmail],
  );

  const rows = res.rows.map((r) => ({
    fsLicenseId: r.fs_license_id,
    fsPlanId: r.fs_plan_id,
    fsPricingId: r.fs_pricing_id,
    fsUserId: r.fs_user_id,
    type: r.type,
    expiration: r.expiration,
    isCanceled: r.is_canceled,
    status: r.status,
    createdAt: r.created_at,
    isTrial: Boolean(r.is_trial),
    trialEndsAt: r.trial_ends_at,
  }));

  const subscriptionRows = rows.filter(
    (r) =>
      r.type === "subscription" &&
      r.status !== "deleted" &&
      r.status !== "unknown",
  );
  const activeSub = freemius.entitlement.getActive(subscriptionRows);
  if (activeSub) return activeSub;

  const now = new Date();
  return (
    rows.find(
      (r) =>
        r.type === "oneoff" &&
        !r.isCanceled &&
        r.status !== "deleted" &&
        r.status !== "unknown" &&
        (r.expiration === null || new Date(r.expiration) > now),
    ) ?? null
  );
}
