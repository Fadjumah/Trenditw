import type { WebhookEventType } from "@freemius/sdk";
import { freemius } from "./client";
import {
  syncEntitlementByLicenseId,
  syncEntitlementByEmail,
  deleteEntitlement,
} from "./entitlement";

const LICENSE_EVENTS: WebhookEventType[] = [
  "license.created",
  "license.extended",
  "license.shortened",
  "license.updated",
  "license.cancelled",
  "license.expired",
  "license.plan.changed",
];

/**
 * Handles in-app purchase callback from the Freemius Checkout overlay or sync requests (POST /api/purchase)
 */
export async function handlePurchaseEndpoint(
  request: Request,
): Promise<Response> {
  try {
    const body = (await request.json()) as any;
    const licenseId =
      body?.license_id ||
      body?.purchase?.license_id ||
      body?.trial?.license_id ||
      body?.license?.id;

    const customerId = body?.customer_id ? String(body.customer_id) : undefined;
    const email = body?.email ? String(body.email) : undefined;

    if (!licenseId && !email) {
      return new Response(
        JSON.stringify({ error: "Bad Request: missing license_id or email in payload" }),
        {
          status: 400,
          headers: { "content-type": "application/json" },
        },
      );
    }

    if (licenseId) {
      console.log(
        `[Freemius Purchase] Processing purchase for license_id: ${licenseId}, customer_id: ${customerId}`,
      );
      await syncEntitlementByLicenseId(String(licenseId), customerId);
    } else if (email) {
      console.log(
        `[Freemius Purchase] Syncing entitlement by email: ${email}, customer_id: ${customerId}`,
      );
      await syncEntitlementByEmail(email, customerId);
    }

    return new Response(
      JSON.stringify({
        status: "success",
        message: "Purchase entitlement recorded",
      }),
      {
        status: 200,
        headers: { "content-type": "application/json" },
      },
    );
  } catch (error: any) {
    console.error("[Freemius Purchase] Error syncing purchase:", error);
    return new Response(
      JSON.stringify({
        error: "Internal Server Error",
        message: error?.message,
      }),
      {
        status: 500,
        headers: { "content-type": "application/json" },
      },
    );
  }
}

/**
 * Handles lifecycle webhooks from Freemius (POST /api/webhooks/freemius)
 */
export async function handleFreemiusWebhook(
  request: Request,
): Promise<Response> {
  try {
    const listener = freemius.webhook.createListener();

    // Re-sync authoritative purchase for license events
    listener.on(LICENSE_EVENTS, async ({ objects: { license } }) => {
      try {
        const id = (license as any)?.id;
        console.log(
          `[Freemius Webhook] License lifecycle event received for ID: ${id}`,
        );
        if (id) {
          await syncEntitlementByLicenseId(String(id));
        }
      } catch (err) {
        console.error("[Freemius Webhook] Error processing license event:", err);
      }
    });

    // Re-sync for subscription lifecycle events (trial created/ended, renewed, cancelled, expired, payment failed)
    listener.on(
      [
        "subscription.created",
        "subscription.trial_started",
        "subscription.trial_ended",
        "subscription.renewed",
        "subscription.cancelled",
        "subscription.expired",
        "subscription.payment_failed",
        "subscription.reactivated",
      ] as any,
      async (eventData: any) => {
        try {
          const licenseId =
            eventData?.objects?.license?.id ||
            eventData?.objects?.subscription?.license_id ||
            eventData?.data?.license_id ||
            eventData?.data?.id;
          console.log(
            `[Freemius Webhook] Subscription lifecycle event received for license ID: ${licenseId}`,
          );
          if (licenseId) {
            await syncEntitlementByLicenseId(String(licenseId));
          }
        } catch (err) {
          console.error("[Freemius Webhook] Error processing subscription event:", err);
        }
      },
    );

    // Re-sync for payment events (payment created, failed, refunded)
    listener.on(
      ["payment.created", "payment.refunded", "payment.failed"] as any,
      async (eventData: any) => {
        try {
          const licenseId =
            eventData?.objects?.license?.id ||
            eventData?.objects?.payment?.license_id ||
            eventData?.data?.license_id;
          console.log(
            `[Freemius Webhook] Payment lifecycle event received for license ID: ${licenseId}`,
          );
          if (licenseId) {
            await syncEntitlementByLicenseId(String(licenseId));
          }
        } catch (err) {
          console.error("[Freemius Webhook] Error processing payment event:", err);
        }
      },
    );

    // Handle deletion
    listener.on("license.deleted", async ({ data }) => {
      try {
        const licenseId = (data as any)?.license_id;
        console.log(`[Freemius Webhook] License deleted for ID: ${licenseId}`);
        if (licenseId) {
          await deleteEntitlement(String(licenseId));
        }
      } catch (err) {
        console.error("[Freemius Webhook] Error processing deletion event:", err);
      }
    });

    return await freemius.webhook.processFetch(listener, request);
  } catch (error: any) {
    console.error("[Freemius Webhook] Error processing webhook:", error);
    return new Response(
      JSON.stringify({
        error: "Webhook processing failed",
        message: error?.message,
      }),
      {
        status: 500,
        headers: { "content-type": "application/json" },
      },
    );
  }
}

/**
 * Returns Freemius checkout config including dynamic sandbox token when FREEMIUS_SANDBOX=true (GET /api/checkout/config)
 */
export async function handleCheckoutConfigEndpoint(
  request: Request,
): Promise<Response> {
  try {
    const { getCheckoutConfig } = await import("./checkout");
    const url = new URL(request.url);
    const planId = url.searchParams.get("plan_id") || undefined;
    const product = url.searchParams.get("product") || undefined;
    const config = getCheckoutConfig(planId, product);

    return new Response(JSON.stringify(config), {
      status: 200,
      headers: {
        "content-type": "application/json",
        "cache-control": "no-store, no-cache, must-revalidate",
      },
    });
  } catch (error: any) {
    console.error("[Freemius Config] Error generating checkout config:", error);
    return new Response(
      JSON.stringify({
        error: "Internal Server Error",
        message: error?.message,
      }),
      {
        status: 500,
        headers: { "content-type": "application/json" },
      },
    );
  }
}
